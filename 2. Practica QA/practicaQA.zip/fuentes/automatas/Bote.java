package automatas;
/**
 * Clase que modeliza un bote que se desliza por una cinta. Simplemente es una
 * clase para guardar el atributo de la posici�n del bote sobre una cinta.
 * 
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */
public class Bote
{
	/**
	 * Posici�n del bote en una cinta.
	 */
	protected float posicion=0f;
	
	/**
	 * Obtiene la posici�n del bote en la cinta.
	 * @return Valor de la posici�n en metros (valor decimal)
	 */
	public float getPosicion()
	{
		return posicion;
	}

	/**
	 * Establece la posici�n del bote en la cinta.
	 * @param posicion Valor de la posici�n en metros (valor decimal)
	 */
	public void setPosicion(float posicion)
	{
		this.posicion = posicion;
	}
}
