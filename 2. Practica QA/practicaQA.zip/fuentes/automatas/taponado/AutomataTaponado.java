package automatas.taponado;

import java.util.Iterator;

import scada.Configuracion;
import automatas.Actuador;
import automatas.Automata;
import automatas.Cinta;
import automatas.Detector;
import automatas.ISensor;
import automatas.SensorPosicion;

import comun.IConstantes;
import comunicaciones.BuzonEntrada;
import comunicaciones.BuzonSalida;
import comunicaciones.ComunicacionException;
import comunicaciones.Mensaje;
import comunicaciones.MensajeConfig;
import comunicaciones.MensajeEstado;
import comunicaciones.MensajeParada;
/**
 * Clase que modeliza el aut�mata de taponado. Tiene un m�todo main para lanzarlo,
 * y cuyos par�metros son el puerto donde escuha y la direcci�n y puerto donde
 * escucha el aut�mata maestro. Aqu� va un ejemplo de invocaci�n: <br>
 * <pre>
 * 			$> java automatas.AutomataTaponado 6777 host1.uc3m.es:8080
 * </pre>
 * Como propiedades de clase tendr� a la cinta, los sensores y actuadores necesarios,
 * y dem�s propiedades para almacenar su informaci�n.
 * Por heredar de <code>Automata</code>, debe implementar el m�todo <code>ciclo</code>,
 * que es donde realizar� los c�lculos para ver a qu� estado transita cada vez (los valores
 * de los estados los obtiene del interfaz <code>IConstantes</code>.
 * Para comunicarse tiene un buz�n de entrada y otro de salida. Cada ciclo de reloj, y antes
 * de hacer los c�lculos para ver a qu� estado se transita, se leen los mensajes del buz�n
 * de entrada para actuar en consecuencia. 
 * 
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 * @see comun.IConstantes
 * @see automatas.Automata
 * @see automatas.Cinta
 * @see automatas.ISensor
 * @see automatas.SensorPosicion
 * @see automatas.Detector
 * @see automatas.Actuador
 * @see comunicaciones.BuzonEntrada
 * @see comunicaciones.BuzonSalida
 *
 */
public class AutomataTaponado extends Automata 
{
	/**
	 * Cinta del aut�mata
	 */
	protected Cinta cinta = null;
	/**
	 * Capacidad de la caja final de embalaje. Cada vez que se mete un bote, este
	 * contador decrece. 
	 */
	private int capacidadCajaEmbalaje;
	/**
	 * Tiempo que tarda el robot en trasladar el bote a la caja de embalaje
	 */
	private int tiempoTransporteCajaEmbalaje;
	/**
	 * Sensor de posici�n de taponado
	 */
	protected ISensor sPosTaponado;
	/**
	 * Sensor de posici�n de etiquetado
	 */
	protected ISensor sPosEtiquetado;
	/**
	 * Sensor de posici�n de detecci�n de bote mal tapado
	 */
	protected ISensor sPosDeteccion;
	/**
	 * Detector de bote mal tapado
	 */
	protected ISensor dBoteTapado;
	/**
	 * En esta propiedad guardamos lo que dice el detector de bote mal tapado para
	 * que al llegar a la zona de expulsion actuemos en consecuencia.
	 */
	protected boolean boteDebeSerExpulsado;	
	/**
	 * Sensor de posici�n de expulsion de bote mal tapado
	 */
	protected ISensor sPosExpulsion;
	/**
	 * Sensor de posici�n de final de cinta
	 */
	protected ISensor sPosFinal;
	/**
	 * Actuador para el tapador de botes
	 */
	protected Actuador tapador = new Actuador();
	/**
	 * Actuador para el etiquetador de botes
	 */
	protected Actuador etiquetador = new Actuador();
	/**
	 * Actuador para el expulsor de botes
	 */
	protected Actuador expulsor = new Actuador();
	/**
	 * Actuador para el robot de transporte a la caja de embalaje
	 */
	protected Actuador robot = new Actuador();
	
	/**
	 * Propiedad que indica si el aut�mata est� o no funcionando
	 */
	protected boolean automataFuncionando = false;
	/**
	 * Propiedad que indica si se recibi� un mensaje de parada normal del maestro.
	 */
	protected boolean paradaNormal = false;
	
	/**
	 * Buz�n de mensajes entrantes desde el aut�mata maestro.
	 */
	protected BuzonEntrada buz_ent = null;
	/**
	 * Buz�n de salida de mensajes hacia el aut�mata maestro
	 */
	protected BuzonSalida buz_sal = null;
	
	/**
	 * El constructor recibe el puerto por donde escuchar los mensajes del maestro,
	 * y la direcci�n de �ste para enviarle mensajes. Se invoca desde el m�todo main,
	 * puesto que funciona como aplicaci�n
	 * @param puerto Puerto donde escuchar� el aut�mata de taponado
	 * @param dirMaestro Direcci�n del aut�mata maestro de la forma host:puerto
	 */
	public AutomataTaponado(int puerto, String dirMaestro) 
	{
		inicializarBuzones(puerto, dirMaestro);
		this.estado = IConstantes.AT_SISTEMA_PARADO;
		start();
	}
	
	/**
	 * M�todo llamado desde el constructor que crea los buzones. Si hubiese alg�n fallo,
	 * se indicar�a por pantalla y el programa terminar�a.
	 * @param puerto Puerto donde escuchar� el aut�mata de taponado
	 * @param dirMaestro Direcci�n del aut�mata maestro de la forma host:puerto
	 */
	private void inicializarBuzones(int puerto, String dirMaestro) 
	{
		try
		{
			String hostMaestro = dirMaestro.substring(0, dirMaestro.indexOf(":"));
			int puertoMaestro = Integer.parseInt(dirMaestro.substring(dirMaestro.indexOf(":")+1));
			buz_ent = new BuzonEntrada(puerto);
			buz_sal = new BuzonSalida(hostMaestro, puertoMaestro);
		}
		catch(Exception e)
		{
			System.out.println("Error inicializando buzones:"+e);
			System.exit(-1);
		}
	}
	
	/**
	 * Este m�todo se llama cuando el maestro env�a a los aut�matas la configuaci�n.
	 * Recibimos en un mensaje todos los datos y preparamos los elementos del aut�mata
	 * con �stos.
	 * @param cicloReloj Ciclo de reloj del aut�mata
	 * @param longitudCinta Longitud de la cinta en metros
	 * @param velocidadCinta Velocidad de la cinta en metros por minuto
	 * @param umbralBotesMalTapados Umbral de botes mal tapados (entre 0 y 100)
	 * @param capacidadCajaEmbalaje Capacidad de la caja de embalaje
	 * @param tiempoTransporteCajaEmbalaje Tiempo en segundos en transportar el bote a
	 *        la caja de embalaje.
	 */	
	public void configurar(int cicloReloj, int longitudCinta, int velocidadCinta, 
						   int umbralBotesMalTapados,
						   int capacidadCajaEmbalaje, int tiempoTransporteCajaEmbalaje)
	{
		// Establecemos los valores
		if (cinta==null)
			cinta = new Cinta(longitudCinta, velocidadCinta);
		else
		{
			cinta.finalizarHilo();
			cinta = new Cinta(longitudCinta, velocidadCinta);
		}
		this.cicloReloj = cicloReloj;
		this.tiempoTransporteCajaEmbalaje = tiempoTransporteCajaEmbalaje;
		this.capacidadCajaEmbalaje=capacidadCajaEmbalaje;
		paradaNormal=false;
		// Colocamos los sensores y el detector
		sPosTaponado=new SensorPosicion((int) (0.3*cinta.getLongitud()));
		sPosEtiquetado=new SensorPosicion((int) (0.6*cinta.getLongitud()));
		sPosDeteccion=new SensorPosicion((int) (0.7*cinta.getLongitud()));
		dBoteTapado=new Detector(umbralBotesMalTapados);
		sPosExpulsion=new SensorPosicion((int) (0.8*cinta.getLongitud()));
		sPosFinal=new SensorPosicion(cinta.getLongitud());
		// Al principio la cinta est� esperando un bote
		this.estado = IConstantes.AT_ESPERANDO_BOTE;
		automataFuncionando=true;
	}


	/**
	 * M�todo que estamos obligados a implementar por heredar de <code>Automata</code>
	 * y donde se especifica las acciones a realizar en cada ciclo. Este aut�mata siempre
	 * permanecer� a la escucha de mensajes, y en cada ciclo procesa los mensajes que puedan
	 * llegar del maestro y hace los c�lculos pertinentes para transitar a otro estado.
	 */	
	protected void ciclo()
	{
		// Leemos los mensajes que nos llegan del maestro
		for(Iterator it = buz_ent.getMensajes().iterator(); it.hasNext();)
			procesarMensajeDelMaestro((Mensaje) it.next());
		// Comprobamos todos los casos posibles
		if (estado==IConstantes.AT_SISTEMA_PARADO)
		{
			// No hacemos nada
		}
		else if (estado==IConstantes.AT_PARADA_EMERGENCIA_CAJA_BOTES_LLENA)
		{
			automataFuncionando=false;
		}
		else if (estado==IConstantes.AT_BOTE_EN_CAJA_EMBALAJE)
		{
			cinta.reset();
			if (paradaNormal)
				estado = IConstantes.AT_SISTEMA_PARADO;
			else
				estado = IConstantes.AT_ESPERANDO_BOTE;
		}
		else
		{
			if (sPosTaponado!=null && sPosTaponado.getEstado(cinta.getBote()))
			{
				cinta.parar();
				if (estado == IConstantes.AT_ANDANDO_SIN_TAPA)
				{
					tapador.inicializa(1);
					estado = IConstantes.AT_TAPANDO;
				}
				if (!tapador.actua())
				{
					estado = IConstantes.AT_ANDANDO_TAPADO;
					cinta.arrancar();
				}
			}
			else if (sPosEtiquetado!=null && sPosEtiquetado.getEstado(cinta.getBote()))
			{
				cinta.parar(); 
				if (estado == IConstantes.AT_ANDANDO_TAPADO)
				{
					etiquetador.inicializa(1);
					estado = IConstantes.AT_ETIQUETANDO;
				}
				if (!etiquetador.actua())
				{
					estado = IConstantes.AT_ANDANDO_ETIQUETADO;
					cinta.arrancar();
				}
			}
			else if (sPosDeteccion!=null && sPosDeteccion.getEstado(cinta.getBote()) && estado==IConstantes.AT_ANDANDO_ETIQUETADO)
			{
				boteDebeSerExpulsado = !dBoteTapado.getEstado(cinta.getBote());
				estado = IConstantes.AT_PASA_POR_DETECTOR_TAPADO;
			}
			else if (estado == IConstantes.AT_PASA_POR_DETECTOR_TAPADO)
			{
				// La deteccion se produce en un solo ciclo, luego sigue circulando
				estado = IConstantes.AT_ANDANDO_ETIQUETADO_DETECTADO;
			}
			else if (sPosExpulsion!=null && 
					sPosExpulsion.getEstado(cinta.getBote()) && 
					boteDebeSerExpulsado)
			{
				cinta.parar();
				if (estado==IConstantes.AT_ANDANDO_ETIQUETADO_DETECTADO)
				{
					estado = IConstantes.AT_EXPULSANDO_BOTE;
					expulsor.inicializa(1);
				}
				if (!expulsor.actua())
				{
					estado = IConstantes.AT_ESPERANDO_BOTE;
				}
			}			
			else if ((sPosFinal!=null && sPosFinal.getEstado(cinta.getBote())) || 
					 (cinta!=null && cinta.getBote()!=null && cinta.getBote().getPosicion()>cinta.getLongitud()))
			{
				cinta.parar();
				if (estado!=IConstantes.AT_TRANSPORTANDO)
				{
					 if(capacidadCajaEmbalaje<=0)
					 	estado=IConstantes.AT_PARADA_EMERGENCIA_CAJA_BOTES_LLENA;
					 else 
					 {
						capacidadCajaEmbalaje--;
						estado=IConstantes.AT_TRANSPORTANDO;
						robot.inicializa(tiempoTransporteCajaEmbalaje*1000/cicloReloj);
					}
				}
				if (estado==IConstantes.AT_TRANSPORTANDO)
				{
					if (!robot.actua())
					{
						estado = IConstantes.AT_BOTE_EN_CAJA_EMBALAJE;
					}
				}
			}
		}
		try
		{			
			if (automataFuncionando)
				buz_sal.enviarMensaje(new MensajeEstado(IConstantes.AUTOMATA_TAPONADO, estado));
		}
		catch (ComunicacionException e)
		{
			System.out.println("Error comunicando con el automata maestro:"+e);
			System.exit(-1);
		} 
	}
	

	/**
	 * M�todo que procesa un mensaje recibido por el buz�n de entrada. Dependiendo
	 * del contenido, se har�n unas cosas u otras.
	 * @param m Mensaje recibido por el buz�n de entrada del automata maestro
	 */
	private void procesarMensajeDelMaestro(Mensaje m)
	{
		if (m instanceof MensajeConfig)
		{
			Configuracion conf = ((MensajeConfig) m).getConfiguracion();
			configurar(conf.getCicloReloj(),
					   conf.getLongitudCintaTaponado(),
					   conf.getVelocidadCintaTaponado(),
					   conf.getUmbralBotesMalTaponados(),
					   conf.getCapacidadCajaEmbalaje(),
					   conf.getTiempoTransporteCajaEmbalaje());
		}
		else if (m instanceof MensajeParada)
		{
			MensajeParada mp = (MensajeParada) m;
			if (mp.esDeEmergencia())
			{
				estado = IConstantes.AT_SISTEMA_PARADO;
				cinta.reset();
			}
			else
			{
				paradaNormal = true;
			}
		} 
		else if (m instanceof MensajeEstado)
		{
			MensajeEstado me = (MensajeEstado) m;
			if (me.getEstado()==IConstantes.AM_BOTE_TRANSPORTADO)
			{
				estado = IConstantes.AT_ANDANDO_SIN_TAPA;
				cinta.reset();
				cinta.ponerBote();
				cinta.arrancar();
			}
		}
	}
	
	/**
	 * Procedimiento principal del programa. Se invoca para lanzarlo. Si no se indican 
	 * argumentos, muestra por pantalla la ayuda. 
	 * @param args Par�metros de la linea de comandos
	 */	
	public static void main(String[] args)
	{
		if (args.length!=2)
		{
			System.out.println("Los argumentos que acepta el programa son:\n");
			System.out.println("\t-Puerto de escucha de mensajes provenientes del automata maestro");
			System.out.println("\t-Donde escucha el automata maestro los mensajes, de la forma host:puerto\n\n");
		}
		else
			new AutomataTaponado(Integer.parseInt(args[0]), args[1]);
	}

}
