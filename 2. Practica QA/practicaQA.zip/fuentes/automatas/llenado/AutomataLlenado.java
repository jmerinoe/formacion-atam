package automatas.llenado;

import java.util.Iterator;

import scada.Configuracion;
import automatas.Actuador;
import automatas.Automata;
import automatas.Cinta;
import automatas.Detector;
import automatas.ISensor;
import automatas.SensorPosicion;

import comun.IConstantes;
import comunicaciones.BuzonEntrada;
import comunicaciones.BuzonSalida;
import comunicaciones.ComunicacionException;
import comunicaciones.Mensaje;
import comunicaciones.MensajeConfig;
import comunicaciones.MensajeEstado;
import comunicaciones.MensajeParada;

/**
 * Clase que modeliza el aut�mata de llenado. Tiene un m�todo main para lanzarlo,
 * y cuyos par�metros son el puerto donde escuha y la direcci�n y puerto donde
 * escucha el aut�mata maestro. Aqu� va un ejemplo de invocaci�n: <br>
 * <pre>
 * 			$> java automatas.AutomataLlenado 7666 host2.uc3m.es:8888
 * </pre>
 * Como propiedades de clase tendr� a la cinta, los sensores y actuadores necesarios,
 * y dem�s propiedades para almacenar su informaci�n.
 * Por heredar de <code>Automata</code>, debe implementar el m�todo <code>ciclo</code>,
 * que es donde realizar� los c�lculos para ver a qu� estado transita cada vez (los valores
 * de los estados los obtiene del interfaz <code>IConstantes</code>.
 * Para comunicarse tiene un buz�n de entrada y otro de salida. Cada ciclo de reloj, y antes
 * de hacer los c�lculos para ver a qu� estado se transita, se leen los mensajes del buz�n
 * de entrada para actuar en consecuencia. 
 * 
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 * @see comun.IConstantes
 * @see automatas.Automata
 * @see automatas.Cinta
 * @see automatas.ISensor
 * @see automatas.SensorPosicion
 * @see automatas.Detector
 * @see automatas.Actuador
 * @see comunicaciones.BuzonEntrada
 * @see comunicaciones.BuzonSalida
 *
 */
public class AutomataLlenado extends Automata 
{
	/**
	 * Cinta del aut�mata
	 */
	protected Cinta cinta = null;
	/**
	 * Tiempo de llenado del bote en segundos
	 */
	protected int tiempoLlenadoBote;
	/**
	 * Botes que hay en el dep�sito de botes. Cada vez que sale uno, el contador decrece.
	 */
	protected int botes;
	/**
	 * Capacidad del dep�sito de botes mal llenados. Cada vez que se descarta
	 * uno, el contador decrece.
	 */
	protected int capacidadMalLlenados;
	/**
	 * Botes de mermelada que se pueden llenar. Cada vez que se llena un bote,
	 * este contador decrece.
	 */
	protected int mermelada;
	
	/**
	 * Sensor de posici�n de llenado
	 */
	protected ISensor sPosLlenado;
	/**
	 * Sensor de posici�n de deteccion
	 */
	protected ISensor sPosDeteccion;
	/**
	 * Detector que mira si el bote est� bien o mal llenado
	 */
	protected ISensor dBoteLlenado;
	/**
	 * Aqui se almacena el resultado del detector de llenado. Cuando el bote pasa
	 * por la zona de expulsi�n, si el detectot dijo que hab�a que expulsarlo, se expulsa.
	 */
	protected boolean boteDebeSerExpulsado;	
	/**
	 * Sensor de posici�n de expulsi�n
	 */
	protected ISensor sPosExpulsion;
	/**
	 * Sensor de posici�n final de cinta
	 */
	protected ISensor sPosFinal;
	
	/**
	 * Actuador para el llenador de mermelada
	 */
	protected Actuador llenador = new Actuador();
	/**
	 * Actuador para el expulsor de botes mal llenados
	 */
	protected Actuador expulsor = new Actuador();
	
	/**
	 * Propiedad que nos indica si el aut�mata est� o no funcionando
	 */
	protected boolean automataFuncionando = false;
	/**
	 * Propiedad que nos indica si el aut�mata recibi� el aviso de parada normal
	 */
	protected boolean paradaNormal = false;
	
	/**
	 * Buz�n de entrada por donde recibe mensajes del aut�mata maestro
	 */
	protected BuzonEntrada buz_ent = null;
	/**
	 * Buz�n de salida por donde le env�a los mensajes al aut�mata maestro
	 */
	protected BuzonSalida buz_sal = null;
	
	/**
	 * El constructor recibe el puerto por donde escuchar los mensajes del maestro,
	 * y la direcci�n de �ste para enviarle mensajes. Se invoca desde el m�todo main,
	 * puesto que funciona como aplicaci�n
	 * @param puerto Puerto donde escuchar� el aut�mata de llenado
	 * @param dirMaestro Direcci�n del aut�mata maestro de la forma host:puerto
	 */
	public AutomataLlenado(int puerto, String dirMaestro) 
	{
		inicializarBuzones(puerto, dirMaestro);
		this.estado = IConstantes.AL_SISTEMA_PARADO;
		start();
	}
	
	/**
	 * M�todo llamado desde el constructor que crea los buzones. Si hubiese alg�n fallo,
	 * se indicar�a por pantalla y el programa terminar�a.
	 * @param puerto Puerto donde escuchar� el aut�mata de llenado
	 * @param dirMaestro Direcci�n del aut�mata maestro de la forma host:puerto
	 */
	private void inicializarBuzones(int puerto, String dirMaestro) 
	{
		try
		{
			String hostMaestro = dirMaestro.substring(0, dirMaestro.indexOf(":"));
			int puertoMaestro = Integer.parseInt(dirMaestro.substring(dirMaestro.indexOf(":")+1));
			buz_ent = new BuzonEntrada(puerto);
			buz_sal = new BuzonSalida(hostMaestro, puertoMaestro);
		}
		catch(Exception e)
		{
			System.out.println("Error inicializando buzones:"+e);
			System.exit(-1);
		}
	}
	 
	/**
	 * Este m�todo se llama cuando el maestro env�a a los aut�matas la configuaci�n.
	 * Recibimos en un mensaje todos los datos y preparamos los elementos del aut�mata
	 * con �stos.
	 * @param cicloReloj Ciclo de reloj del aut�mata
	 * @param longitudCinta Longitud de la cinta en metros
	 * @param velocidadCinta Velocidad de la cinta en metros por minuto
	 * @param tiempoLlenadoBote Tiempo de llenado del bote en segundos
	 * @param umbralBotesVacios Umbral de botes vac�os (entre 0 y 100)
	 * @param capacidadDeposBotes Capacidad del dep�sito de botes inicial
	 * @param capacidadMalLlenados Capacidad del dep�sito de botes mal llenados 
	 * @param mermelada Cantidad de botes que pueden ser llenados con mermelada
	 */
	public void configurar(int cicloReloj, int longitudCinta, int velocidadCinta, 
						   int tiempoLlenadoBote, int umbralBotesVacios,
						   int capacidadDeposBotes, int capacidadMalLlenados,
						   int mermelada)
	{
		// Establecemos los valores
		if (this.cinta==null)
			this.cinta = new Cinta(longitudCinta, velocidadCinta);
		else
		{
			this.cinta.finalizarHilo();
			this.cinta = new Cinta(longitudCinta, velocidadCinta);
		}
		this.cicloReloj = cicloReloj;
		this.tiempoLlenadoBote = tiempoLlenadoBote;
		this.botes = capacidadDeposBotes;
		this.capacidadMalLlenados = capacidadMalLlenados;
		this.mermelada = mermelada;
		paradaNormal=false;
		// Colocamos los sensores y el detector
		this.sPosLlenado=new SensorPosicion((int) (0.3*cinta.getLongitud()));
		this.sPosDeteccion=new SensorPosicion((int) (0.6*cinta.getLongitud()));
		this.dBoteLlenado=new Detector(umbralBotesVacios);
		this.sPosExpulsion=new SensorPosicion((int) (0.7*cinta.getLongitud()));
		this.sPosFinal=new SensorPosicion(cinta.getLongitud());
		// Al principio la cinta est� libre
		this.estado=IConstantes.AL_CINTA_LIBRE;
		automataFuncionando=true;
	}
	
	/**
	 * M�todo que estamos obligados a implementar por heredar de <code>Automata</code>
	 * y donde se especifica las acciones a realizar en cada ciclo. Este aut�mata siempre
	 * permanecer� a la escucha de mensajes, y en cada ciclo procesa los mensajes que puedan
	 * llegar del maestro y hace los c�lculos pertinentes para transitar a otro estado.
	 */	
	protected void ciclo()
	{
		// Leemos los mensajes que nos llegan del maestro
		for(Iterator it = buz_ent.getMensajes().iterator(); it.hasNext();)
			procesarMensajeDelMaestro((Mensaje) it.next());
		
		// Comprobamos todos los casos posibles
		if (estado==IConstantes.AL_SISTEMA_PARADO)
		{
		}
		else if (estado==IConstantes.AL_PARADA_EMERGENCIA_NO_BOTES || estado==IConstantes.AL_PARADA_EMERGENCIA_NO_MERMELADA || estado==IConstantes.AL_PARADA_EMERGENCIA_CAJA_BOTES_LLENA)
		{
			automataFuncionando=false;
		}
		else if (estado==IConstantes.AL_CINTA_LIBRE)
		{
			if (paradaNormal)
			{
				estado=IConstantes.AL_SISTEMA_PARADO;
				cinta.parar();
			}
			else
			{
				if (this.capacidadMalLlenados<=0)
					estado = IConstantes.AL_PARADA_EMERGENCIA_CAJA_BOTES_LLENA;
				else if (botes<=0)
					estado = IConstantes.AL_PARADA_EMERGENCIA_NO_BOTES;
				else if (mermelada<=0)
					estado = IConstantes.AL_PARADA_EMERGENCIA_NO_MERMELADA;
				else
					estado = IConstantes.AL_SACANDO_BOTE;
			}
		}
		else if (estado==IConstantes.AL_SACANDO_BOTE)
		{
			botes--;
			estado = IConstantes.AL_ANDANDO_VACIO;
			cinta.parar();
			cinta.reset();
			cinta.ponerBote();
			cinta.arrancar();
		}
		else if (estado != IConstantes.AL_SISTEMA_PARADO)
		{
			if (sPosLlenado!=null && sPosLlenado.getEstado(cinta.getBote()) && 
				(estado==IConstantes.AL_ANDANDO_VACIO || estado==IConstantes.AL_LLENANDO))
			{
				cinta.parar();
				if (estado != IConstantes.AL_LLENANDO)
					llenador.inicializa((tiempoLlenadoBote*1000)/this.cicloReloj);
				estado = IConstantes.AL_LLENANDO;
				if (!llenador.actua())
				{
					estado = IConstantes.AL_ANDANDO_LLENO;
					mermelada-=1;
					cinta.arrancar();
				}
			}
			else if (sPosDeteccion!=null && sPosDeteccion.getEstado(cinta.getBote()) && estado==IConstantes.AL_ANDANDO_LLENO)
			{
				boteDebeSerExpulsado = !dBoteLlenado.getEstado(cinta.getBote());
				estado = IConstantes.AL_PASA_POR_DETECTOR_LLENADO;
			}
			else if (estado == IConstantes.AL_PASA_POR_DETECTOR_LLENADO)
			{
				// La deteccion se produce en un solo ciclo, luego sigue circulando
				estado = IConstantes.AL_ANDANDO_LLENO_DETECTADO;
			}
			else if (sPosExpulsion!=null && sPosExpulsion.getEstado(cinta.getBote()) && boteDebeSerExpulsado)
			{
				cinta.parar();
				if (estado==IConstantes.AL_ANDANDO_LLENO_DETECTADO)
				{
					estado = IConstantes.AL_EXPULSANDO_BOTE;
					expulsor.inicializa(1);
				}
				if (!expulsor.actua())
				{
					estado = IConstantes.AL_CINTA_LIBRE;
					this.capacidadMalLlenados--;
					if (this.capacidadMalLlenados<=0)
						estado = IConstantes.AL_PARADA_EMERGENCIA_CAJA_BOTES_LLENA;					
				//	cinta.ponerBote();
					//cinta.arrancar();
				}
			}			
			else if ((sPosFinal!=null && sPosFinal.getEstado(cinta.getBote())) || 
					(cinta!=null && cinta.getBote()!=null && cinta.getBote().getPosicion()>cinta.getLongitud()))
			{
				estado = IConstantes.AL_ESPERANDO_TRANSPORTE;
				cinta.parar();
			}
		}
		// Enviamos el estado actual al maestro
		try
		{
			if (automataFuncionando)
				buz_sal.enviarMensaje(new MensajeEstado(IConstantes.AUTOMATA_LLENADO, estado));				
		}
		catch (ComunicacionException e)
		{
			System.out.println("Error comunicando con el automata maestro:"+e);
			System.exit(-1);
		} 		
	}
	
	/**
	 * M�todo que procesa un mensaje recibido por el buz�n de entrada. Dependiendo
	 * del contenido, se har�n unas cosas u otras.
	 * @param m Mensaje recibido por el buz�n de entrada del automata maestro
	 */
	private void procesarMensajeDelMaestro(Mensaje m)
	{
		if (m instanceof MensajeConfig)
		{
			Configuracion conf = ((MensajeConfig) m).getConfiguracion();
			configurar(conf.getCicloReloj(),
					   conf.getLongitudCintaLlenado(),
					   conf.getVelocidadCintaLlenado(),
					   conf.getTiempoLlenadoBote(),
					   conf.getUmbralBotesVacios(),
					   conf.getCapacidadDepositoBotes(),
					   conf.getCapacidadCajaMalLlenados(),
					   conf.getCapacidadDepositoMermelada());
		}
		else if (m instanceof MensajeParada)
		{
			MensajeParada mp = (MensajeParada) m;
			if (mp.esDeEmergencia())
				estado = IConstantes.AL_SISTEMA_PARADO;
			else 
				paradaNormal = true;
		} 
		else if (m instanceof MensajeEstado)
		{
			MensajeEstado me = (MensajeEstado) m;
			if (estado==IConstantes.AL_ESPERANDO_TRANSPORTE && me.getEstado()==IConstantes.AM_TRANSPORTANDO_BOTE_A_OTRA_CINTA)
			{
				if (!paradaNormal)
					estado = IConstantes.AL_CINTA_LIBRE;
				else
					estado = IConstantes.AL_SISTEMA_PARADO;				
			}
		} 
	}

	/**
	 * Procedimiento principal del programa. Se invoca para lanzarlo. Si no se indican 
	 * argumentos, muestra por pantalla la ayuda. 
	 * @param args Par�metros de la linea de comandos
	 */
	public static void main(String[] args)
	{
		if (args.length!=2)
		{
			System.out.println("Los argumentos que acepta el programa son:\n");
			System.out.println("\t-Puerto de escucha de mensajes provenientes del automata maestro");
			System.out.println("\t-Donde escucha el automata maestro los mensajes, de la forma host:puerto\n\n");
		}
		else
			new AutomataLlenado(Integer.parseInt(args[0]), args[1]);
	}

}
