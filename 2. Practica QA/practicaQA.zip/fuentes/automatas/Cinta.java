package automatas;
/**
 * Clase que modeliza una cinta de transporte que lleva un bote. Como toda cinta
 * de transporte tiene una longitud y gira a determinada velocidad. Es una clase
 * activa que permite ir alterando cada cierto tiempo la posici�n del bote que lleva
 * encima, dependiendo de su velocidad y si est� o no girando en un momento dado.
 * 
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */
public class Cinta extends Thread
{
	/**
	 * Longitud de la cinta en metros
	 */
	protected int longitud;
	/**
	 * Velocidad de la cinta en metros por minuto
	 */
	protected int velocidad;
	/**
	 * Indica si la cinta est� o no parada
	 */
	protected boolean parada = true;
	/**
	 * Bote que lleva la cinta
	 * @see Bote
	 */
	protected Bote bote = null;
	/**
	 * Veces por segundo que se actualiza la posici�n del bote en la cinta.
	 * Esto no influye en el avance del bote, solamente en la velocidad con
	 * que se actualiza su posici�n.
	 */
	protected int actualizacionesPorSeg = 10; // Cada 100 ms.
	
	/**
	 * Permite acabar el hilo de ejecuci�n. El Thread vivir� mientras
	 * esta propeidad valga true. Para matar el thread y liberar recursos,
	 * deber� llamarse al m�todo <code>finalizarHilo</code> 
	 */
	protected boolean hiloVivo = true;
	
	/**
	 * El constructor necesita la longitud de la cinta y la velocidad en metros por minuto.
	 * Tras guardar los valores arranca el hilo, que se ejecutar� indefinidamente hasta que
	 * el m�todo <code>finalizarHilo</code> sea llamado. 
	 * 
	 * @param longitud Longitud de la cinta en metros
	 * @param velocidad Velocidad de la cinta en metros por minuto
	 * 
	 */
	public Cinta(int longitud, int velocidad)
	{		
		this.bote = null;
		this.longitud=longitud;
		this.velocidad=velocidad;
		start();
	}

	/**
	 * Este m�todo permite quitar el bote de la cinta y dejarla como al principio de
	 * su creaci�n: Detenida y sin bote. 
	 */
	public void reset()
	{
		this.bote = null;
		parada = true;
	}
	
	/**
	 * M�todo de las clases que son gestionadas por un thread. Aqui se
	 * detalla la tarea de la cinta: Si est� el movimiento y lleva bote,
	 * actualizar la posici�n de �ste en base a la velocidad de la cinta. 
	 *
	 */
	public void run()
	{
		while(hiloVivo)
		{
			if (!parada && bote!=null)
			{
				float avance = ((1000f/actualizacionesPorSeg) * (float) velocidad) / 60000f;
				bote.setPosicion(bote.getPosicion()+avance);
			}
			try { Thread.sleep(1000/actualizacionesPorSeg); } catch (Exception e) {}
		}
	}
	
	/**
	 * M�todo que permite poner en funcionamiento la cinta. Si lleva un bote, 
	 * actualizar� la posici�n cada x milisegundos (definidos en la propiedad
	 * <code>actualizacionesPorSeg</code>).
	 *
	 */
	public void arrancar()
	{
		parada = false;
	}
	
	/**
	 * M�todo que permite parar la cinta. Si lleva un bote, deja de actualizar 
	 * la posici�n de �ste.
	 *
	 */
	public void parar()
	{
		parada = true;
	}
	
	/**
	 * M�todo que pone un bote sobre la cinta al principio de �sta.
	 *
	 */
	public void ponerBote()
	{
		bote = new Bote();
	}
	
	/**
	 * M�todo que permite conocer la longitud en metros de la cinta
	 * @return Longitud en metros de la cinta
	 */
	public int getLongitud()
	{
		return longitud;
	}
	
	/**
	 * M�todo que permite obtener el bote que circula por la cinta para preguntar
	 * por la posici�n en que se encuentra.
	 * @return Un objeto Bote
	 * @see Bote
	 */
	public Bote getBote()
	{
		return bote;
	}

	/**
	 * Permite finalizar el hilo de ejecuci�n de esta cinta y liberar recursos. Se
	 * debe llamar antes de poner la referencia de la cinta a null o hacer otra 
	 * instanciacion sobre el mismo puntero.
	 *
	 */
	public void finalizarHilo()
	{
		hiloVivo=false;
	}	
}
