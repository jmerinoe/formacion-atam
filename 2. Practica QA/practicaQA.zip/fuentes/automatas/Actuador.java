package automatas;
/**
 * Clase que modeliza un actuador de las cintas de los aut�matas. Como actuador 
 * se entiende algo que realiza una operaci�n durante ciertos ciclos de reloj.
 * La instancia se inicializa al n�mero de ciclos durante el cual actuar� y
 * luego cada ciclo se llamar� al m�todo actua. En cuanto este m�todo devuelve
 * false, sabremos que ha dejado de atuar y as� habr�n pasado los ciclos determinados.
 * 
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */
public class Actuador
{
	/**
	 * Numero de ciclos durante los cuales actuar�
	 */
	protected int ciclos = -1;
	
	/**
	 * M�todo a llamar en cada ciclo. Cuando devuelve false, el actuador ha
	 * finalizado su cometido
	 *  
	 * @return Si el actuador est� aun funcionando o no.
	 */
	public boolean actua()
	{
		if (ciclos>0)
		{
			ciclos--;
			return true;
		}
		return false;
	}

	/**
	 * M�todo que resetea el contador de ciclos durante los cuales actuar�
	 * @param ciclos Numero de ciclos que actuar�
	 */
	public void inicializa(int ciclos)
	{
		this.ciclos=ciclos;
	}
}
