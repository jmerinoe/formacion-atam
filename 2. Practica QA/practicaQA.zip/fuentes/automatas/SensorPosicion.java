package automatas;
/**
 * Clase que modeliza un sensor de posici�n. Como tiene que implementar
 * <code>ISensor</code>, tiene que tener un m�todo <code>getEstado</code>
 * que recibe la referencia al Bote. Seg�n si el bote est� en la posici�n de
 * este sensor, se activar� o no.
 * 
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 * @see ISensor
 */
public class SensorPosicion implements ISensor
{
	/**
	 * Posici�n del sensor sobre la cinta de transporte
	 */
	protected int posicion;
	
	/**
	 * Al construir un sensor, se le indica la posici�n que ocupa sobre la cinta de
	 * transporte 
	 * @param p Posici�n en metros sobre la cinta de transporte
	 */
	public SensorPosicion(int p)
	{
		this.posicion = p;
	}

	/**
	 * Devuelve true si el bote est� en la zona del sensor con un error de �0.75 metros.
	 * @param b Bote que circula por la cinta y susceptible de estar bajo este sensor.
	 * @return Cierto si el bote se encuentra bajo el sensor.
	 */
	public boolean getEstado(Bote b)
	{
		return b!=null && Math.abs( b.getPosicion() - this.posicion ) <= 0.75f;
	}
	
}
