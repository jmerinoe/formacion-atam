package automatas.maestro;

import java.util.Iterator;
import java.util.List;

import automatas.Automata;

import comun.IConstantes;
import comunicaciones.BuzonEntrada;
import comunicaciones.BuzonSalida;
import comunicaciones.ComunicacionException;
import comunicaciones.Mensaje;
import comunicaciones.MensajeConfig;
import comunicaciones.MensajeEstado;
import comunicaciones.MensajeParada;
/**
 * Clase que modeliza el aut�mata maestro. Tiene un m�todo main para lanzarlo,
 * y cuyos par�metros son el puerto donde escuha y la direcci�n y puerto tanto del
 * scada como de los aut�matas de llenado y taponado. Aqu� va un ejemplo de invocaci�n: <br>
 * <pre>
 * 		$> java automatas.AutomataMaestro 5555 scada.uc3m.es:6777 llenado.uc3m.es:8888 tapado.uc3m.es:9999
 * </pre>
 * Por heredar de <code>Automata</code>, debe implementar el m�todo <code>ciclo</code>,
 * que es donde realizar� las acciones pertinentes cada ciclo de reloj.
 * Para comunicarse tiene un buz�n de entrada y otro de salida. Cada ciclo de reloj lo 
 * que hace es se leen los mensajes del buz�n de entrada para actuar en consecuencia. 
 * 
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 * @see comun.IConstantes
 * @see automatas.Automata
 * @see comunicaciones.BuzonEntrada
 * @see comunicaciones.BuzonSalida
 */
public class AutomataMaestro extends Automata 
{
	/**
	 * Buz�n de salida para enviar mensajes al Scada
	 */
	protected BuzonSalida buzonSalScada = null;
	/**
	 * Buz�n de salida para enviar mensajes al automata de llenado
	 */
    protected BuzonSalida buzonSalAutLlenado = null;
	/**
	 * Buz�n de salida para enviar mensajes al automata de tapado
	 */
    protected BuzonSalida buzonSalAutTaponado = null;
	/**
	 * Buz�n de entrada para leer mensajes de quien sea (scada o esclavos)
	 */
    protected BuzonEntrada buzonEnt = null;
	/**
	 * El aut�mata maestro se encarga del transporte entre cintas del robot. Aqui
	 * guardamos la duraci�n de ese transporte en segundos
	 */
	protected int tiempoTransporteRobot;

	/**
	 * En esta propiedad se indica si el aut�mata maestro se encuentra en estos
	 * momentos transportando el bote entre las cintas con el robot
	 */
	protected boolean transportandoBote = false;
	/**
	 * Esta propiedad indica si lleg� un mensaje del maestro de parada normal.
	 */
	protected boolean paradaNormal=false;
	/**
	 * Esta propiedad indica si lleg� un mensaje del maestro de parada de emergencia.
	 */
	protected boolean paradaEmergencia=false;
	
	/**
	 * Esta propiedad guarda el ultimo estado recibido del automata de llenado
	 */
	protected int ultimoEstadoAutomataLlenado=-1;
	/**
	 * Esta propiedad guarda el ultimo estado recibido del automata de taponado
	 */
	protected int ultimoEstadoAutomataTaponado=-1;
	
	/**
	 * Esta propiedad guarda el n�mero de botes que hay circulando en total por las cintas
	 * (para ver si al solicitar parada normal se puede parar ya o no).
	 */
	protected int botesCirculando = 0;
    
	/**
	 * El constructor se llama desde el m�todo main, al ejecutar la aplicaci�n. Recibe
	 * los datos de d�nde escuchar y d�nde escuchar los dem�s. Luego se inicia el hilo
	 * de ejecuci�n.
	 * @param puerto Puerto donde escuchar� el aut�mata maestro
	 * @param dirScada Direcci�n del scada, de la forma <i>host:puerto</i>
	 * @param dirAutLle Direcci�n del automata de llenado, de la forma <i>host:puerto</i>
	 * @param dirAutTap Direcci�n del automata de tapado, de la forma <i>host:puerto</i>
	 */
	public AutomataMaestro(int puerto, String dirScada, String dirAutLle, String dirAutTap)
	{
		inicializarBuzones(puerto, dirScada, dirAutLle, dirAutTap);
		start();
	}

	/**
	 * M�todo que estamos obligados a implementar por heredar de <code>Automata</code>
	 * y donde se especifica las acciones a realizar en cada ciclo. Este aut�mata siempre
	 * permanecer� a la escucha de mensajes, y procesarlos y actuar en consecuencia ser�
	 * su tarea.
	 */
	protected void ciclo()  
    {
		synchronized(this)
        {
			if (buzonEnt==null)
				return;
			List lstMsg = buzonEnt.getMensajes();
	        for(Iterator it = lstMsg.iterator(); it.hasNext();)
	        {
	        	try
				{
					procesarMensaje((Mensaje) it.next());
				}
				catch (ComunicacionException e)
				{
					System.out.println("Error procesando mensaje:"+e);
					System.exit(-1);
				}
	        }
        }
    }
 
	/**
	 * M�todo que procesa un mensaje recibido por el buz�n de entrada. Dependiendo
	 * del remitente y el contenido, se har� unas u otras acciones, y se comunicar�
	 * con el resto de participantes para coordinar el proceso.
	 * @param m Mensaje recibido por el buz�n de entrada
	 * @exception comunicaciones.ComunicacionException Lanza una excepcion de comunicaci�n
	 * 	          si no se puede enviar alg�n mensaje por los buzones de salida 
	 */
	private void procesarMensaje(Mensaje m) throws ComunicacionException
	{
		if (m.getRemitente()==IConstantes.SCADA)
        {
            if (m instanceof MensajeConfig)
            {
            	paradaNormal=false;
            	paradaEmergencia=false;
            	ultimoEstadoAutomataLlenado=-1;
            	ultimoEstadoAutomataTaponado=-1;
            	transportandoBote = false;
            	botesCirculando=0;
            	// Se lo enviamos a los esclavos, pero antes leemos el ciclo de 
            	// reloj para ajustarlo
            	MensajeConfig mc = (MensajeConfig) m;
            	this.cicloReloj = mc.getConfiguracion().getCicloReloj(); 
            	this.tiempoTransporteRobot = mc.getConfiguracion().getTiempoTransporteEntreCintas();
            	mc.setRemitente(IConstantes.AUTOMATA_MAESTRO);
            	buzonSalAutLlenado.enviarMensaje(mc);
            	buzonSalAutTaponado.enviarMensaje(mc);
            }
            else if (m instanceof MensajeParada)
            {
            	MensajeParada mp = (MensajeParada) m;
            	if ((mp.esNormal() && !paradaNormal) || (mp.esDeEmergencia() && !paradaEmergencia))
				{
            		paradaNormal=mp.esNormal();
            		paradaEmergencia=mp.esDeEmergencia();
            		// Se lo enviamos a los esclavos
            		m.setRemitente(IConstantes.AUTOMATA_MAESTRO);
            		// Al de taponado solo si es de emergencia
            		buzonSalAutLlenado.enviarMensaje(m);
            		if (paradaEmergencia)
            			buzonSalAutTaponado.enviarMensaje(m);
            		if (paradaEmergencia)
            			buzonSalScada.enviarMensaje(new MensajeEstado(IConstantes.AUTOMATA_MAESTRO, IConstantes.AM_SISTEMA_PARADO));
				}
            }
        }
        else 
        {
        	if (m instanceof MensajeEstado)
            {
                MensajeEstado mc = (MensajeEstado) m;
        		if (mc.getRemitente()==IConstantes.AUTOMATA_LLENADO)
            	{
            		if (ultimoEstadoAutomataLlenado!=IConstantes.AL_ANDANDO_VACIO &&
            			mc.getEstado()==IConstantes.AL_ANDANDO_VACIO)
            			botesCirculando++;
            		ultimoEstadoAutomataLlenado = mc.getEstado();
            	}
            	else if (mc.getRemitente()==IConstantes.AUTOMATA_TAPONADO)
            	{
            		if (ultimoEstadoAutomataTaponado!=-1 &&
            				ultimoEstadoAutomataTaponado!=IConstantes.AT_ESPERANDO_BOTE &&
                			mc.getEstado()==IConstantes.AT_ESPERANDO_BOTE)
                			botesCirculando--;
            		ultimoEstadoAutomataTaponado = mc.getEstado();
            	}
            	// Dependiendo del estado que nos comuniquen los esclavos, hacemos unas cosas u otras
            	switch(mc.getEstado())
				{
            		case IConstantes.AL_ESPERANDO_TRANSPORTE:
            			if (ultimoEstadoAutomataTaponado==IConstantes.AT_ESPERANDO_BOTE)
            			{
            				new TransporteDeBote(this.tiempoTransporteRobot);
            				buzonSalAutLlenado.enviarMensaje(new MensajeEstado(IConstantes.AUTOMATA_MAESTRO, IConstantes.AM_TRANSPORTANDO_BOTE_A_OTRA_CINTA));
            				buzonSalScada.enviarMensaje(new MensajeEstado(IConstantes.AUTOMATA_MAESTRO, IConstantes.AM_TRANSPORTANDO_BOTE_A_OTRA_CINTA));
            			}
            			else
            				buzonSalScada.enviarMensaje(new MensajeEstado(IConstantes.AUTOMATA_MAESTRO, IConstantes.AL_ESPERANDO_TRANSPORTE));
            			break;
            		case IConstantes.AL_PARADA_EMERGENCIA_NO_BOTES:
            			paradaEmergencia=true;
            			buzonSalScada.enviarMensaje(new MensajeEstado(IConstantes.AUTOMATA_MAESTRO, IConstantes.AL_PARADA_EMERGENCIA_NO_BOTES));
            			buzonSalAutTaponado.enviarMensaje(new MensajeParada(IConstantes.AUTOMATA_MAESTRO, true, false));
            			break;
            		case IConstantes.AL_PARADA_EMERGENCIA_NO_MERMELADA:
            			paradaEmergencia=true;
            			buzonSalScada.enviarMensaje(new MensajeEstado(IConstantes.AUTOMATA_MAESTRO, IConstantes.AL_PARADA_EMERGENCIA_NO_MERMELADA));
            			buzonSalAutTaponado.enviarMensaje(new MensajeParada(IConstantes.AUTOMATA_MAESTRO, true, false));
            			break;
            		case IConstantes.AT_PARADA_EMERGENCIA_CAJA_BOTES_LLENA:
            			paradaEmergencia=true;
            			buzonSalScada.enviarMensaje(new MensajeEstado(IConstantes.AUTOMATA_MAESTRO, IConstantes.AT_PARADA_EMERGENCIA_CAJA_BOTES_LLENA));
            			buzonSalAutLlenado.enviarMensaje(new MensajeParada(IConstantes.AUTOMATA_MAESTRO, true, false));
            			break;
        			case IConstantes.AT_SISTEMA_PARADO:
                    	if (botesCirculando==0)
                			buzonSalScada.enviarMensaje(new MensajeEstado(IConstantes.AUTOMATA_MAESTRO, IConstantes.AM_SISTEMA_PARADO));
        				break;
        			case IConstantes.AL_SISTEMA_PARADO:
                    	if (botesCirculando==0)
                			buzonSalScada.enviarMensaje(new MensajeEstado(IConstantes.AUTOMATA_MAESTRO, IConstantes.AM_SISTEMA_PARADO));
    					break;
        			case IConstantes.AT_ESPERANDO_BOTE:        				
        				buzonSalScada.enviarMensaje(new MensajeEstado(IConstantes.AUTOMATA_MAESTRO, IConstantes.AT_ESPERANDO_BOTE));
        				break;
        			default:
        				buzonSalScada.enviarMensaje(new MensajeEstado(IConstantes.AUTOMATA_MAESTRO, mc.getEstado()));        				
            			break;
				}         
            } 
        }
	}
	
	/**
	 * Metodo llamado en el constructor que inicializa los buzones para los valores con que
	 * se creo la instancia. Si no se puede crear alguno de los buzones, indica el error por
	 * pantalla y finaliza la aplicaci�n.
	 * @param puerto Puerto donde escuchar� el aut�mata maestro
	 * @param dirScada Direcci�n del scada, de la forma <i>host:puerto</i>
	 * @param dirAutomLlenado Direcci�n del automata de llenado, de la forma <i>host:puerto</i>
	 * @param dirAutomTaponado Direcci�n del automata de tapado, de la forma <i>host:puerto</i>
	 */
	private void inicializarBuzones(int puerto, String dirScada, String dirAutomLlenado, String dirAutomTaponado) 
	{
		String hostScada = dirScada.substring(0, dirScada.indexOf(":"));
		int puertoScada = Integer.parseInt(dirScada.substring(dirScada.indexOf(":")+1));
		String hostAutomLlenado= dirAutomLlenado.substring(0, dirAutomLlenado.indexOf(":"));
		int puertoAutomLlenado = Integer.parseInt(dirAutomLlenado.substring(dirAutomLlenado.indexOf(":")+1));
		String hostAutomTapon= dirAutomTaponado.substring(0, dirAutomTaponado.indexOf(":"));
		int puertoAutomTapon = Integer.parseInt(dirAutomTaponado.substring(dirAutomTaponado.indexOf(":")+1));

		try
		{
			buzonEnt      		= new BuzonEntrada(puerto);
			buzonSalScada 		= new BuzonSalida(hostScada, puertoScada);		
			buzonSalAutLlenado 	= new BuzonSalida(hostAutomLlenado, puertoAutomLlenado);		
			buzonSalAutTaponado = new BuzonSalida(hostAutomTapon, puertoAutomTapon);
		}
		catch(Exception e)
		{
			System.out.println("Error inicializando buzones:"+e);
			System.exit(-1);
		}
	}

	/**
	 * Cuando hay que transportar un bote, un robot se encarga de ello. Cuando el 
	 * transporte del bote finaliza, se realiza una llamada a este m�todo, que lo
	 * que hace es avisar al automata de taponado que ya tiene disponible el bote
	 * en su cinta.
	 *
	 */
	private void finTransporteBote() 
	{
		try
		{
			transportandoBote = false;
			if (!paradaEmergencia)
			{
				Mensaje m = new MensajeEstado(IConstantes.AUTOMATA_MAESTRO, IConstantes.AM_BOTE_TRANSPORTADO); 
				buzonSalScada.enviarMensaje(m);
				buzonSalAutTaponado.enviarMensaje(m);
			}
		}
		catch(Exception e)
		{
			System.out.println("Fallo comunicando el fin del transporte entre cintas:"+e);
			System.exit(-1);
		}
	}

	/**
	 * Procedimiento principal del programa. Se invoca para lanzarlo. Si no se indican 
	 * argumentos, muestra por pantalla la ayuda. 
	 * @param args Par�metros de la linea de comandos
	 */
    public static void main(String[] args) 
    {
    	if (args.length!=4)
		{
			System.out.println("Los argumentos que acepta el programa son:\n");
			System.out.println("\t-Puerto de escucha de mensajes provenientes del otros elementos del sistema");
			System.out.println("\t-Donde escucha el scada los mensajes, de la forma host:puerto\n\n");
			System.out.println("\t-Donde escucha el automata de llenado los mensajes, de la forma host:puerto\n\n");
			System.out.println("\t-Donde escucha el automata de taponado los mensajes, de la forma host:puerto\n\n");
		}
		else
			new AutomataMaestro(Integer.parseInt(args[0]), args[1], args[2], args[3]);
	}

    /**
     * Clase interna activa que simula el tiempo de transporte entre las cintas.
     * Inicia un contador con la duraci�n del transporte del robot. Mientras, y
     * de forma concurrente, el aut�mata sigue leyendo mensajes de entrada y enviado
     * mensajes por los buzones. Al acabar el tiempo, se llama al m�todo 
     * <code>finTransporteBote</code>, en donde se enviar� un mensaje al aut�mata de
     * taponado para indicarle que tiene su bote al principio de la cinta. 
     * 
     */
    class TransporteDeBote extends Thread
	{
    	/**
    	 * Segundo de duraci�n del transporte
    	 */
    	private int segundos; 
    	
    	/**
    	 * Se le indica la duraci�n en segundos del transporte del bote entre cintas
    	 * @param segundos Segundos que dura el transporte de bote entre cintas
    	 */
		public TransporteDeBote(int segundos)
    	{
    		this.segundos = segundos;
			start();
    	}
    	
    	/**
    	 * M�todo del thread que simplemente espera x segundos y luego llama al
    	 * m�todo <code>finTransporteBote</code>.
    	 */
    	public void run()
    	{
    		try { Thread.sleep(segundos*1000); } catch(Exception e) { }
    		finTransporteBote();
    	}
	}

}
