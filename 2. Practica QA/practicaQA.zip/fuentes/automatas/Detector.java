package automatas;

import java.util.Random;
/**
 * Clase que modeliza un detector situado en una cinta. Los detectores se activan
 * con un cierto umbral. El detector, al invocar su m�todo <code>getEstado</code>
 * (que est� obligado a incluir por ser un tipo de sensor e implementar el interfaz
 * <code>ISensor</code>), devolver� true o false dependiendo del umbral y un n�mero
 * aleatorio generado.
 * 
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 * @see ISensor
 */
public class Detector implements ISensor
{
	/**
	 * Constante de clase est�tica que har� de semilla para todas
	 * las instancias de la clase.
	 */
	protected static Random semillaAleatoria = new Random();
	
	/**
	 * Umbral de activaci�n de la instacia.
	 */
	protected int umbral;
	
	/**
	 * Al crear una instancia debe especificarse un valor entre 0 y 100 que 
	 * ser� el umbral de activaci�n.  
	 * @param umbral Valor de activaci�n umbral
	 */
	public Detector(int umbral)
	{
		this.umbral = umbral;
	}
	
	/**
	 * M�todo que se deve implementar por implementar el interfaz <code>ISensor</code>
	 * y que devuelve true o false si el detector se activa o no.
	 * Para ello, genera un n�mero aleatorio entre 0 y 100. Si el n�mero supera
	 * el umbral establecido, se activa
	 * 
	 * @param b Bote que est� bajo el sensor. Todos los sensores deben tener acceso
	 * 			al bote de la cinta para comprobar su posici�n. En el caso de un
	 * 			detector, se le pasa, pero no lo usar para nada. Aunque debe seguir
	 * 			la firma del m�todo, pues implementa el interfaz <code>ISensor</code>
	 * @return Si se activa o no 
	 */
	public boolean getEstado(Bote b)
	{
		return semillaAleatoria.nextInt(101)>=umbral;
	}
	
}
