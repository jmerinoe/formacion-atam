package automatas;
/**
 * Clase que modeliza un aut�mata gen�rico. Como aut�mata que ser�, tendr� un 
 * estado y un ciclo de reloj que le permite ejecutar cada cierto tiempo 
 * los c�lculos y operaciones para saber el nuevo estado al que transitar.
 * Para ello, la clase extiende de Thread, y su m�todo run() lo que hace es llamar
 * cada x milisegundos (los que hayamos decidido que dure su ciclo de reloj), a un
 * m�todo llamado <code>ciclo</code>, que todas las subclases deben implementar.
 * Esta clase es abstracta, debiendo incorporar todas sus subclases el m�todo 
 * indicado anteriormente en su implementaci�n.
 * 
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */

public abstract class Automata extends Thread
{
	/**
	 * Duraci�n en milisegundos del ciclo de reloj del aut�mata
	 */
	protected int cicloReloj=200;
	/**
	 * Estado del aut�mata. Los valores posibles se encuentran en IConstantes
	 * @see comun.IConstantes
	 */
	protected int estado;
	
	/**
	 * El constructor vac�o simplemente resetea el estado del aut�mata.
	 */
	public Automata()
	{
		reset();		
	}
	
	/**
	 * Este m�todo se llama desde el constructor y cuado el programador estime oportuno.
	 * A este nivel est� vac�o para permitir al programador sobreescribirlo en las subclases
	 * con el c�digo que estime oportuno para inicializar su aut�mata.
	 */
	public void reset()
	{
	}
	
	/**
	 * M�todo que tienen todos los Thread para declarar su funcionalidad. En el caso de 
	 * un aut�mata, es ejecutar el m�todo <code>ciclo</code> cada x milisegundos (valor
	 * del ciclo de reloj).
	 */
	public void run()
	{
		while(true)
		{
			ciclo();
			try { Thread.sleep(cicloReloj); } catch(Exception ex) {}
		}
	}
	
	/**
	 * M�todo que ejecutan todos los aut�matas cada x milisegundos (valor
	 * del ciclo de reloj). Se declara abstracto para forzar a las subclases a 
	 * meter aqu� el c�digo que les corresponda.
	 */
	protected abstract void ciclo();

	/**
	 * Permite averiguar el valor del ciclo de reloj
	 * @return Ciclo de reloj del aut�mata en milisegundos
	 */
	public int getCicloReloj()
	{
		return cicloReloj;
	}

	/**
	 * Permite establecer el valor del ciclo de reloj
	 * @param cicloReloj Ciclo de reloj del aut�mata en milisegundos
	 */
	public void setCicloReloj(int cicloReloj)
	{
		this.cicloReloj = cicloReloj;
	}
}

