package automatas;
/**
 * Interfaz que deben implementar todas las clases que quieran tener un
 * comportamiento de sensor. Los sensores necesitan tener una referencia
 * al Bote para ver si est�n en su radio de alcance y poder tomas decisiones
 * con la informaci�n que �ste les aporta.
 * 
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */
public interface ISensor
{
	/**
	 * M�todo que debe implementar todo sensor. En base al bote y su informaci�n
	 * decidir�n si se activan o no.
	 */
	public boolean getEstado(Bote b);

}
