package comunicaciones;
/**
 * Clase que encapsula las excepciones de comunicaciones de la
 * aplicaci�n.
 * 
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */
public class ComunicacionException extends Exception
{
	/**
	 * Constructor que recibe el mensaje de error y la excepcion original
	 * @param string Mensaje de error
	 * @param e Excepci�n original
	 */
	public ComunicacionException(String string, Exception e)
	{
		super(string,e);
	}

}
