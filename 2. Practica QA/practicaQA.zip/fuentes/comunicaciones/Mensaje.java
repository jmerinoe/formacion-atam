package comunicaciones;

import java.io.Serializable;
/**
 * Clase abstracta que ser� el padre en la jerarqu�a de los distintos
 * mensajes que se pueden intercambiar los interlocutores.
 * 
 * @see comun.IConstantes
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */
public abstract class Mensaje implements Serializable
{
	/**
	 * Propiedad que almacena el remitente. Es el valor de una constante en
	 * el interfaz <b>IConstantes</b>. Todo mensaje lleva un remitente.
	 */
	protected int remitente;
	
	public void setRemitente(int remitente)
	{
		this.remitente = remitente;
	}
	
	public int getRemitente()
	{
		return this.remitente;
	}
}
