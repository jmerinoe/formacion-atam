package comunicaciones;

import java.io.Serializable;

import scada.Configuracion;
/**
 * Clase que representa un mensaje que lleva consigo la informaci�n de 
 * configuraci�n.
 * 
 * @see comun.IConstantes
 * @see Mensaje
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */
public class MensajeConfig extends Mensaje implements Serializable
{
	/**
	 * Propiedad que almacena la configuraci�n
	 */
	protected Configuracion config;
	
	/**
	 * Constructor del mensaje
	 * @param remitente Quien es el remitente (constante en IConstantes)
	 * @param config Datos de configuraci�n
	 */
	public MensajeConfig(int remitente, Configuracion config)
	{
		this.remitente = remitente;
		this.config = config;
	}
	
	/**
	 * Obtiene la configuraci�n del mensaje
	 * @return Objeto con la informaci�n de configuraci�n
	 */
	public Configuracion getConfiguracion()
	{
		return config;
	}	
}
