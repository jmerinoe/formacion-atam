package comunicaciones;
/**
 * Clase que representa un mensaje de error.
 * 
 * @see comun.IConstantes
 * @see Mensaje
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */
public class MensajeError extends Mensaje
{
	/**
	 * Propiedad que almacena el mensaje de error que se transporta
	 */
	protected String mensajeError;
	
	/**
	 * Constructor que recibe el remitente y el mensaje de error
	 * @param remitente Quien envia el mensaje (constante en IConstantes)
	 * @param mensaje Texto del mensaje de error
	 */
	public MensajeError(int remitente, String mensaje)
	{
		this.remitente = remitente;
		this.mensajeError = mensaje;
	}
	
	public String getMensaje()
	{
		return this.mensajeError;
	}
	
}

	
