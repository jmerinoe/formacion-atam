package comunicaciones;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

/**
 * Clase que representa un buz�n de salida. Permite enviar mensajes una vez
 * conectado.
 * 
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */
public class BuzonSalida 
{
	/**
	 * Nombre del host con el que conectaremos
	 */
	private String host;
	/**
	 * Puerto del host con el que conectaremos
	 */
	private int puerto;
	/**
	 * Socket de conexion con el host con el que conectaremos
	 */
	private Socket s;
	
	/**
	 * Constructor del buzon
	 * @param host Nombre del host contra el que conectar
	 * @param puerto Puerto del host contra el que conectar 
	 */
	public BuzonSalida(String host, int puerto) 
	{
		this.host = host;
		this.puerto = puerto;
	}
	
	/**
	 * M�todo que permite enviar un mensaje al destinatario
	 * @param m Mensaje a enviar
	 * @throws ComunicacionException Si hay problemas en la comunicaci�n
	 */
	public void enviarMensaje(Mensaje m) throws ComunicacionException
	{
		try
		{
			if (s==null)
				s = new Socket(host, puerto);			
			ObjectOutputStream oos = new ObjectOutputStream(s.getOutputStream());
			oos.writeObject(m);
			oos.flush();
		}
		catch (UnknownHostException e)
		{
			throw new ComunicacionException("No se conoce el host para asociar el buzon:"+e, e);
		}
		catch (IOException e)
		{
			throw new ComunicacionException("Imposible asociar buz�n de salida con "+host+":"+puerto+"\n\n"+e.getMessage(),e);
		}		
	}
}
