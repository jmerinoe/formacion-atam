package comunicaciones;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
/**
 * Clase que representa un buz�n de entrada. Es un thread porque est� constantemente
 * escuchando por el puerto a ver si llegan mensajes.
 * 
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */
public class BuzonEntrada extends Thread
{
	/**
	 * Indica si el hilo est� ejecutando la tarea o no.
	 */
	private boolean ejecutando = true;
	/**
	 * Socket servidor por donde se escuchar�
	 */
	private ServerSocket ss=null;
	/**
	 * Lista de mensajes que se reciben
	 */
	private List mensajes = new ArrayList();
	
	/**
	 * Constructor del buz�n
	 * @param puerto Puerto donde escuchar� la aplicaci�n
	 * @throws IOException Si hay problemas de red o de entrada/salida
	 */
	public BuzonEntrada(int puerto) throws IOException
	{
		this.ss = new ServerSocket(puerto);
		start();
	}
	
	/**
	 * Aqui se hace la tarea del Thread: Simplemente lee del socket. Por cada petici�n
	 * se levanta un hilo que la atiende
	 */
	public void run()
	{
		try
		{
			while(ejecutando)
				new LeerSocket(ss.accept());
		}
		catch (Exception ex)
		{
			System.out.println("Fallo en las comunicaciones:"+ex);				
		}
	}
	
	/**
	 * M�todo que obtiene la lista de mensajes acumulados
	 * @return Lista de mensajes recibidos
	 */
	public synchronized List getMensajes()
	{
		List lm = new ArrayList();
		if (mensajes!=null && mensajes.size()>0)
		{
			lm.addAll(mensajes);
			mensajes.clear();
		}
		return lm;
	}

	/**
	 * Clase interna que se encarga de atender cada petici�n por separado
	 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
	 */
	class LeerSocket extends Thread
	{
		/**
		 * Socket del cual se leer� y enviar� la informaci�n
		 */
		private Socket s;
		
		/**
		 * Constructor que recibe el Socket abierto por el cual se realizar� la comunicaci�n.
		 * @param s
		 */
		public LeerSocket(Socket s)
		{
			this.s=s;
			start();
		}
		
		/**
		 * M�todo principal donde se realiza la tarea: Tras ciertas comprobaciones de 
		 * va leyendo del flujo de entrada los mensajes y se almacenan en la lista.
		 */
		public void run()
		{
			while(s.isBound() && s.isConnected() && !s.isClosed())
			{
				try
				{
					ObjectInputStream ois = new ObjectInputStream(s.getInputStream());
					Mensaje msg = (Mensaje) ois.readObject();
					synchronized(this)
					{
						mensajes.add(msg);
					}
				}
				catch(Exception ex)
				{
					System.out.println("Fallo en las comunicaciones:"+ex);
					try
					{
						s.close();
					}
					catch (IOException e)
					{
						
					}
				}
			}
		}
	}
	
}
