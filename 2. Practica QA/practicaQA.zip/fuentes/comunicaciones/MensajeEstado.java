package comunicaciones;

import java.io.Serializable;
/**
 * Clase que representa un mensaje de estado (los que mandan los automatas en 
 * cada ciclo.
 * 
 * @see comun.IConstantes
 * @see Mensaje
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */
public class MensajeEstado extends Mensaje implements Serializable
{
	/**
	 * Estado que se env�a. Es una constante en IConstantes
	 */
	protected int estado;
	
	/**
	 * Constructor que recibe el remitente (constante en IConstante) y el estado
	 * que �ste quiere transmitir
	 * @param remitente Quien env�a
	 * @param estado Qu� estado env�a
	 */
	public MensajeEstado(int remitente, int estado)
	{
		this.remitente = remitente;
		this.estado = estado;
	}
	
	public int getEstado()
	{
		return estado;
	}
}
