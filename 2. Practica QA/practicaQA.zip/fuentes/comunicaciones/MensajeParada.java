package comunicaciones;

import java.io.Serializable;
/**
 * Clase que representa un mensaje de parada
 * 
 * @see comun.IConstantes
 * @see Mensaje
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */
public class MensajeParada extends Mensaje implements Serializable
{
	/**
	 * Dice si el mensaje es de parada de emergencia.
	 */
	protected boolean emergencia = false;
	/**
	 * Dice si el mensaje es de parada normal.
	 */
	protected boolean normal = false;
	
	/**
	 * En el constructor se especifica quien lo env�a y si es de emergencia o normal.
	 * @param remitente Quien env�a
	 * @param emergencia True si es parada de emergencia
	 * @param normal True si es parada normal
	 */
	public MensajeParada(int remitente, boolean emergencia, boolean normal)
	{
		if (emergencia)
			this.emergencia=true;
		else if (normal)
			this.normal=true;
	}
	
	/**
	 * Dice si este mensaje es de parada de emergencia
	 * @return Cierto si es una parada de emergencia
	 */
	public boolean esDeEmergencia()
	{
		return emergencia;
	}

	/**
	 * Dice si este mensaje es de parada normal
	 * @return Cierto si es una parada normal
	 */
	public boolean esNormal()
	{
		return normal;
	}	
}
