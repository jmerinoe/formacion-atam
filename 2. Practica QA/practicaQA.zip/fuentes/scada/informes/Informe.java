package scada.informes;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
/**
 * Clase que encapsula los datos de los informes y que se encarga tambi�n
 * se leer y de escribir la informaci�n en disco. Todo se guarda en un 
 * archivo de propiedades. 
 * 
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */
public class Informe 
{
	/**
	 * Constante para formatear fechas
	 */
	private static final transient SimpleDateFormat sdf = new SimpleDateFormat("dd-mm-yyyy HH:mm");

	/**
	 * Almacena la fecha de instalaci�n del sistema
	 */
	private Calendar fechaInstalacion=null;
	
	/**
	 * Almacena el numero de botes bien llenados
	 */
	private int bienLlenados=0;
	/**
	 * Almacena el numero de botes mal llenados
	 */
	private int malLlenados=0;
	/**
	 * Almacena el numero de botes mal tapados
	 */	
	private int malTapados=0;

	/**
	 * Almacena el numero de botes bien llenados totales
	 */
	private int bienLlenadosTotales=0;
	/**
	 * Almacena el numero de botes mal llenados totales
	 */
	private int malLlenadosTotales=0;
	/**
	 * Almacena el numero de botes bien tapados totales
	 */
	private int malTapadosTotales=0;
	
	/**
	 * Almacena el numero de paradas de emergencia
	 */
	private int paradasEmergencia=0;
	/**
	 * Almacena el numero de paradas normales
	 */
	private int paradasNormales=0;
	/**
	 * Almacena el numero de arranques
	 */
	private int arranques=0;

	/**
	 * Guarda todos los datos que contiene en un archivo de properties
	 * @param os Flujo de salida donde escribir la informaci�n
	 * @throws IOException Si ocurre algo que no permita guardar la informaci�n
	 */
	public void guardarDatos(OutputStream os) throws IOException
	{
		if (fechaInstalacion==null)
			fechaInstalacion=Calendar.getInstance();
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(os));
		bw.write("##########################################\n");
		bw.write("# Archivo de informes                    #\n");
		bw.write("##########################################\n\n");
		bw.write("fecha_instalacion="+sdf.format(this.fechaInstalacion.getTime())+"\n");
		bw.write("fecha_ultima_actualizacion="+sdf.format(new Date())+"\n\n");
		bw.write("# Numero de botes bien llenados\n");
		bw.write("bienLlenados="+this.bienLlenados+"\n\n");
		bw.write("# Numero de botes mal llenados\n");
		bw.write("malLlenados="+this.malLlenados+"\n\n");
		bw.write("# Numero de botes mal tapados\n");
		bw.write("malTapados="+this.malTapados+"\n\n");
		bw.write("# Numero de botes bien llenados totales\n");
		bw.write("bienLlenadosTotales="+this.bienLlenadosTotales+"\n\n");
		bw.write("# Numero de botes mal llenados totales\n");
		bw.write("malLlenadosTotales="+this.malLlenadosTotales+"\n\n");
		bw.write("# Numero de botes mal tapados totales\n");
		bw.write("malTapadosTotales="+this.malTapadosTotales+"\n\n");
		bw.write("# Los datos que siguen son desde que se instal� el sistema\n\n");
		bw.write("# Numero de paradas de emergencia\n");
		bw.write("paradasEmergencia="+this.paradasEmergencia+"\n\n");
		bw.write("# Numero de paradas normales\n");
		bw.write("paradasNormales="+this.paradasNormales+"\n\n");
		bw.write("# Numero de arranques\n");
		bw.write("arranques="+this.arranques+"\n\n");
		bw.flush();
	}
	
	/**
	 * Carga los datos del archivo de estad�sticas en las propiedades de una instancia 
	 * de esta clase, que es retornada por la funci�n
	 * @param is Flujo de donde se lee la informaci�n
	 * @return Instancia de esta clase con toda la informaci�n le�da.
	 * @throws IOException
	 * @throws ParseException
	 */
	public static Informe cargarDatos(InputStream is) throws IOException, ParseException
	{
		Properties prop = new Properties();
		prop.load(is);
		Informe i = new Informe();
		i.bienLlenados 		  = Integer.parseInt(prop.getProperty("bienLlenados"));
		i.malLlenados 		  = Integer.parseInt(prop.getProperty("malLlenados"));
		i.malTapados 		  = Integer.parseInt(prop.getProperty("malTapados"));
		i.bienLlenadosTotales = Integer.parseInt(prop.getProperty("bienLlenadosTotales"));
		i.malLlenadosTotales  = Integer.parseInt(prop.getProperty("malLlenadosTotales"));
		i.malTapadosTotales   = Integer.parseInt(prop.getProperty("malTapadosTotales"));
		i.paradasEmergencia   = Integer.parseInt(prop.getProperty("paradasEmergencia"));
		i.paradasNormales     = Integer.parseInt(prop.getProperty("paradasNormales"));
		i.arranques		      = Integer.parseInt(prop.getProperty("arranques"));
		
		i.fechaInstalacion = Calendar.getInstance();
		i.fechaInstalacion.setTime(sdf.parse(prop.getProperty("fecha_instalacion")));
		
		return i;
	}
	
	public int getArranques()
	{
		return arranques;
	}
	
	public void setArranques(int arranques)
	{
		this.arranques = arranques;
	}

	public int getBienLlenados()
	{
		return bienLlenados;
	}
	
	public void setBienLlenados(int bienLlenados)
	{
		this.bienLlenados = bienLlenados;
	}
	
	public int getBienLlenadosTotales()
	{
		return bienLlenadosTotales;
	}
	
	public void setBienLlenadosTotales(int bienLlenadosTotales)
	{
		this.bienLlenadosTotales = bienLlenadosTotales;
	}
	
	public int getMalLlenados()
	{
		return malLlenados;
	}
	
	public void setMalLlenados(int malLlenados)
	{
		this.malLlenados = malLlenados;
	}
	
	public int getMalLlenadosTotales()
	{
		return malLlenadosTotales;
	}
	
	public void setMalLlenadosTotales(int malLlenadosTotales)
	{
		this.malLlenadosTotales = malLlenadosTotales;
	}
	
	public int getMalTapados()
	{
		return malTapados;
	}
	
	public void setMalTapados(int malTapados)
	{
		this.malTapados = malTapados;
	}
	
	public int getMalTapadosTotales()
	{
		return malTapadosTotales;
	}

	public void setMalTapadosTotales(int malTapadosTotales)
	{
		this.malTapadosTotales = malTapadosTotales;
	}
	
	public int getParadasEmergencia()
	{
		return paradasEmergencia;
	}
	
	public void setParadasEmergencia(int paradasEmergencia)
	{
		this.paradasEmergencia = paradasEmergencia;
	}
	
	public int getParadasNormales()
	{
		return paradasNormales;
	}
	
	public void setParadasNormales(int paradasNormales)
	{
		this.paradasNormales = paradasNormales;
	}
	
}
