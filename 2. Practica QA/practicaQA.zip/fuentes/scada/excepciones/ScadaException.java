package scada.excepciones;

/**
 * Clase que envuelve cualquier excepci�n. Sirve para englobar todos los errores 
 * en un solo tipo
 * 
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */
public class ScadaException extends Exception
{
	/**
	 * Constructor de la clase
	 * @param string Mensaje a mostrar
	 * @param e Excepci�n que se encapsula
	 */
	public ScadaException(String string, Exception e)
	{
		super(string+":\n"+e.getMessage(),e);
	}

	/**
	 * Constructor de la clase
	 * @param string Mensaje a mostrar
	 */
	public ScadaException(String string)
	{
		super(string);
	}

}
