package scada.excepciones;
/**
 * Clase que envuelve una excepci�n que denota que uno de los valores
 * de configuraci�n no tiene un valor apropiado.
 * 
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */
public class ValorConfiguracionException extends Exception
{
	/**
	 * Constructor de la clase
	 * @param msg Mensaje a mostrar
	 */
	public ValorConfiguracionException(String msg)
	{
		super(msg);
	}
	
}
