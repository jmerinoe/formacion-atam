package scada;

import java.io.Serializable;

/**
 * Clase que encapsula la informaci�n de configuraci�n de la aplicacion.
 * 
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 * @see ManagerConfiguracion
 */

public class Configuracion implements Serializable
{
	/**
	 *  Ciclo de reloj de todos los aut�matas en ms.
	 */ 
	protected int cicloReloj;
	
	/**
	 *  Longitud de la cinta de llenado en metros
	 */ 
	protected int longitudCintaLlenado;

	/**
	 *  Velocidad de la cinta de llenado en metros/minuto
	 */ 
	protected int velocidadCintaLlenado;

	/**
	 *  Tiempo que tarda en llenarse un bote de mermelada en segundos
	 */ 
	protected int tiempoLlenadoBote;
	
	/**
	 *  Umbral sobre el cual se detectan los botes mal llenados, entre 0 y 100
	 */ 
	protected int umbralBotesVacios;

	/**
	 *  Capacidad del dep�sito de botes inicial de la cinta de llenado
	 */ 
	protected int capacidadDepositoBotes;

	/**
	 *  Capacidad de la caja de botes mal llenados
	 */ 
	protected int capacidadCajaMalLlenados;
	
	/**
	 *  Cantidad de mermelada (en n�mero de botes que se podr�an llenar)
	 */ 
	protected int capacidadDepositoMermelada;
	
	/**
	 *  Longitud de la cinta de taponado en metros por minuto
	 */ 
	protected int longitudCintaTaponado;

	/**
	 *  Velocidad de la cinta de taponado 
	 */ 
	protected int velocidadCintaTaponado;
	
	/**
	 *  Umbral sobre el cual se detectan los botes mal tapados, entre 0 y 100
	 */ 
	protected int umbralBotesMalTaponados;
	
	/**
	 *  Capacidad de la caja de embalaje de botes 
	 */ 
	protected int capacidadCajaBotes;
	
	/**
	 *  Tiempo de transporte de bote entre cintas en segundos
	 */ 
	protected int tiempoTransporteEntreCintas;
	

	/**
	 *  Tiempo de transporte de bote a la caja de embalaje en segundos
	 */ 
	protected int tiempoTransporteCajaEmbalaje;
	
	// Usuario que tiene acceso al scada
	/**
	 * Login del usuario con acceso al scada (se almacena en la BD)
	 */
	protected String usuario;

	/**
	 * MD% de la clave del usuario (se almacena en la BD)
	 */
	protected String claveMD5;

	public int getCapacidadCajaEmbalaje()
	{
		return capacidadCajaBotes;
	}

	public void setCapacidadCajaBotes(int capacidadCajaBotes)
	{
		this.capacidadCajaBotes = capacidadCajaBotes;
	}
	
	public int getCapacidadCajaMalLlenados()
	{
		return capacidadCajaMalLlenados;
	}
	
	public void setCapacidadCajaMalLlenados(int capacidadCajaMalLlenados)
	{
		this.capacidadCajaMalLlenados = capacidadCajaMalLlenados;
	}
	
	public int getCapacidadDepositoBotes()
	{
		return capacidadDepositoBotes;
	}
	
	public void setCapacidadDepositoBotes(int capacidadDepositoBotes)
	{
		this.capacidadDepositoBotes = capacidadDepositoBotes;
	}
	
	public int getCapacidadDepositoMermelada()
	{
		return capacidadDepositoMermelada;
	}
	
	public void setCapacidadDepositoMermelada(int capacidadDepositoMermelada)
	{
		this.capacidadDepositoMermelada = capacidadDepositoMermelada;
	}

	public int getCicloReloj()
	{
		return cicloReloj;
	}

	public void setCicloReloj(int cicloReloj)
	{
		this.cicloReloj = cicloReloj;
	}
	
	public int getLongitudCintaLlenado()
	{
		return longitudCintaLlenado;
	}
	
	public void setLongitudCintaLlenado(int longitudCintaLlenado)
	{
		this.longitudCintaLlenado = longitudCintaLlenado;
	}
	
	public int getLongitudCintaTaponado()
	{
		return longitudCintaTaponado;
	}
	
	public void setLongitudCintaTaponado(int longitudCintaTaponado)
	{
		this.longitudCintaTaponado = longitudCintaTaponado;
	}
	
	public int getTiempoLlenadoBote()
	{
		return tiempoLlenadoBote;
	}
	
	public void setTiempoLlenadoBote(int tiempoLlenadoBote)
	{
		this.tiempoLlenadoBote = tiempoLlenadoBote;
	}
	
	public int getTiempoTransporteCajaEmbalaje()
	{
		return tiempoTransporteCajaEmbalaje;
	}
	
	public void setTiempoTransporteCajaEmbalaje(int tiempoTransporteCajaEmbalaje)
	{
		this.tiempoTransporteCajaEmbalaje = tiempoTransporteCajaEmbalaje;
	}
	
	public int getTiempoTransporteEntreCintas()
	{
		return tiempoTransporteEntreCintas;
	}
	
	public void setTiempoTransporteEntreCintas(int tiempoTransporteEntreCintas)
	{
		this.tiempoTransporteEntreCintas = tiempoTransporteEntreCintas;
	}
	
	public int getUmbralBotesMalTaponados()
	{
		return umbralBotesMalTaponados;
	}
	
	public void setUmbralBotesMalTaponados(int umbralBotesMalTaponados)
	{
		this.umbralBotesMalTaponados = umbralBotesMalTaponados;
	}
	
	public int getUmbralBotesVacios()
	{
		return umbralBotesVacios;
	}
	
	public void setUmbralBotesVacios(int umbralBotesVacios)
	{
		this.umbralBotesVacios = umbralBotesVacios;
	}
	
	public int getVelocidadCintaLlenado()
	{
		return velocidadCintaLlenado;
	}
	
	public void setVelocidadCintaLlenado(int velocidadCintaLlenado)
	{
		this.velocidadCintaLlenado = velocidadCintaLlenado;
	}
	
	public int getVelocidadCintaTaponado()
	{
		return velocidadCintaTaponado;
	}
	
	public void setVelocidadCintaTaponado(int velocidadCintaTaponado)
	{
		this.velocidadCintaTaponado = velocidadCintaTaponado;
	}
		
	public String getClaveMD5() 
	{
		return claveMD5;
	}
	
	public void setClaveMD5(String claveMD5) 
	{
		this.claveMD5 = claveMD5;
	}
	
	public String getUsuario() 
	{
		return usuario;
	}
	
	public void setUsuario(String usuario) 
	{
		this.usuario = usuario;
	}
}
