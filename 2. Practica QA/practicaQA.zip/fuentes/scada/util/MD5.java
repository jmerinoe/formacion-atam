package scada.util;

import java.security.MessageDigest;

/**
 * Clase que permite generar y comprobar la firma MD5 de cualquier texto
 * 
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */
public class MD5 
{
	/**
	 * Propiedad de clase que es la instancia que se encarga de hacer los c�lculos. 
	 */
	private static MessageDigest md5;
	
	static
	{
		try 
		{
			MD5.md5 = MessageDigest.getInstance("MD5");
		} 
		catch (Exception e) 
		{
			System.out.println(e.toString());
			e.printStackTrace();
		}
	}

	/*
	 * No se permite crear instancias de la clase, s�lo llamar
	 * a sus m�todos est�ticos.
	 */
	private MD5()
	{		
	}
	
	/**
	 * M�todo principal que devuelve el MD5 del texto que se le pasa
	 * @param inStr Texto oara el cual se quiere calcular el MD5
	 * @return Resultado de aplicar el MD5 al texto de entrada
	 */
	public static String calcular(String inStr) 
	{
		char[] charArray = inStr.toCharArray();
		byte[] byteArray = new byte[charArray.length];
		for (int i = 0; i < charArray.length; i++)
			byteArray[i] = (byte) charArray[i];
		byte[] md5Bytes = MD5.md5.digest(byteArray);
		StringBuffer hexValue = new StringBuffer();
		for (int i = 0; i < md5Bytes.length; i++) 
		{
			int val = ((int) md5Bytes[i]) & 0xff;
			if (val < 16)
				hexValue.append("0");
			hexValue.append(Integer.toHexString(val));
		}
		return hexValue.toString();
	}
	
	/**
	 * Permite la ejecuci�n de esta clase en linea de comandos para obtener
	 * el MD5 de lo que se le pasa por par�metro.
	 * @param s Parametros desde la linea de comandos.
	 */
	public static void main(String s[])
	{
		if (s.length==1)
		{
			System.out.println(calcular(s[0]));
		}	
	}
}

