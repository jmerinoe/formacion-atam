package scada;

import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;

import scada.excepciones.ScadaException;

/**
 * Clase que se encarga de gestionar los datos que majena la aplicaci�n.
 * Se encargar de leer/escribir en un archivo de properties todos los par�metros
 * relacionados con la aplicaci�n. Estos par�metros se encapsulan para un mejor
 * acceso en una instancia de la clase 'Configuracion'.
 * Los datos se leen de un archivo llamado <b>basedatos.properties</b>, que
 * debe estar en el classpath de la aplicaci�n
 * 
 * @see Configuracion
 * 
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */
public class ManagerConfiguracion  
{
	/**
	 * M�todo que se encarga de grabar a disco la configuraci�n que recibe
	 * por par�metro.
	 * @param conf Objecto con los datos de configuraci�n
	 * @throws ScadaException Si no se puede grabar el archivo
	 */
    public static void salvarConfiguracion(Configuracion conf, String archivo) throws ScadaException 
    {
		StringBuffer sb = new StringBuffer("# Archivo de configuracion\n\n");
		sb.append("ciclo.reloj="+conf.getCicloReloj()+"\n\n");

		sb.append("automatallenado.long_cinta="+conf.getLongitudCintaLlenado()+"\n");
		sb.append("automatallenado.vel_cinta="+conf.getVelocidadCintaLlenado()+"\n");
		sb.append("automatallenado.tiempo_llenado="+conf.getTiempoLlenadoBote()+"\n");
		sb.append("automatallenado.umbral_vacios="+conf.getUmbralBotesVacios()+"\n");
		sb.append("automatallenado.cap_botes="+conf.getCapacidadDepositoBotes()+"\n");
		sb.append("automatallenado.cap_mal_llenados="+conf.getCapacidadCajaMalLlenados()+"\n");
		sb.append("automatallenado.cap_mermelada="+conf.getCapacidadDepositoMermelada()+"\n\n");

		sb.append("automatataponado.long_cinta="+conf.getLongitudCintaTaponado()+"\n");
		sb.append("automatataponado.vel_cinta="+conf.getVelocidadCintaTaponado()+"\n");
		sb.append("automatataponado.umbral_mal_tapados="+conf.getUmbralBotesMalTaponados()+"\n");
		sb.append("automatataponado.cap_botes="+conf.getCapacidadCajaEmbalaje()+"\n\n");

		sb.append("robot1.tiempo_transporte="+conf.getTiempoTransporteEntreCintas()+"\n");
		sb.append("robot2.tiempo_transporte="+conf.getTiempoTransporteCajaEmbalaje()+"\n\n");
		
		sb.append("# Usuario de acceso al scada con el md5 de su clave\n\n");
		sb.append("usuario="+conf.getUsuario()+"\n");
		sb.append("clave="+conf.getClaveMD5()+"\n\n");
		
		try
		{
			FileWriter fw = new FileWriter(archivo);
			fw.write(sb.toString());
			fw.close();	
		}
		catch (IOException e)
		{
			throw new ScadaException("Error al grabar el archivo de base de datos", e);
		}		
    }
    
	/**
	 * M�todo que se encarga de leer de disco la configuraci�n.
	 * @param archivo Archivo de properties con la informaci�n
	 * @return Objecto con los datos de configuraci�n
	 * @throws ScadaException Si no se puede leer el archivo
	 */
    public static Configuracion cargarConfiguracion(String archivo) throws ScadaException 
    {
		Properties prop = new Properties();
		try
		{
			prop.load(new FileInputStream(archivo));
		}
		catch (Exception e)
		{
			throw new ScadaException("No se puede leer el archivo de base de datos", e);
		}
		Configuracion conf = new Configuracion();

		conf.setCicloReloj(ManagerConfiguracion.getPropiedadComoNumero(prop,"ciclo.reloj"));

		conf.setLongitudCintaLlenado(ManagerConfiguracion.getPropiedadComoNumero(prop,"automatallenado.long_cinta"));
		conf.setVelocidadCintaLlenado(ManagerConfiguracion.getPropiedadComoNumero(prop,"automatallenado.vel_cinta"));
		conf.setTiempoLlenadoBote(ManagerConfiguracion.getPropiedadComoNumero(prop,"automatallenado.tiempo_llenado"));
		conf.setUmbralBotesVacios(ManagerConfiguracion.getPropiedadComoNumero(prop,"automatallenado.umbral_vacios"));
		conf.setCapacidadDepositoBotes(ManagerConfiguracion.getPropiedadComoNumero(prop,"automatallenado.cap_botes"));
		conf.setCapacidadCajaMalLlenados(ManagerConfiguracion.getPropiedadComoNumero(prop,"automatallenado.cap_mal_llenados"));
		conf.setCapacidadDepositoMermelada(ManagerConfiguracion.getPropiedadComoNumero(prop,"automatallenado.cap_mermelada"));

		conf.setLongitudCintaTaponado(ManagerConfiguracion.getPropiedadComoNumero(prop,"automatataponado.long_cinta"));
		conf.setVelocidadCintaTaponado(ManagerConfiguracion.getPropiedadComoNumero(prop,"automatataponado.vel_cinta"));
		conf.setUmbralBotesMalTaponados(ManagerConfiguracion.getPropiedadComoNumero(prop,"automatataponado.umbral_mal_tapados"));
		conf.setCapacidadCajaBotes(ManagerConfiguracion.getPropiedadComoNumero(prop,"automatataponado.cap_botes"));

		conf.setTiempoTransporteEntreCintas(ManagerConfiguracion.getPropiedadComoNumero(prop,"robot1.tiempo_transporte"));
		conf.setTiempoTransporteCajaEmbalaje(ManagerConfiguracion.getPropiedadComoNumero(prop,"robot2.tiempo_transporte"));

		conf.setUsuario(prop.getProperty("usuario"));
		conf.setClaveMD5(prop.getProperty("clave"));

        return conf;
    }

    /**
	 * M�todo privado de ayuda que lee de un objeto Properties un valor y lo
	 * devuelve como entero.
	 * 
	 * @param prop Colecci�n de propiedades
	 * @param nombre Nombre de la propiedad a recuperar
	 * @throws ScadaException Si no se encuentra la propiedad o esta no es num�rica
	 */
    private static int getPropiedadComoNumero(Properties prop, String nombre) throws ScadaException
    {
    	String str = prop.getProperty(nombre);
    	if (str==null)
    		throw new ScadaException("El valor '"+nombre+"' de la base de datos no se encuentra");
    	else
    	{
    		try
			{
    			return Integer.parseInt(str);
			}
    		catch(Exception e)
			{
    			throw new ScadaException("El valor '"+nombre+"' de la base de datos no tiene un valor num�rico apropiado");
			}
    	}
    }
    
}

