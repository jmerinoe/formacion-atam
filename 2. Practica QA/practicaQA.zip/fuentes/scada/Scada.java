package scada;

import java.awt.BorderLayout;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import scada.excepciones.ScadaException;
import scada.informes.Informe;
import scada.ui.ConfigDialog;
import scada.ui.ControlPanel;
import scada.ui.InformesDialog;
import scada.ui.LoginDialog;
import scada.ui.SimuladorPanel;
import scada.util.MD5;

import comun.IConstantes;
import comunicaciones.BuzonEntrada;
import comunicaciones.BuzonSalida;
import comunicaciones.ComunicacionException;
import comunicaciones.Mensaje;
import comunicaciones.MensajeConfig;
import comunicaciones.MensajeError;
import comunicaciones.MensajeEstado;
import comunicaciones.MensajeParada;

/**
 * Clase que hereda de JFrame y que ser� la aplicaci�n principal del Scada.
 * Se encarga de mostrar por el interfaz de usuario lo que va ocurriendo
 * con lo aut�matas, y que le es comunicado por el aut�mata maestro v�a
 * buzones TCP.
 * 
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */
public class Scada extends JFrame implements Runnable 
{
	/**
	 * Panel independiente donde transcurre la simulaci�n animada
	 */
	protected SimuladorPanel panelSimulacion = null;
	/**
	 * Panel independiente para controlar la aplicaci�n
	 */
	protected ControlPanel panelControl = null;

	/**
	 * Datos de configuraci�n leidos de la BD
	 */
	protected Configuracion config = null;
	
	/**
	 * Nombre del archivo de base de datos
	 */
	protected String archivoBD;
	/**
	 * Buzon de entrada por donde se reciben mensajes del aut�mata maestro
	 */
	protected BuzonEntrada buz_ent = null;
	/**
	 * Buzon de salida por donde se envian mensajes al aut�mata maestro
	 */
	protected BuzonSalida buz_sal = null;
	
	/**
	 * Esta propiedad almacena si el usuario pulso el bot�n de parada de
	 * emergencia y aun no respondi� el aut�mata maestro
	 */
	private boolean pendienteDeParadaEmergencia = false;

	/**
	 * Esta propiedad almacena si el usuario pulso el bot�n de parada normal
	 */
	private boolean pendienteDeParadaNormal = false;

	/**
	 * Indica si el automata de llenado nos consta como parado
	 */
	private boolean automataLlenadoParado = true;

	/**
	 * Indica si el automata de taponado nos consta como parado
	 */
	private boolean automataTapadoParado = true;
	
	/**
	 * Indica si estamos o no escuchando mensajes
	 */
	private boolean escucharMensajes = false;
	
	/**
	 * Contabiliza los botes bien llenados de la �ltima tanda
	 */
	private int numBotesBienLlenadosUltTanda = 0;
	/**
	 * Contabiliza los botes mal llenados de la �ltima tanda
	 */
	private int numBotesMalLlenadosUltTanda = 0;
	/**
	 * Contabiliza los botes mal tapados de la �ltima tanda
	 */
	private int numBotesMalTapadosUltTanda = 0;

	/**
	 * Constante que nos dice donde guardaremos el archivo de estad�sticas
	 */
	private static final String ARCHIVO_ESTADISTICAS = "estadisticas.properties";
	/**
	 * Instancia que almanena la informaci�n estad�stica
	 */
	private Informe estadisticas = null;
	
	/**
	 * Constructor de la aplicaci�n que recibe d�nde est� el archivo de la base de datos,
	 * en qu� puerto escucha y la direcci�n del aut�mata maestro.
	 * Lo primero que hace es mostrar la pantalla de login. Si en esta pantalla no se
	 * consigue hacer login, la aplicaci�n acaba. Si no, se inicializan los buzones, se
	 * carga la configuraci�n de la BD y si las estad�sticas no existen se crean. Luego
	 * se inicializa el interfaz de usuario con la funcion crearGUI(). 
	 * 
	 * @param database Archivo de base de datos
	 * @param puerto
	 * @param dirAutomMaestro
	 */
	public Scada(String database, int puerto, String dirAutomMaestro)
	{
		try
		{
			// Cargamos la base de datos e intentamos conectar con el autom. maestro
			this.archivoBD = database;
			this.config = ManagerConfiguracion.cargarConfiguracion(database);
			// Pedimos el login del usuario. Si no acierta, ni seguimos
			LoginDialog login = new LoginDialog(this);
			centrarVentana(login);
			login.setVisible(true);
			login.setModal(true);
			// Inicializamos los buzones
			inicializarBuzones(puerto, dirAutomMaestro);
			try
			{
				File f = new File(ARCHIVO_ESTADISTICAS);
				if (!f.exists())
				{
					estadisticas = new Informe();
					guardarEstadisticas();
				}
				else
				{
					estadisticas = Informe.cargarDatos(new FileInputStream(ARCHIVO_ESTADISTICAS));
				}
			}
			catch (Exception e)
			{
				JOptionPane.showMessageDialog(null, "No se puede crear archivo para guardar estadisticas:"+e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				System.exit(-2);
			}
			crearGUI();
		}
		catch(ScadaException ex)
		{
			JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
			System.exit(-1);				
		}
	}
	
	/**
	 * Funci�n que arranca el hilo que da comienzo a la escucha de mensajes. 
	 */
	private void espezarEscuchaMensajes()
	{
		escucharMensajes=true;
		Thread hilo = new Thread(this);
		hilo.start();
	}
	
	/**
	 * M�todo que se encarga de crear y colocar los componentes gr�ficos de la
	 * aplicaci�n.
	 */
	private void crearGUI()
	{
		// Inicializamos el interfazs
		this.setTitle("C�lula de fabricaci�n flexible");		
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.setSize(800,650);
		this.getContentPane().setLayout(new BorderLayout());
		panelSimulacion = new SimuladorPanel(this);
		panelControl = new ControlPanel(this);
		this.getContentPane().add(panelSimulacion, BorderLayout.CENTER);
		this.getContentPane().add(panelControl, BorderLayout.SOUTH);
		this.setVisible(true);
		this.addWindowListener(new WindowAdapter(){ public void windowClosing(WindowEvent e) { System.exit(0);}});
		centrarVentana(this);
	}
	
	/**
	 * M�todo que inicializa los buzones de entrada y salida que se conectan
	 * al aut�mata maestro. 
	 * 
	 * @param puerto Puerto donde escuchar� el scada
	 * @param dirAutomMaestro Direcci�n del aut�mata maestro de la forma host:puerto
	 * @exception scada.excepciones.ScadaException Lanza una excepcion si hay problemas
	 * 			  a la hora de crear los sockets. 
	 */
	private void inicializarBuzones(int puerto, String dirAutomMaestro) throws ScadaException
	{
		String hostMaestro = dirAutomMaestro.substring(0, dirAutomMaestro.indexOf(":"));
		int puertoMaestro = Integer.parseInt(dirAutomMaestro.substring(dirAutomMaestro.indexOf(":")+1));
		try
		{
			buz_ent = new BuzonEntrada(puerto);
			buz_sal = new BuzonSalida(hostMaestro, puertoMaestro);
		}
		catch(Exception ex)
		{
			throw new ScadaException("Error creando buzones:"+ex);
		}
	}
	
	/**
	 * Devuelve la referencia al objeto que contiene los datos de configuraci�n
	 * @return Objeto que contiene los datos de configuraci�n
	 */
	public Configuracion getConfiguracion()
	{
		return config;
	}

	/**
	 * Aqui se pone la acci�n a realizar cuando el usuario pulsa el boton de informes
	 */
	public void botonInformes()
	{
		// Mostramos el dialogo
		InformesDialog d = new InformesDialog(this, estadisticas);
		centrarVentana(d);
		d.setModal(true);
		d.setVisible(true);
	}
	
	/**
	 * Aqui se pone la acci�n a realizar cuando el usuario pulsa el boton 
	 * de parada de emergencia
	 */
	public void botonParadaEmergenciaUsuarioPulsado()
	{
		try
		{
			buz_sal.enviarMensaje(new MensajeParada(IConstantes.SCADA, true, false));
			pendienteDeParadaEmergencia=true;
		}
		catch (ComunicacionException e)
		{
			JOptionPane.showMessageDialog(null, "Error comunicando la parada de emergencia al automata maestro:\n"+e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
			pendienteDeParadaEmergencia=false;
		}
	}
	
	/**
	 * Aqui se pone la acci�n a realizar cuando el usuario pulsa el boton 
	 * de parada normal
	 */
	public void botonParadaNormalUsuarioPulsado()
	{
		try
		{
			buz_sal.enviarMensaje(new MensajeParada(IConstantes.SCADA, false, true));
			pendienteDeParadaNormal=true;
			panelControl.habilitarBotonParadaNormal(false);
		}
		catch (ComunicacionException e)
		{
			JOptionPane.showMessageDialog(null, "Error comunicando la parada normal al automata maestro:\n"+e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
			pendienteDeParadaNormal=false;
		}
	}
	
	/**
	 * Aqui se pone la acci�n a realizar cuando el usuario pulsa el boton 
	 * de configuraci�n 
	 */	
	public void botonConfigurar()
	{
		try
		{
			ConfigDialog cd = new ConfigDialog(this);
			centrarVentana(cd);
			cd.setModal(true);
			cd.setVisible(true);
			// Una vez cerrado el dialogo (que es modal), recargamos la
			// configuraci�n por si hubiese salvado.
			config = ManagerConfiguracion.cargarConfiguracion(this.archivoBD);
		}
		catch (ScadaException e)
		{
			JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);	
		}
	}

	/**
	 * Aqui se pone la acci�n a realizar cuando el usuario pulsa el boton 
	 * de arrancar el sistema 
	 */	
	public void botonArrancarPulsado()
	{
		try
		{
			panelSimulacion.inicializar();
			// Ponemos los contadores a 0
			numBotesBienLlenadosUltTanda = 0;
			numBotesMalLlenadosUltTanda = 0;
			numBotesMalTapadosUltTanda = 0;
			// Al arrancar enviamos la configuracion al maestro
			buz_sal.enviarMensaje(new MensajeConfig(IConstantes.SCADA, config));
			panelControl.habilitarBotonParadaNormal(true);
			panelControl.habilitarBotonParadaEmergencia(true);
			panelControl.habilitarBotonConfiguracion(false);
			panelControl.habilitarBotonArrancar(false);
			panelControl.habilitarBotonInforme(false);
			automataLlenadoParado = false;
			automataTapadoParado = false;
			pendienteDeParadaEmergencia = false;
			pendienteDeParadaNormal = false;
			automataLlenadoParado = true;
			automataTapadoParado = true;
			escucharMensajes = false;
			// Nos ponemos a escuchar mensajes
			espezarEscuchaMensajes();
			// Grabamos un arranque m�s para estadisticas
			estadisticas.setArranques(estadisticas.getArranques()+1);
			guardarEstadisticas();
		}
		catch (ComunicacionException e)
		{
			JOptionPane.showMessageDialog(null, "Error comunicando con el automata maestro:\n"+e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		}
	}

	/** 
	 * Metodo run() controlado por un hilo. La tarea que hace aqui
	 * el Scada es estar constantemente, en cada ciclo de reloj, leyendo
	 * los mensajes que env�a el automata maestro y procesarlos. 
	 */
	public void run()
	{
		while(escucharMensajes)
		{
			if (buz_ent!=null)
			{
				// Leemos del buzon de entrada los mensajes
				List lst = buz_ent.getMensajes();
				for(int x=0;escucharMensajes && lst!=null && x<lst.size();x++)
					procesarMensaje((Mensaje) lst.get(x));
			}
			try { Thread.sleep(config.getCicloReloj()); } catch(Exception ex) {}
		}
	}
	
	/**
	 * Aqui se hace lo conveniente cuando hay una parada de emergencia.
	 * @param msg Mensaje a mostrar por pantalla y se supone es el motivo de la parada
	 */		
	private void paradaEmergencia(String msg)
	{
		pendienteDeParadaEmergencia=false;
		escucharMensajes=false;
		automataLlenadoParado=true;
		automataTapadoParado=true;
		panelSimulacion.pararTodo();
		panelControl.habilitarBotonParadaNormal(false);
		panelControl.habilitarBotonParadaEmergencia(false);
		panelControl.habilitarBotonArrancar(false);
		panelControl.habilitarBotonConfiguracion(true);
		panelControl.habilitarBotonArrancar(true);
		panelControl.habilitarBotonInforme(true);
		// Guardamos las estadisticas
		estadisticas.setParadasEmergencia(estadisticas.getParadasEmergencia()+1);
		guardarEstadisticas();
		JOptionPane.showMessageDialog(this, msg, "Aviso", JOptionPane.WARNING_MESSAGE);		
	}

	/**
	 * Aqui se hace lo conveniente cuando hay una parada normal.
	 * @param msg Mensaje a mostrar por pantalla 
	 */		
	private void paradaNormal(String msg)
	{
		pendienteDeParadaNormal=false;
		escucharMensajes=false;
		automataLlenadoParado=true;
		automataTapadoParado=true;
		panelSimulacion.pararTodo();
		panelControl.habilitarBotonParadaNormal(false);
		panelControl.habilitarBotonParadaEmergencia(false);
		panelControl.habilitarBotonConfiguracion(true);
		panelControl.habilitarBotonArrancar(true);
		panelControl.habilitarBotonInforme(true);
		// Guardamos las estadisticas
		estadisticas.setParadasNormales(estadisticas.getParadasNormales()+1);
		guardarEstadisticas();
		JOptionPane.showMessageDialog(this, msg, "Aviso", JOptionPane.WARNING_MESSAGE);		
	}

	/**
	 * En este m�todo se procesa un mensaje llegado del automata maestro.
	 * Dependiendo del tipo de mensaje recibido, y de su contenido, se 
	 * realiza una accion u otra
	 */
	private void procesarMensaje(Mensaje m)
	{
		// Si es un mensaje de error, lo mostramos por pantalla
		// y cancelamos la ejecuci�n
		if (m instanceof MensajeError)
		{
			MensajeError e = (MensajeError) m;
			JOptionPane.showMessageDialog(this,e.getMensaje(), "Error", JOptionPane.ERROR_MESSAGE);
			panelControl.habilitarBotonParadaNormal(false);
			panelControl.habilitarBotonParadaEmergencia(false);
			panelControl.habilitarBotonConfiguracion(true);
			panelControl.habilitarBotonArrancar(true);
			panelControl.habilitarBotonInforme(true);
		}
		else if (m instanceof MensajeEstado)
		{
			switch(((MensajeEstado)m).getEstado())
			{
				case IConstantes.AL_PARADA_EMERGENCIA_NO_BOTES:
					panelSimulacion.depositoBotesParado();
					paradaEmergencia("Parada de emergencia: No hay botes");
					break;
				case IConstantes.AL_PARADA_EMERGENCIA_NO_MERMELADA:
					panelSimulacion.llenadorMermeladaParado();
					paradaEmergencia("Parada de emergencia: No hay mermelada");
					break;
				case IConstantes.AL_PARADA_EMERGENCIA_CAJA_BOTES_LLENA:
					panelSimulacion.cajaBotesMalTapadosLlena();
					paradaEmergencia("Parada de emergencia: Caja de botes mal llenados repleta");
					break;
				case IConstantes.AT_PARADA_EMERGENCIA_CAJA_BOTES_LLENA:
					panelSimulacion.cajaEmbalajeLlena();
					paradaEmergencia("Parada de emergencia: La caja de embalaje esta llena");
					break;
				case IConstantes.AM_SISTEMA_PARADO:
					if (pendienteDeParadaEmergencia)
						paradaEmergencia("Parada de emergencia del usuario");
					else if (pendienteDeParadaNormal)
						paradaNormal("Parada normal del usuario");
					break;
				case IConstantes.AL_SACANDO_BOTE:
					panelSimulacion.sacandoNuevoBote();
					break;
				case IConstantes.AL_ANDANDO_VACIO:
					panelSimulacion.boteAndandoVacio();
					break;
				case IConstantes.AL_ANDANDO_LLENO:
					panelSimulacion.boteAndandoLleno();
					break;
				case IConstantes.AL_ANDANDO_LLENO_DETECTADO:
					panelSimulacion.boteAndandoLleno();
					break;
				case IConstantes.AL_PASA_POR_DETECTOR_LLENADO:
					panelSimulacion.pasaPorDetectorLlenado();
					break;
				case IConstantes.AL_LLENANDO:
					panelSimulacion.cargarMermelada();
					break;
				case IConstantes.AL_EXPULSANDO_BOTE:
					boteMalLlenado();
					panelSimulacion.expulsarBoteCinta1();
					break;
				case IConstantes.AL_ESPERANDO_TRANSPORTE:
					panelSimulacion.esperandoTransporteEntreCintas();
					break;
				case IConstantes.AL_CINTA_LIBRE:
					panelSimulacion.quitarBoteCinta1();
					break;
				case IConstantes.AM_TRANSPORTANDO_BOTE_A_OTRA_CINTA:
					panelSimulacion.quitarBoteCinta1();
					panelSimulacion.transportarBote();
				break;
				case IConstantes.AM_BOTE_TRANSPORTADO:
					panelSimulacion.finTransporteEntreCintas();
					break;
				case IConstantes.AT_ANDANDO_SIN_TAPA:
					panelSimulacion.boteCintaTapadoAndandoSinTapa();
					break;
				case IConstantes.AT_TAPANDO:
					panelSimulacion.tapandoBote();
					break;
				case IConstantes.AT_ANDANDO_TAPADO:
					panelSimulacion.boteCintaTapadoAndandoConTapa();
					break;
				case IConstantes.AT_ETIQUETANDO:
					panelSimulacion.etiquetandoBote();
					break;
				case IConstantes.AT_ANDANDO_ETIQUETADO:
					panelSimulacion.boteCintaTapadoAndandoConEtiqueta();
					break;
				case IConstantes.AT_PASA_POR_DETECTOR_TAPADO:
					panelSimulacion.boteCintaTapadoPasaPorDetectorTapado();
					break;
				case IConstantes.AT_EXPULSANDO_BOTE:
					boteMalTapado();
					panelSimulacion.expulsarBoteCinta2();
					break;
				case IConstantes.AT_ANDANDO_ETIQUETADO_DETECTADO:						
					panelSimulacion.boteCintaTapadoAndandoConEtiqueta();
					break;
				case IConstantes.AT_TRANSPORTANDO:
					panelSimulacion.transportandoBoteCajaEmbalaje();
					break;
				case IConstantes.AT_BOTE_EN_CAJA_EMBALAJE:
					boteTerminado();
					break;
				case IConstantes.AT_ESPERANDO_BOTE:
					if (!automataLlenadoParado)
						panelSimulacion.esperandoBoteCintaTapado();
					else 
						automataTapadoParado=true;
					break;
				case IConstantes.AT_SISTEMA_PARADO:
					panelSimulacion.esperandoBoteCintaTapado();				
					break;
			}
		}
	}
	
	/**
	 * M�todo que se encarga de guardar las estad�sticas que se almacenan en 
	 * la propiedad 'estadisticas' a disco.
	 */
	private synchronized void guardarEstadisticas()
	{
		try
		{
			estadisticas.guardarDatos(new FileOutputStream(ARCHIVO_ESTADISTICAS));
		}
		catch (Exception e)
		{
			JOptionPane.showMessageDialog(null, "Error grabando estadisticas:\n"+e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	
	/**
	 * Este m�todo es llamado al recibir el mensaje desde el maestro de que el bote
	 * se expulsa de la cinta 1 por estar mal lleno. Se cambian las estadisticas
	 * y se graban.
	 */
	private void boteMalLlenado()
	{
		estadisticas.setMalLlenados(++numBotesMalLlenadosUltTanda);
		estadisticas.setMalLlenadosTotales(estadisticas.getMalLlenadosTotales()+1);
		guardarEstadisticas();
	}

	/**
	 * Este m�todo es llamado al recibir el mensaje desde el maestro de que el bote
	 * se ha llevado a la caja de embalaje final. Se cambian las estadisticas
	 * y se graban.
	 */
	private void boteTerminado()
	{
		estadisticas.setBienLlenados(++numBotesMalLlenadosUltTanda);
		estadisticas.setBienLlenadosTotales(estadisticas.getBienLlenadosTotales()+1);
		guardarEstadisticas();
	}

	/**
	 * Este m�todo es llamado al recibir el mensaje desde el maestro de que el bote
	 * se ha tapado mal y se expulsa. Se cambian las estadisticas y se graban.
	 */
	private void boteMalTapado()
	{
		estadisticas.setMalTapados(++numBotesMalTapadosUltTanda);
		estadisticas.setMalTapadosTotales(estadisticas.getMalTapadosTotales()+1);
		guardarEstadisticas();
	}

	/** 
	 * M�todo que nos sirve para centrar una ventana en la pantalla,
	 * independientemente de la resoluci�n del usuario.
	 */
	private static void centrarVentana(Window x)
	{
		int ancho = x.getSize().width;
		int alto = x.getSize().width;
		int anchoPan = Toolkit.getDefaultToolkit().getScreenSize().width;
		int altoPan = Toolkit.getDefaultToolkit().getScreenSize().height;
		int px = (anchoPan/2)-(ancho/2);
		int py = (altoPan/2)-(alto/2);
		x.setLocation(Math.max(1,px),Math.max(1,py));
	}

	/**
	 * Metodo que se llama desde el dialogo de login y que comprueba que es usuario
	 * y la clave suministrados son correctos.
	 * 
	 * @param usuario Login del usuario (en la BD)
	 * @param clave Clave del usuario (le hacemos el MD5 para compararlo con el de la BD)
	 * @return Cierto o falso si est� autorizado
	 */
	public boolean login(String usuario, String clave)
	{
		if (config.getUsuario().equals(usuario) && MD5.calcular(clave).equals(config.getClaveMD5()))
			return true;
		else
			return false;		
	}

	/**
	 * Devuelve el valor de la propiedad del archivo de configuraci�n
	 * 
	 * @return Valor de la propiedad del archivo de configuraci�n
	 */
	public String getArchivoBD()
	{
		return this.archivoBD;
	}

	/**
	 * Programa principal que arranca el scada
	 * @param args Argumentos por la linea de comandos: Archivo de BD, puerto de escucha
	 * 				y direcci�n del aut�mata maestro.
	 * @throws IOException si algo va mal creando los buzones o leyendo de la BD.
	 */
	public static void main(String args[]) throws IOException
	{
		if (args.length!=3)
		{
			System.out.println("Los argumentos que acepta el programa son:\n");
			System.out.println("\t-Ruta del archivo properties de la base de datos");
			System.out.println("\t-Puerto de escucha de mensajes provenientes del automata maestro");
			System.out.println("\t-Donde escucha el automata maestro los mensajes, de la forma host:puerto\n\n");
		}
		else
			new Scada(args[0], Integer.parseInt(args[1]), args[2]);
	}

}
