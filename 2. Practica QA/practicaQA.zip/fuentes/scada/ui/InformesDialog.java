package scada.ui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

import scada.informes.Informe;
/**
 * Clase que es un di�logo modal donde se le muestra al usuario los resultados
 * estadisticos de la ejecuci�n de la aplicaci�n. Necesita en su constructor
 * una instancia de la clase Informe, de donde sacar� los datos que muestra.
 * 
 * @see scada.Scada
 * @see scada.informes.Informe
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */
public class InformesDialog extends javax.swing.JDialog implements ActionListener 
{
	/* Propiedades del interfaz de usuario */
	private JPanel panelDatosParadas;
	private JLabel lbNumArranques;
	private JLabel lbParadasNormales;
	private JButton btnOk;
	private JLabel datoBotesBienLlenadosIni;
	private JLabel datoBotesMalTapadosIni;
	private JLabel datoBotesBienLlenados;
	private JLabel datoBotesMalLlenadosIni;
	private JLabel datoBotesMalTapados;
	private JLabel datoBotesMalLlenados;
	private JLabel lbUltTanda;
	private JLabel lbTotProdInsSist;
	private JLabel lbTextoMalLlenados;
	private JLabel lbTextoBienLlenados;
	private JLabel lbTextoMalTapados;
	private JPanel panelDatosProduccion;
	private JLabel datoParadasEmergencia;
	private JLabel datoArranques;
	private JLabel datoParadasNormales;
	private JLabel lbTotalDesdeInstSist;
	private JLabel lbParadasEmerg;
	private JLabel lbEstadisticas;
	
	/**
	 * Datos empleados para el informe, y que son leidos previamente de disco. 
	 */
	private Informe informe;
	
	/**
	 * Crea el di�logo modal de los informes. Para ello recibe el JFrame padre (el
	 * scada), y la informaci�n a representar.
	 * @param frame Aplicacion padre del dialogo modal. 
	 * @param i Instancia que almacena la informaci�n estad�stica
	 */
	public InformesDialog(JFrame frame, Informe i) 
	{
		super(frame);
		initGUI();
		this.informe = i;
		this.datoBotesBienLlenados.setText(String.valueOf(i.getBienLlenados()));
		this.datoBotesMalLlenados.setText(String.valueOf(i.getMalLlenados()));
		this.datoBotesMalTapados.setText(String.valueOf(i.getMalTapados()));
		this.datoBotesBienLlenadosIni.setText(String.valueOf(i.getBienLlenadosTotales()));
		this.datoBotesMalLlenadosIni.setText(String.valueOf(i.getMalLlenadosTotales()));
		this.datoBotesMalTapadosIni.setText(String.valueOf(i.getMalTapadosTotales()));
		this.datoParadasEmergencia.setText(String.valueOf(i.getParadasEmergencia()));
		this.datoParadasNormales.setText(String.valueOf(i.getParadasNormales()));
		this.datoArranques.setText(String.valueOf(i.getArranques()));
	}
	
	/**
	 * En este m�todo se inicializan los componentes visuales de la aplicaci�n
	 * y se colocan en el di�logo.
	 *
	 */
	private void initGUI() 
	{
		try {
			this.setSize(572, 418);
			this.getContentPane().setLayout(null);
			this.getContentPane().setBackground(new java.awt.Color(248,233,214));
			{
				panelDatosParadas = new JPanel();
				this.getContentPane().add(panelDatosParadas);
				panelDatosParadas.setBounds(30, 198, 502, 133);
				panelDatosParadas.setBorder(BorderFactory.createTitledBorder(null, "Datos de paradas", TitledBorder.LEADING, TitledBorder.TOP, new java.awt.Font("Dialog",1,12), new java.awt.Color(128,128,255)));
				panelDatosParadas.setLayout(null);
				panelDatosParadas.setOpaque(false);
				{
					lbNumArranques = new JLabel();
					panelDatosParadas.add(lbNumArranques);
					lbNumArranques.setText("N�mero de arranques");
					lbNumArranques.setBounds(12, 90, 142, 16);
				}
				{
					lbParadasEmerg = new JLabel();
					panelDatosParadas.add(lbParadasEmerg);
					lbParadasEmerg.setText("Paradas de emergencia");
					lbParadasEmerg.setBounds(12, 45, 142, 16);
				}
				{
					lbParadasNormales = new JLabel();
					panelDatosParadas.add(lbParadasNormales);
					lbParadasNormales.setText("Paradas normales");
					lbParadasNormales.setBounds(12, 66, 142, 16);
				}
				{
					lbTotalDesdeInstSist = new JLabel();
					panelDatosParadas.add(lbTotalDesdeInstSist);
					lbTotalDesdeInstSist.setText("Total desde la instalacion del sistema");
					lbTotalDesdeInstSist.setBounds(178, 18, 226, 15);
				}
				{
					datoParadasNormales = new JLabel();
					panelDatosParadas.add(datoParadasNormales);
					datoParadasNormales.setText("0");
					datoParadasNormales.setBounds(254, 68, 57, 16);
					datoParadasNormales.setHorizontalAlignment(SwingConstants.RIGHT);
					datoParadasNormales.setBorder(new LineBorder(new java.awt.Color(0,128,64), 1, false));
					datoParadasNormales.setForeground(new java.awt.Color(0,128,128));
				}
				{
					datoArranques = new JLabel();
					panelDatosParadas.add(datoArranques);
					datoArranques.setText("0");
					datoArranques.setHorizontalAlignment(SwingConstants.RIGHT);
					datoArranques.setForeground(new java.awt.Color(0,128,128));
					datoArranques.setBorder(new LineBorder(new java.awt.Color(0,128,64), 1, false));
					datoArranques.setBounds(254, 90, 57, 15);
				}
				{
					datoParadasEmergencia = new JLabel();
					panelDatosParadas.add(datoParadasEmergencia);
					datoParadasEmergencia.setText("0");
					datoParadasEmergencia.setHorizontalAlignment(SwingConstants.RIGHT);
					datoParadasEmergencia.setForeground(new java.awt.Color(0, 128, 128));
					datoParadasEmergencia.setBorder(new LineBorder(new java.awt.Color(
						0,
						128,
						64), 1, false));
					datoParadasEmergencia.setBounds(254, 48, 57, 16);
				}
				{
				}
			}
			{
				lbEstadisticas = new JLabel();
				this.getContentPane().add(lbEstadisticas);
				lbEstadisticas.setText("I N F O R M E    D E    P R O D U C C I � N");
				lbEstadisticas.setBounds(21, 6, 514, 41);
				lbEstadisticas.setHorizontalAlignment(SwingConstants.CENTER);
				lbEstadisticas.setFont(new java.awt.Font("Arial Black",1,22));
				lbEstadisticas.setForeground(new java.awt.Color(0,128,192));
			}
			{
				panelDatosProduccion = new JPanel();
				this.getContentPane().add(panelDatosProduccion);
				panelDatosProduccion.setBorder(BorderFactory.createTitledBorder(
					null,
					"Datos de producci�n",
					TitledBorder.LEADING,
					TitledBorder.TOP,
					new java.awt.Font("Dialog", 1, 12),
					new java.awt.Color(128, 128, 255)));
				panelDatosProduccion.setOpaque(false);
				panelDatosProduccion.setLayout(null);
				panelDatosProduccion.setBounds(25, 56, 502, 133);
				{
					lbTextoMalTapados = new JLabel();
					panelDatosProduccion.add(lbTextoMalTapados);
					lbTextoMalTapados.setText("N� de botes mal tapados");
					lbTextoMalTapados.setBounds(12, 90, 142, 16);
				}
				{
					lbTextoBienLlenados = new JLabel();
					panelDatosProduccion.add(lbTextoBienLlenados);
					lbTextoBienLlenados.setText("N� de botes bien llenados");
					lbTextoBienLlenados.setBounds(12, 45, 142, 16);
				}
				{
					lbTextoMalLlenados = new JLabel();
					panelDatosProduccion.add(lbTextoMalLlenados);
					lbTextoMalLlenados.setText("N� de botes mal llenados");
					lbTextoMalLlenados.setBounds(12, 66, 142, 16);
				}
				{
					lbTotProdInsSist = new JLabel();
					panelDatosProduccion.add(lbTotProdInsSist);
					lbTotProdInsSist.setText("Total desde la instalacion del sistema");
					lbTotProdInsSist.setBounds(263, 15, 226, 15);
				}
				{
					lbUltTanda = new JLabel();
					panelDatosProduccion.add(lbUltTanda);
					lbUltTanda.setText("�ltima tanda");
				}
				{
					datoBotesMalLlenados = new JLabel();
					panelDatosProduccion.add(datoBotesMalLlenados);
					datoBotesMalLlenados.setText("0");
					datoBotesMalLlenados.setHorizontalAlignment(SwingConstants.RIGHT);
					datoBotesMalLlenados.setForeground(new java.awt.Color(0, 128, 128));
					datoBotesMalLlenados.setBorder(new LineBorder(new java.awt.Color(
						0,
						128,
						64), 1, false));
					datoBotesMalLlenados.setBounds(185, 66, 57, 15);
				}
				{
					datoBotesMalTapados = new JLabel();
					panelDatosProduccion.add(datoBotesMalTapados);
					datoBotesMalTapados.setText("0");
					datoBotesMalTapados.setHorizontalAlignment(SwingConstants.RIGHT);
					datoBotesMalTapados.setForeground(new java.awt.Color(0, 128, 128));
					datoBotesMalTapados.setBorder(new LineBorder(new java.awt.Color(
						0,
						128,
						64), 1, false));
					datoBotesMalTapados.setBounds(185, 88, 57, 15);
				}
				{
					datoBotesMalLlenadosIni = new JLabel();
					panelDatosProduccion.add(datoBotesMalLlenadosIni);
					datoBotesMalLlenadosIni.setText("0");
					datoBotesMalLlenadosIni.setHorizontalAlignment(SwingConstants.RIGHT);
					datoBotesMalLlenadosIni.setForeground(new java.awt.Color(0, 128, 128));
					datoBotesMalLlenadosIni.setBorder(new LineBorder(new java.awt.Color(
						0,
						128,
						64), 1, false));
					datoBotesMalLlenadosIni.setBounds(331, 66, 57, 15);
				}
				{
					datoBotesBienLlenados = new JLabel();
					panelDatosProduccion.add(datoBotesBienLlenados);
					datoBotesBienLlenados.setText("0");
					datoBotesBienLlenados.setHorizontalAlignment(SwingConstants.RIGHT);
					datoBotesBienLlenados.setForeground(new java.awt.Color(0, 128, 128));
					datoBotesBienLlenados.setBorder(new LineBorder(new java.awt.Color(
						0,
						128,
						64), 1, false));
					datoBotesBienLlenados.setBounds(185, 46, 57, 15);
				}
				{
					datoBotesMalTapadosIni = new JLabel();
					panelDatosProduccion.add(datoBotesMalTapadosIni);
					datoBotesMalTapadosIni.setText("0");
					datoBotesMalTapadosIni.setHorizontalAlignment(SwingConstants.RIGHT);
					datoBotesMalTapadosIni.setForeground(new java.awt.Color(0, 128, 128));
					datoBotesMalTapadosIni.setBorder(new LineBorder(new java.awt.Color(
						0,
						128,
						64), 1, false));
					datoBotesMalTapadosIni.setBounds(331, 88, 57, 15);
				}
				{
					datoBotesBienLlenadosIni = new JLabel();
					panelDatosProduccion.add(datoBotesBienLlenadosIni);
					datoBotesBienLlenadosIni.setText("0");
					datoBotesBienLlenadosIni.setHorizontalAlignment(SwingConstants.RIGHT);
					datoBotesBienLlenadosIni.setForeground(new java.awt.Color(0, 128, 128));
					datoBotesBienLlenadosIni.setBorder(new LineBorder(new java.awt.Color(
						0,
						128,
						64), 1, false));
					datoBotesBienLlenadosIni.setBounds(331, 46, 57, 15);
				}
			}
			{
				btnOk = new JButton();
				this.getContentPane().add(btnOk);
				btnOk.setText("C E R R A R");
				btnOk.setBounds(222, 348, 117, 30);
				btnOk.setOpaque(false);
				btnOk.addActionListener(this);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * M�todo que se llama cuando se pulsa el bot�n de cerrar del di�logo
	 */
	public void actionPerformed(ActionEvent e)
	{
		this.dispose();
	}

}
