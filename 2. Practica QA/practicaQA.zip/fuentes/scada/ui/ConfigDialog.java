package scada.ui;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;

import scada.Configuracion;
import scada.ManagerConfiguracion;
import scada.Scada;
import scada.excepciones.ScadaException;
/**
 * Clase que es un di�logo modal donde se le permite al usuario alterar los
 * valores leidos de la base de datos. Al cambiarlos y pulsar aceptar, se
 * vuelven a grabar en disco.
 * 
 * @see scada.Scada
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */
public class ConfigDialog extends javax.swing.JDialog implements ActionListener 
{
	/**
	 * Propiedad donde se guarda la configuraci�n leida de disco.
	 */
	private Configuracion conf;
	
	/**
	 * Propiedad que referencia al JFrame que abri� el dialogo (el scada en este caso)
	 */
	private Scada scada;
	/*
	 * Propiedades del interfaz de usuario
	 */
	private JLabel lbTitulo;
	private CampoNumerico tfCicloReloj;
	private JLabel lbTitulCiclos;
	private JLabel jLabel8;
	private JLabel jLabel4;
	private CampoNumerico tfLongCintaLlenado;
	private CampoNumerico tfTiempoTranspCintas;
	private CampoNumerico tfTiempoTranspCajaFin;
	private CampoNumerico tfCapacidadCajaEmbalaje;
	private CampoNumerico tfUmbralBotesMalTapados;
	private CampoNumerico tfVelocCintaTaponado;
	private CampoNumerico tfLongCintaTaponado;
	private CampoNumerico tfCapacDeposMermelada;
	private CampoNumerico tfVelocCintaLlenado;
	private CampoNumerico tfTiempoLlenadoBote;
	private CampoNumerico tfUmbralBotesVacios;
	private CampoNumerico tfCapacDeposBotes;
	private CampoNumerico tfCapacCajaBotesMalLlenados;
	private JButton btnCancelar;
	private JButton btnGuardar;
	private JLabel lbTituloDatosAutomTapon;
	private JLabel jLabel17;
	private JLabel jLabel16;
	private JLabel jLabel12;
	private JLabel jLabel11;
	private JPanel panAutomTaponado;
	private JLabel lbTituloDatosAutomLlenado;
	private JLabel lbTitAutom1;
	private JLabel jLabel15;
	private JLabel jLabel14;
	private JLabel jLabel13;
	private JLabel jLabel9;
	private JLabel jLabel6;
	private JLabel jLabel1;
	private JPanel panAutomLlenado;
	private JLabel jLabel7;
	private JPanel panDatosRobots;

	/**
	 * Constructor del dialogo modal. Recibe el JFrame que ser� su padre. Se carga la
	 * configuraci�n desde disco y se almacena en la propiedad <code>conf<code>.
	 * @param frame Componente padre
	 * @throws ScadaException
	 * @see scada.ManagerConfiguracion
	 */
	public ConfigDialog(Scada frame) throws ScadaException 
	{
		super(frame);
		this.scada = frame;
		initGUI();
		conf = ManagerConfiguracion.cargarConfiguracion(frame.getArchivoBD());
		cargarConfiguracionEnCampos();
	}
	
	/**
	 * M�todo que se encarga de inicializar los componentes gr�ficos y
	 * de colocarlos en pantalla. Se llama desde el constructor
	 *
	 */
	private void initGUI() 
	{
		this.getContentPane().setLayout(null);
		this.setSize(639, 388);
		setTitle("Configuraci�n de la aplicaci�n");
		this.getContentPane().setBackground(new java.awt.Color(255,225,255));
		lbTitulo = new JLabel();
		this.getContentPane().add(lbTitulo, BorderLayout.CENTER);
		lbTitulo.setText("Configuraci�n de la aplicaci�n");
		lbTitulo.setBounds(95, 16, 452, 35);
		lbTitulo.setFont(new java.awt.Font("Arial Black",1,20));
		lbTitulo.setBorder(BorderFactory.createEtchedBorder(BevelBorder.LOWERED, null, null));
		lbTitulo.setOpaque(true);
		lbTitulo.setHorizontalAlignment(SwingConstants.CENTER);
		lbTitulo.setBackground(new java.awt.Color(177,204,231));
		tfCicloReloj = new CampoNumerico("Ciclos de reloj", 10, 5000);
		this.getContentPane().add(tfCicloReloj);
		tfCicloReloj.setBounds(165, 72, 50, 16);
		tfCicloReloj.setHorizontalAlignment(SwingConstants.RIGHT);
		tfCicloReloj.setFont(new java.awt.Font("Dialog",0,10));
		panDatosRobots = new JPanel();
		this.getContentPane().add(panDatosRobots);
		panDatosRobots.setBounds(343, 236, 256, 50);
		panDatosRobots.setLayout(null);
		panDatosRobots.setOpaque(false);
		panDatosRobots.setBorder(BorderFactory.createEtchedBorder(BevelBorder.LOWERED, null, null));
		jLabel7 = new JLabel();
		panDatosRobots.add(jLabel7);
		jLabel7.setText("Tiempo de transporte robot 1 (seg.)");
		jLabel7.setFont(new java.awt.Font("Dialog",1,10));
		jLabel7.setBounds(10, 10, 181, 15);
		jLabel8 = new JLabel();
		panDatosRobots.add(jLabel8);
		jLabel8.setText("Tiempo de transporte robot 2 (seg.)");
		jLabel8.setFont(new java.awt.Font("Dialog",1,10));
		jLabel8.setBounds(11, 29, 179, 14);
		tfTiempoTranspCajaFin = new CampoNumerico("Tiempo empleado para transportar el bote a la caja de embalaje", 0, 100);
		panDatosRobots.add(tfTiempoTranspCajaFin);
		tfTiempoTranspCajaFin.setFont(new java.awt.Font("Dialog", 0, 10));
		tfTiempoTranspCajaFin.setHorizontalAlignment(SwingConstants.RIGHT);
		tfTiempoTranspCajaFin.setText("");
		tfTiempoTranspCajaFin.setBounds(195, 29, 50, 16);
		tfTiempoTranspCintas = new CampoNumerico("Tiempo de transporte entre cintas", 0, 100);
		panDatosRobots.add(tfTiempoTranspCintas);
		tfTiempoTranspCintas.setFont(new java.awt.Font("Dialog",0,10));
		tfTiempoTranspCintas.setHorizontalAlignment(SwingConstants.RIGHT);
		tfTiempoTranspCintas.setText("");
		tfTiempoTranspCintas.setBounds(194, 9, 50, 16);
		lbTitulCiclos = new JLabel();
		this.getContentPane().add(lbTitulCiclos);
		lbTitulCiclos.setText("Ciclo de reloj (en ms.)");
		lbTitulCiclos.setFont(new java.awt.Font("Dialog", 1, 10));
		lbTitulCiclos.setBounds(40, 72, 120, 15);
		panAutomLlenado = new JPanel();
		this.getContentPane().add(panAutomLlenado);
		panAutomLlenado.setBorder(BorderFactory.createEtchedBorder(
			BevelBorder.LOWERED,
			null,
			null));
		panAutomLlenado.setOpaque(false);
		panAutomLlenado.setLayout(null);
		panAutomLlenado.setBounds(36, 117, 292, 170);
		jLabel1 = new JLabel();
		panAutomLlenado.add(jLabel1);
		jLabel1.setText("Capacidad deposito botes");
		jLabel1.setFont(new java.awt.Font("Dialog", 1, 10));
		jLabel1.setBounds(16, 98, 163, 14);
		jLabel4 = new JLabel();
		panAutomLlenado.add(jLabel4);
		jLabel4.setText("Capacidad deposito mermelada");
		jLabel4.setFont(new java.awt.Font("Dialog", 1, 10));
		jLabel4.setBounds(18, 136, 157, 15);
		jLabel6 = new JLabel();
		panAutomLlenado.add(jLabel6);
		jLabel6.setText("Longitud cinta (metros)");
		jLabel6.setFont(new java.awt.Font("Dialog", 1, 10));
		jLabel6.setBounds(15, 19, 120, 15);
		jLabel9 = new JLabel();
		panAutomLlenado.add(jLabel9);
		jLabel9.setText("Velocidad cinta (metros/min.)");
		jLabel9.setFont(new java.awt.Font("Dialog", 1, 10));
		jLabel9.setBounds(15, 40, 153, 14);
		jLabel13 = new JLabel();
		panAutomLlenado.add(jLabel13);
		jLabel13.setText("Umbral botes vac�os (%)");
		jLabel13.setFont(new java.awt.Font("Dialog", 1, 10));
		jLabel13.setBounds(16, 76, 120, 15);
		jLabel14 = new JLabel();
		panAutomLlenado.add(jLabel14);
		jLabel14.setText("Tiempo llenado bote (seg.)");
		jLabel14.setFont(new java.awt.Font("Dialog", 1, 10));
		jLabel14.setBounds(16, 57, 147, 15);
		jLabel15 = new JLabel();
		panAutomLlenado.add(jLabel15);
		jLabel15.setText("Capacidad caja botes mal llenados");
		jLabel15.setFont(new java.awt.Font("Dialog", 1, 10));
		jLabel15.setBounds(16, 116, 177, 14);
		tfCapacCajaBotesMalLlenados = new CampoNumerico("Capacidad de la caja de botes mal llenados", 0, 1000);
		panAutomLlenado.add(tfCapacCajaBotesMalLlenados);
		tfCapacCajaBotesMalLlenados.setFont(new java.awt.Font("Dialog", 0, 10));
		tfCapacCajaBotesMalLlenados.setHorizontalAlignment(SwingConstants.RIGHT);
		tfCapacCajaBotesMalLlenados.setText("");
		tfCapacCajaBotesMalLlenados.setBounds(212, 114, 50, 16);
		tfCapacDeposBotes = new CampoNumerico("Capacidad del deposito de botes", 0, 1000);
		panAutomLlenado.add(tfCapacDeposBotes);
		tfCapacDeposBotes.setFont(new java.awt.Font("Dialog",0,10));
		tfCapacDeposBotes.setHorizontalAlignment(SwingConstants.RIGHT);
		tfCapacDeposBotes.setText("");
		tfCapacDeposBotes.setBounds(212, 96, 50, 16);
		tfUmbralBotesVacios = new CampoNumerico("Umbral de botes vacios", 0, 100);
		panAutomLlenado.add(tfUmbralBotesVacios);
		tfUmbralBotesVacios.setFont(new java.awt.Font("Dialog",0,10));
		tfUmbralBotesVacios.setHorizontalAlignment(SwingConstants.RIGHT);
		tfUmbralBotesVacios.setText("");
		tfUmbralBotesVacios.setBounds(212, 75, 50, 16);
		tfTiempoLlenadoBote = new CampoNumerico("Tiempo de llenado del bote", 0, 100);
		panAutomLlenado.add(tfTiempoLlenadoBote);
		tfTiempoLlenadoBote.setFont(new java.awt.Font("Dialog",0,10));
		tfTiempoLlenadoBote.setHorizontalAlignment(SwingConstants.RIGHT);
		tfTiempoLlenadoBote.setText("");
		tfTiempoLlenadoBote.setBounds(212, 56, 50, 16);
		tfVelocCintaLlenado = new CampoNumerico("Velocidad de la cinta de llenado", 1, 300);
		panAutomLlenado.add(tfVelocCintaLlenado);
		tfVelocCintaLlenado.setFont(new java.awt.Font("Dialog",0,10));
		tfVelocCintaLlenado.setHorizontalAlignment(SwingConstants.RIGHT);
		tfVelocCintaLlenado.setText("");
		tfVelocCintaLlenado.setBounds(212, 38, 50, 16);
		tfLongCintaLlenado = new CampoNumerico("Longitud de la cinta de llenado", 5, 40);
		panAutomLlenado.add(tfLongCintaLlenado);
		tfLongCintaLlenado.setFont(new java.awt.Font("Dialog",0,10));
		tfLongCintaLlenado.setHorizontalAlignment(SwingConstants.RIGHT);
		tfLongCintaLlenado.setText("");
		tfLongCintaLlenado.setBounds(212, 18, 50, 16);
		tfCapacDeposMermelada = new CampoNumerico("Capacidad del deposito de mermelada", 0, 1000);
		panAutomLlenado.add(tfCapacDeposMermelada);
		tfCapacDeposMermelada.setFont(new java.awt.Font("Dialog",0,10));
		tfCapacDeposMermelada.setHorizontalAlignment(SwingConstants.RIGHT);
		tfCapacDeposMermelada.setText("");
		tfCapacDeposMermelada.setBounds(212, 135, 50, 16);
		lbTitAutom1 = new JLabel();
		this.getContentPane().add(lbTitAutom1);
		lbTitAutom1.setText("Robots");
		lbTitAutom1.setBounds(345, 217, 150, 14);
		lbTituloDatosAutomLlenado = new JLabel();
		this.getContentPane().add(lbTituloDatosAutomLlenado);
		lbTituloDatosAutomLlenado.setText("Aut�mata de llenado");
		lbTituloDatosAutomLlenado.setBounds(39, 97, 120, 16);
		panAutomTaponado = new JPanel();
		this.getContentPane().add(panAutomTaponado);
		panAutomTaponado.setBorder(BorderFactory.createEtchedBorder(BevelBorder.LOWERED, null, null));
		panAutomTaponado.setOpaque(false);
		panAutomTaponado.setLayout(null);
		panAutomTaponado.setBounds(338, 118, 259, 93);
		jLabel11 = new JLabel();
		panAutomTaponado.add(jLabel11);
		jLabel11.setText("Capacidad caja de botes");
		jLabel11.setFont(new java.awt.Font("Dialog", 1, 10));
		jLabel11.setBounds(13, 66, 163, 14);
		jLabel12 = new JLabel();
		panAutomTaponado.add(jLabel12);
		jLabel12.setText("Longitud cinta (metros)");
		jLabel12.setFont(new java.awt.Font("Dialog", 1, 10));
		jLabel12.setBounds(12, 8, 120, 15);
		jLabel16 = new JLabel();
		panAutomTaponado.add(jLabel16);
		jLabel16.setText("Velocidad cinta (metros/min.)");
		jLabel16.setFont(new java.awt.Font("Dialog", 1, 10));
		jLabel16.setBounds(13, 29, 153, 14);
		jLabel17 = new JLabel();
		panAutomTaponado.add(jLabel17);
		jLabel17.setText("Umbral botes mal tapados (%)");
		jLabel17.setFont(new java.awt.Font("Dialog", 1, 10));
		jLabel17.setBounds(13, 47, 159, 14);
		tfLongCintaTaponado = new CampoNumerico("Longitud de la cinta de taponado", 5, 40);
		panAutomTaponado.add(tfLongCintaTaponado);
		tfLongCintaTaponado.setFont(new java.awt.Font("Dialog",0,10));
		tfLongCintaTaponado.setHorizontalAlignment(SwingConstants.RIGHT);
		tfLongCintaTaponado.setText("");
		tfLongCintaTaponado.setBounds(195, 8, 50, 16);
		tfVelocCintaTaponado = new CampoNumerico("Velocidad de la cinta de taponado", 1, 300);
		panAutomTaponado.add(tfVelocCintaTaponado);
		tfVelocCintaTaponado.setFont(new java.awt.Font("Dialog",0,10));
		tfVelocCintaTaponado.setHorizontalAlignment(SwingConstants.RIGHT);
		tfVelocCintaTaponado.setText("");
		tfVelocCintaTaponado.setBounds(195, 28, 50, 16);
		tfUmbralBotesMalTapados = new CampoNumerico("Umbral de botes mal tapados", 0, 100);
		panAutomTaponado.add(tfUmbralBotesMalTapados);
		tfUmbralBotesMalTapados.setFont(new java.awt.Font("Dialog",0,10));
		tfUmbralBotesMalTapados.setHorizontalAlignment(SwingConstants.RIGHT);
		tfUmbralBotesMalTapados.setText("");
		tfUmbralBotesMalTapados.setBounds(195, 46, 50, 16);
		tfCapacidadCajaEmbalaje = new CampoNumerico("Capacidad de la caja de embalaje", 0, 1000);
		panAutomTaponado.add(tfCapacidadCajaEmbalaje);
		tfCapacidadCajaEmbalaje.setFont(new java.awt.Font("Dialog",0,10));
		tfCapacidadCajaEmbalaje.setHorizontalAlignment(SwingConstants.RIGHT);
		tfCapacidadCajaEmbalaje.setText("");
		tfCapacidadCajaEmbalaje.setBounds(195, 65, 50, 16);
		lbTituloDatosAutomTapon = new JLabel();
		this.getContentPane().add(lbTituloDatosAutomTapon);
		lbTituloDatosAutomTapon.setText("Aut�mata de taponado");
		lbTituloDatosAutomTapon.setBounds(341, 98, 150, 14);
		btnGuardar = new JButton();
		this.getContentPane().add(btnGuardar);
		btnGuardar.setText("Guardar");
		btnGuardar.setBounds(158, 323, 103, 30);
		btnCancelar = new JButton();
		this.getContentPane().add(btnCancelar);
		btnCancelar.setText("Cancelar");
		btnCancelar.setBounds(333, 323, 103, 30);
		
		btnGuardar.addActionListener(this);
		btnCancelar.addActionListener(this);
	}

	/**
	 * M�todo que obliga a implementar el interfaz ActionListener. Hemos hecho a la
	 * propia instancia de ConfigDialog escuchadora de eventos para los botones del
	 * interfaz. Al pulsar un boton, se llama a este m�todo. Una vez decidido qu�
	 * bot�n se puls�, de realizan las acciones oportunas.
	 * @param e Objeto ActionEvent con informaci�n sobre el evento desencadenado
	 */
	public void actionPerformed(ActionEvent e)
	{
		if (e.getSource()==btnCancelar)
			this.dispose();
		else if (e.getSource()==btnGuardar)
		{
			try
			{
				conf.setCicloReloj(tfCicloReloj.getValor());
				
				conf.setLongitudCintaLlenado(tfLongCintaLlenado.getValor());
				conf.setVelocidadCintaLlenado(tfVelocCintaLlenado.getValor());
				conf.setTiempoLlenadoBote(tfTiempoLlenadoBote.getValor());
				conf.setUmbralBotesVacios(tfUmbralBotesVacios.getValor());
				conf.setCapacidadDepositoBotes(tfCapacDeposBotes.getValor());
				conf.setCapacidadCajaMalLlenados(tfCapacCajaBotesMalLlenados.getValor());
				conf.setCapacidadDepositoMermelada(tfCapacDeposMermelada.getValor());
				
				conf.setLongitudCintaTaponado(tfLongCintaTaponado.getValor());
				conf.setVelocidadCintaTaponado(tfVelocCintaTaponado.getValor());
				conf.setUmbralBotesMalTaponados(tfUmbralBotesMalTapados.getValor());
				conf.setCapacidadCajaBotes(tfCapacidadCajaEmbalaje.getValor());
				
				conf.setTiempoTransporteCajaEmbalaje(tfTiempoTranspCajaFin.getValor());
				conf.setTiempoTransporteEntreCintas(tfTiempoTranspCintas.getValor());
				
				ManagerConfiguracion.salvarConfiguracion(conf, scada.getArchivoBD());
				this.dispose();
			}
			catch (Exception ex)
			{
				JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
			}
		}
	}
	
	/**
	 * Metodo que coge la configuraci�n almacenada en la propiedad <code>conf</code>,
	 * y que previamente debi� ser leida de disco, y pone los valores apropiados en
	 * los campos de texto para permitir su edici�n por el usuario.
	 */
	private void cargarConfiguracionEnCampos()
	{
		tfCicloReloj.setValor(conf.getCicloReloj());
		
		tfLongCintaLlenado.setValor(conf.getLongitudCintaLlenado());
		tfVelocCintaLlenado.setValor(conf.getVelocidadCintaLlenado());
		tfTiempoLlenadoBote.setValor(conf.getTiempoLlenadoBote());
		tfUmbralBotesVacios.setValor(conf.getUmbralBotesVacios());
		tfCapacDeposBotes.setValor(conf.getCapacidadDepositoBotes());
		tfCapacCajaBotesMalLlenados.setValor(conf.getCapacidadCajaMalLlenados());
		tfCapacDeposMermelada.setValor(conf.getCapacidadDepositoMermelada());
		
		tfLongCintaTaponado.setValor(conf.getLongitudCintaTaponado());
		tfVelocCintaTaponado.setValor(conf.getVelocidadCintaTaponado());
		tfUmbralBotesMalTapados.setValor(conf.getUmbralBotesMalTaponados());
		tfCapacidadCajaEmbalaje.setValor(conf.getCapacidadCajaEmbalaje());
		
		tfTiempoTranspCajaFin.setValor(conf.getTiempoTransporteCajaEmbalaje());
		tfTiempoTranspCintas.setValor(conf.getTiempoTransporteEntreCintas());
	}

}
