package scada.ui;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;

import scada.Scada;
/**
 * Clase que es un dialogo modal que abre la aplicaci�n Scada y que permite
 * validar al usuario. Si este cierra el dialogo sin validarse, la aplicaci�n
 * scada termina.
 * 
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */
public class LoginDialog extends javax.swing.JDialog implements ActionListener 
{
	/* Propiedades del interfaz de usuario */
	private JLabel lbTitulo;
	private JLabel lbLogin;
	private JTextField tfLogin;
	private JPasswordField tfClave;
	private JTextField tfMensajeError;
	private JButton btnAceptar;
	private JLabel lbClave;
	/**
	 * Referencia al scada para poder llamar a su metodo de login y poder comprobar
	 * si lo que ha metido el usuario es correcto
	 */
	private Scada scada;
	/**
	 * Almacena si el usuario ha hecho login ya o no (para ver si cerramos la ventana
	 * y no acabamos la aplicaci�n).
	 */
	private boolean loginOk = false;

	/**
	 * Inicializamos la aplicaci�n y sus componentes gr�ficos
	 * @param scada
	 */
	public LoginDialog(Scada scada) 
	{
		super(scada);
		this.scada = scada;
		setModal(true);
		initGUI();
		this.addWindowListener(new WindowAdapter()
				{
					public void windowClosing(WindowEvent e)
					{
						if (loginOk)
							dispose();
						else
							System.exit(-10);
					}
				});
	}
	
	/**
	 * Creamos el interfaz de usuario y colocamos los componentes
	 */
	private void initGUI() 
	{
		try 
		{
			this.setSize(415, 315);
			this.getContentPane().setLayout(null);
			this.getContentPane().setBackground(new java.awt.Color(169,193,214));
			lbTitulo = new JLabel();
			this.getContentPane().add(lbTitulo);
			lbTitulo.setText("Acceso al sistema");
			lbTitulo.setBounds(32, 15, 329, 72);
			lbTitulo.setFont(new java.awt.Font("Arial Black",1,26));
			lbTitulo.setBorder(BorderFactory.createEtchedBorder(BevelBorder.LOWERED));
			lbTitulo.setHorizontalAlignment(SwingConstants.CENTER);
			lbLogin = new JLabel();
			this.getContentPane().add(lbLogin);
			lbLogin.setText("Usuario");
			lbLogin.setBounds(72, 112, 60, 30);
			lbClave = new JLabel();
			this.getContentPane().add(lbClave);
			lbClave.setText("Clave");
			lbClave.setBounds(71, 142, 44, 30);
			tfClave = new JPasswordField();
			tfClave.setEchoChar('$');
			this.getContentPane().add(tfClave);
			tfClave.setBounds(126, 148, 178, 18);
			tfLogin = new JTextField();
			this.getContentPane().add(tfLogin);
			tfLogin.setBounds(126, 117, 178, 18);
			btnAceptar = new JButton("Entrar");
			btnAceptar.setBounds(145, 182, 100, 29);
			btnAceptar.setOpaque(false);
			this.getContentPane().add(btnAceptar);
			btnAceptar.addActionListener(this);
			tfMensajeError = new JTextField();
			this.getContentPane().add(tfMensajeError);
			tfMensajeError.setText("Error:");
			tfMensajeError.setBounds(12, 244, 378, 30);
			tfMensajeError.setVisible(false);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

	/**
	 * M�todo que se llamar� al pulsar el bot�n de aceptar y en donde
	 * se comprobar� el login y la clave del usuario.
	 * @param e Evento que dispar� la acci�n
	 */
	public void actionPerformed(ActionEvent e) 
	{
		if (!scada.login(tfLogin.getText(), new String(tfClave.getPassword())))
		{
			tfMensajeError.setText("ERROR: El usuario o la clave no son correctos");
			tfMensajeError.setForeground(Color.red);
			tfMensajeError.setVisible(true);
		}
		else 
		{
			loginOk = true;
			this.dispose();
		}
	}

}
