package scada.ui;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JTextField;

import scada.excepciones.ValorConfiguracionException;

/**
 * Clase que hereda de JTextField y que nos permite tener campos de
 * texto que comprueban si su contenido es un n�mero o no. Se usa en
 * el formulario de configuraci�n de la aplicacion.
 * 
 * @see ConfigDialog 
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */
public class CampoNumerico extends JTextField
{
	/** 
	 * Guarda el nombre de la propiedad que almacena este campo.
	 */
	private String nombre;
	/**
	 * Valor inferior permitido en este campo
	 */
	private int desde = 0;
	/**
	 * Valor superior permitido en este campo
	 */
	private int hasta = 1000;
	
	/**
	 * Constructor de campos de texto num�rico. Tiene un listener que evita que
	 * podamos teclear otra cosa que no sean n�meros.
	 * @param nombre Nombre de la propiedad que almacena este campo para notificarla
	 *               en el mensaje de error.
	 */
	public CampoNumerico(String nombre, int desde, int hasta)
	{
		this();
		this.nombre = nombre;
		this.desde = desde;
		this.hasta = hasta;
		this.setToolTipText(nombre);
		this.addKeyListener(new KeyAdapter()
				{
					public void keyTyped(KeyEvent e)
					{
						if ((e.getKeyChar()<48 || e.getKeyChar()>57)  && e.getKeyChar()!=8)
							e.consume();
						else
						{
							String s = "";
							for(int x=0;x<getText().length();x++)
								if (getText().charAt(x)>=48 && getText().charAt(x)<=57)
									s+=getText().charAt(x);
							setText(s);
						}
					}
				});
	}
	
	/**
	 * Constructor de campos de texto num�rico
	 */
	public CampoNumerico()
	{
		setHorizontalAlignment(JTextField.CENTER);
		setText("0");
	}
	
	/**
	 * Permite establecer el valor del campo. Recae en la implementaci�n 
	 * del metodo <code>setText</code> del padre
	 * @param x El valor num�rico a guardar en el campo de texto
	 */
	public void setValor(int x)
	{
		this.setText(String.valueOf(x));
	}
	
	/**
	 * Permite obtener el valor del campo. Recae en la implementaci�n 
	 * del metodo <code>getText</code> del padre. Si el texto que contiene
	 * no se puede convertir a entero o no est� entre el rango determinado
	 * se lanza una excepcion.
	 * @exception scada.excepciones.ValorConfiguracionException Lanza una excepcion si
	 *            el campo no tiene un valor numerico correcto. 
	 */
	public int getValor() throws ValorConfiguracionException
	{
		try
		{
			int x = Integer.parseInt(this.getText());
			if (x>=desde && x<=hasta)
				return x;
			else 
				throw new Exception("");
		}
		catch(Exception e)
		{
			this.requestFocus();
			throw new ValorConfiguracionException("Valor no v�lido en la propiedad: "+nombre+". El rango v�lido es entre "+desde+" y "+hasta);
		}
	}	
}
