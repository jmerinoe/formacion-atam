package scada.ui;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

import scada.Scada;
/**
 * La aplicaci�n Scada muestra en la parte central de la ventana la simulaci�n
 * de la planta de fabricaci�n. Y en la parte inferior tiene un panel con los 
 * botones de acci�n para la aplicaci�n. Este panel inferior de control es
 * el que se crea con esta clase.
 * 
 * @see Scada
 * @see SimuladorPanel
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */
public class ControlPanel extends JPanel implements ActionListener
{
	/* Propiedades del interfaz de usuario */
	private JButton btnArrancar;
	private JButton btnConfigurar;
	private JButton btnParadaEmergencia;
	private JButton btnParadaNormal;
	private JButton btnInforme;
	
	/**
	 * Referencia al scada que contiene este panel
	 */
	private Scada scada;
	
	/**
	 * Crea el panel y le asigna como "padre" al scada
	 * @param s
	 */
	public ControlPanel(Scada s)
	{
		this.scada = s;
		this.setBackground(Color.white);
		
		int numBoton = 0;
		btnConfigurar = new JButton("Configurar", new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getClassLoader().getResource("imagenes/config.gif"))));
		btnArrancar = new JButton("Arrancar", new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getClassLoader().getResource("imagenes/arranque.gif"))));
		btnParadaNormal  = new JButton("<html>Parada <br>normal</html>", new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getClassLoader().getResource("imagenes/rayoAmarillo.gif"))));
		btnParadaEmergencia = new JButton("<html>Parada de<br>emergencia</html>", new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getClassLoader().getResource("imagenes/rayoRojo.gif"))));
		btnInforme = new JButton("Informe", new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getClassLoader().getResource("imagenes/icoBtnInforme.gif"))));
		btnArrancar.addActionListener(this);
		btnConfigurar.addActionListener(this);
		btnParadaEmergencia.addActionListener(this);
		btnParadaNormal.addActionListener(this);
		btnInforme.addActionListener(this);
		
		this.setLayout(new FlowLayout(0));
		this.add(btnConfigurar);
		this.add(btnArrancar);
		this.add(btnParadaNormal);
		this.add(btnParadaEmergencia);
		this.add(btnInforme);
		btnParadaNormal.setEnabled(false);
		btnParadaEmergencia.setEnabled(false);
		
		for(int x=0;x<this.getComponentCount();x++)
		{
			if (this.getComponent(x) instanceof JButton)
			{
				this.getComponent(x).setBackground(new Color(220,220,255));
				this.getComponent(x).setFocusable(false);
			}
		}		
	}
	
	/**
	 * M�todo que se llama cuando el usuario pulsa cualquier bot�n.
	 * Se decide seg�n el bot�n pulsado, qu� m�todo de scada de llama.
	 */
	public void actionPerformed(ActionEvent e)
	{
		if (e.getSource()==btnConfigurar)
			scada.botonConfigurar();
		else if (e.getSource()==btnArrancar)
			scada.botonArrancarPulsado();
		else if (e.getSource()==btnParadaEmergencia)
			scada.botonParadaEmergenciaUsuarioPulsado();
		else if (e.getSource()==btnParadaNormal)
			scada.botonParadaNormalUsuarioPulsado();
		else if (e.getSource()==btnInforme)
			scada.botonInformes();
	}

	public void habilitarBotonParadaNormal(boolean b)
	{
		btnParadaNormal.setEnabled(b);
	}

	public void habilitarBotonParadaEmergencia(boolean b)
	{
		btnParadaEmergencia.setEnabled(b);
	}

	public void habilitarBotonConfiguracion(boolean b)
	{
		btnConfigurar.setEnabled(b);
	}

	public void habilitarBotonArrancar(boolean b)
	{
		btnArrancar.setEnabled(b);
	}

	public void habilitarBotonInforme(boolean b)
	{
		btnInforme.setEnabled(b);
	}
}

