package scada.ui.elementos;

import java.awt.Component;
/**
 * Clase que dibuja un expulsor.
 * 
 * @see scada.Scada
 * @see ElementoGraficoConEstados
 * @see ElementoGrafico
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */
public class Expulsor extends ElementoGraficoConEstados 
{
	/**
	 * Constructor que crea un expulsor en cierta posici�n y con un tama�o
	 * determinado. Tambi�n recibe el componente que lo instancia y que lo
	 * dibujar�
	 * @param sp Componente que lo instancia
	 * @param px Posici�n horizontal
	 * @param py Posici�n vertical
	 * @param width Ancho del expulsor
	 * @param height Alto del expulsor
	 */
	public Expulsor(Component sp, int px, int py, int width, int height)
	{
		super(sp, "imagenes/expulsor.gif", "imagenes/expulsorAmarillo.gif", "imagenes/expulsorRojo.gif",
			  px, py, width, height);
	}
	
	/**
	 * M�todo que activa el expulsor durante medio segundo (cambia su representaci�n gr�fica)
	 */
	public void activar()
	{
		setFuncionando(true);
	    try { Thread.sleep(500); } catch(Exception e) { }
	    setFuncionando(false);
	}
}
