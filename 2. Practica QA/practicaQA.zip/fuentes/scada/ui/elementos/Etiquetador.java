package scada.ui.elementos;

import java.awt.Component;
/**
 * Clase que dibuja un etiquetador.
 * 
 * @see scada.Scada
 * @see ElementoGraficoConEstados
 * @see ElementoGrafico
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */
public class Etiquetador extends ElementoGraficoConEstados 
{
	/**
	 * Constructor de un etiquetador con imagenes seg�n su estado
	 * @param sp Componente que lo instancia
	 * @param px Posici�n horizontal
	 * @param py Posici�n vertical
	 */
	public Etiquetador(Component sp, int px, int py)
	{
		super(sp, "imagenes/etiquetador.gif", "imagenes/etiquetadorAmarillo.gif", "imagenes/etiquetadorRojo.gif",
			  px, py);
	}

}
