package scada.ui.elementos;

import java.awt.Component;
/**
 * Clase que dibuja un deposito de botes. Es una clase 
 * activa que siempre est� funcionando. Permite sacar botes a la cinta. 
 * 
 * @see scada.Scada
 * @see ElementoGraficoConEstados
 * @see ElementoGrafico
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */
public class DepositoBotes extends ElementoGraficoConEstados implements Runnable
{
	/**
	 * Hilo que controla la extracci�n de un nuevo bote para la cinta
	 */
	private Thread hiloExpulsion = null;
	
	/**
	 * Constructor que crea un deposito en cierta parte de la pantalla
	 * @param sp Componente sobre el cual se dibujar� el dep�sito
	 * @param px Posici�n horizontal
	 * @param py Posici�n vertical
	 */
	public DepositoBotes(Component sp, int px, int py)
	{
		super(sp, "imagenes/depositoBotes.gif", "imagenes/depositoBotesAmarillo.gif", "imagenes/depositoBotesRojo.gif",
			  px, py,0,0);
	}

	/**
	 * Inicia la animaci�n para sacar un nuevo bote
	 */
	public void sacarNuevoBote()
	{
		if (hiloExpulsion==null || (hiloExpulsion!=null && !hiloExpulsion.isAlive()))
		{
			hiloExpulsion = new Thread(this);
			hiloExpulsion.start();
		}
	}
	
	/**
	 * Tarea realizada al sacar el bote (vibra el contenedor)
	 */
	public void run()
	{
		// Agitamos el bote 5 veces en un segundo
		setFuncionando(true);
		while(estaFuncionando())
		{
			px++; try { Thread.sleep(1); } catch(Exception e) {}
			py++; try { Thread.sleep(1); } catch(Exception e) {}
			px--; try { Thread.sleep(1); } catch(Exception e) {}
			py--; try { Thread.sleep(1); } catch(Exception e) {}
		}
	}
}
