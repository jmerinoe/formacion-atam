package scada.ui.elementos;

import java.awt.Component;
import java.awt.Graphics;
/**
 * Clase que dibuja un llenador. Es una clase activa que controla su activaci�n para
 * cambiar su estado y dibujarlo de distinta forma.
 * 
 * @see scada.Scada
 * @see ElementoGraficoConEstados
 * @see ElementoGrafico
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */
public class Llenador extends ElementoGraficoConEstados implements Runnable
{
	/**
	 * Thread que controla la tarea de llenado
	 */
	private Thread hiloLlenado = null;
	/**
	 * Propiedad que indica el tiempo de llenado
	 */
	private int duracionLlenado;
	
	/**
	 * Constructor que crea un llenador en cierta posici�n y con cierto tama�o
	 * @param sp Componente que lo instancia
	 * @param px Posici�n horizontal
	 * @param py Posici�n vertical
	 * @param width Ancho
	 * @param height Alto
	 */
	public Llenador(Component sp, int px, int py, int width, int height)
	{
		super(sp, "imagenes/llenador.gif", "imagenes/llenadorAmarillo.gif", "imagenes/llenadorRojo.gif",
			  px, py, width, height);
	}
	
	/**
	 * Dibuja la imagen
	 * @param g Contexto gr�fico del elemento sobre el que se dibuja
	 */
	public void paint(Graphics g)
	{
		g.drawImage(this.imagenActual, px-(width/3)*2, py, width, height, padre);
	}
	
	/**
	 * Activa el proceso de llenado durante 'x' segundos
	 * @param duracion Tiempo en segundos que dura el llenado
	 */
	public void procesoLlenado(int duracion)
	{
		this.duracionLlenado = duracion;
		if (hiloLlenado==null || (hiloLlenado!=null && !hiloLlenado.isAlive()))
		{
			hiloLlenado = new Thread(this);
			hiloLlenado.start();
		}
	}
	
	/**
	 * Tarea de llenado: Basicamente mantiene el estado de llenando mientras dura.
	 */
	public void run()
	{
		setFuncionando(true);
		try { Thread.sleep(duracionLlenado*1000); } catch(Exception e) { }
	    setFuncionando(false);
	}
}
