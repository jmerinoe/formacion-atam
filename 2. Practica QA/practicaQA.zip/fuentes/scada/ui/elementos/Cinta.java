package scada.ui.elementos;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
/**
 * Clase que dibuja una cinta de transporte y que simula su movimiento girando
 * las ruedas a cierta velocidad. Es una clase activa que siempre est� funcionando.
 * Dependiendo del estado, se mueven o no las ruedas laterales.
 * 
 * @see scada.Scada
 * @see ElementoGrafico
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */
public class Cinta extends ElementoGrafico implements Runnable 
{
	/**
	 * Altura de la cinta
	 */
	private int height = 50;
	/**
	 * Anchura de la cinta
	 */
	private int width = 500;
	/**
	 * Posicion horizontal de la cinta
	 */
	private int px=100;
	/**
	 * Posicion vertical de la cinta
	 */
	private int py=100;
	/**
	 * Posicion de giro de la rueda (angulo)
	 */
	private int posGiroRueda = 0;
	/**
	 * Velocidad de giro de la rueda
	 */
	private int velocidad = 0;
	/**
	 * Hilo que gestionar� la tarea
	 */
	private Thread hilo = null;
	/**
	 * Para saber si el hilo est� o no funcionando
	 */
	private boolean threadAlive = false;
	/**
	 * Indica si la cinta est� o no girando
	 */
	private boolean girando = false;
	
	/**
	 * Constructor de la cinta
	 * @param padre Componente que lo instancia
	 * @param x Posicion horizontal
	 * @param y Posicion vertical
	 * @param ancho Ancho de la cinta en pixels
	 * @param alto Alto de la cinta en pixels
	 * @param velocidad Velocidad de giro
	 */
	public Cinta(Component padre, int x, int y, int ancho, int alto, int velocidad)
	{
		super(padre);
		this.height = alto;
		this.width = ancho;
		this.px = x;
		this.py = y;
		this.velocidad = velocidad;
		threadAlive = true;
		hilo = new Thread(this);
		hilo.start();
	}

	/**
	 * Este m�todo dibuja la cinta en el contexto gr�fico que se le pasa (normalmente
	 * el contexto gr�fico del elemento que lo instanci�)
	 */
	public void paint(Graphics g)
	{
		g.setColor(Color.blue);
		g.drawLine(px+(height/2), py, px+width+(height/2), py);
		g.drawLine(px+(height/2), py+height, px+width+(height/2), py+height);
		g.drawArc(px, py, height, height, 90, 180);
		g.drawArc(px+width, py, height, height, 270, 180);
	
		g.setColor(Color.blue);
		g.fillArc(px+2, py+2, height-4, height-4, 0+posGiroRueda, 180);
		g.setColor(new Color(120,160,255));		
		g.fillArc(px+2, py+2, height-4, height-4, 180+posGiroRueda, 180);
		
		g.setColor(Color.blue);
		g.fillArc(px+width+2, py+2, height-4, height-4, 0+posGiroRueda, 180);
		g.setColor(new Color(120,160,255));
		g.fillArc(px+width+2, py+2, height-4, height-4, 180+posGiroRueda, 180);
	}

	/**
	 * Metodo de la tarea que se encarga de ir moviendo las ruedas de la cinta
	 * a cierta velocidad.
	 */
	public void run()
	{
		while(threadAlive)
		{
			while(girando && threadAlive)
			{
				posGiroRueda=(posGiroRueda+(2*(velocidad/10))) % 360;
				try { Thread.sleep(50); }
				catch (InterruptedException e) {}
			}
			try { Thread.sleep(50); }
			catch (InterruptedException e) {}		
		}
	}
	
	/**
	 * Permite destruir la tarea
	 */
	public void destruirTarea()
	{
		threadAlive=false;
	}
	
	protected void finalize() throws Throwable
	{
		destruirTarea();
		super.finalize();
	}
	
	/**
	 * Pone la cinta en movimiento
	 */
	public void arrancarCinta()
	{
		girando = true;
	}

	/**
	 * Detiene la cinta 
	 */
	public void pararCinta()
	{
		girando = false;
	}
	
	/**
	 * Dice si la cinta est� o no girando
	 * @return Si la cinta gira o no
	 */
	public boolean estaGirando()
	{
		return girando && threadAlive;
	}
	
	/**
	 * Retorna el ancho de la cinta
	 * @return Ancho de la cinta
	 */
	public int getAncho()
	{
		return width;
	}
}
