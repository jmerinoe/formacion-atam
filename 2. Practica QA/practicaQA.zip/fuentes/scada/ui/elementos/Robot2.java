package scada.ui.elementos;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Image;
/**
 * Clase que dibuja un robot de transporte de movimiento horizontal. Es una clase
 * activa que mueve el robot con el bote. Al llegar, el bote cae por efecto de la
 * gravedad (tambi�n se anima)
 * 
 * @see scada.Scada
 * @see ElementoGraficoConEstados
 * @see ElementoGrafico
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */
public class Robot2 extends ElementoGraficoConEstados implements Runnable 
{		
	/**
	 * Hilo que maneja la animaci�n
	 */
	private Thread hilo = null;
	/**
	 * Propiedad que indica si se est� o no transportando bote
	 */
	private boolean transportando = false;
	/**
	 * Posici�n horizontal desde la que se parte con el bote
	 */
	private int desde;
	/**
	 * Posici�n horizontal hasta la que se llega con el bote
	 */
	private int hasta;
	/**
	 * Duraci�n del transporte
	 */
	private int duracion;
	/**
	 * Imagen del bote que se transporta
	 */
	private Image bote;
	/**
	 * Indica si el robot est� o no parado
	 */
	private boolean pararRobot=false;
	/**
	 * Indica si el bote est� cayendo (efecto de la gravedad, que tambien se simula)
	 */
	private boolean cayendoBote = false;
	/**
	 * Altura por la que va el bote al caer
	 */
	private float alturaBote;
	
	/**
	 * Constructor del robot
	 * @param sp Componente que lo dibuja
	 * @param px Posici�n horizontal
	 * @param py Posici�n vertical
	 */
	public Robot2(Component sp, int px, int py)
	{
		super(sp, "imagenes/robot2.gif", "imagenes/robot2Amarillo.gif", "imagenes/robot2Rojo.gif",
			  px, py);
		this.bote = cargarImagen("imagenes/imgBoteEtiquetado.gif");
	}

	/**
	 * Inicia la animaci�n de transporte
	 * @param desde Posici�n horizontal desde la que se mueve
	 * @param hasta Posici�n horizontal hasta la que se mueve
	 * @param tiempoTransporte Tiempo que dura el transporte
	 */
	public synchronized void iniciarTransporte(int desde, int hasta, int tiempoTransporte)
	{
		if (hilo==null || !hilo.isAlive())
		{
			transportando = true;
			pararRobot=false;
			this.desde = desde;
			this.hasta = hasta;
			this.duracion = tiempoTransporte;
			hilo = new Thread(this);
			hilo.start();
		}
	}

	/**
	 * Finaliza la acci�n de transporte.
	 */
	public void finTransporte()
	{
		transportando = false;
		hilo=null;
	}
	
	/**
	 * Dibuja el robot con su bote (si lo lleva)
	 */
	public void paint(Graphics g)
	{
		super.paint(g);
		if (transportando)
			g.drawImage(bote, Math.round(px+10), Math.round(py+imagenActual.getHeight(padre)), 20,20,padre);
		if (cayendoBote)
			g.drawImage(bote, hasta, Math.round(py+imagenActual.getHeight(padre)+alturaBote), 20,20,padre);
	}

	/**
	 * Metodo del thread que se encarga de la animaci�n del trasnporte.
	 */
	public void run()
	{
		setFuncionando(true);
		int valorPx = px;
		px=desde;
		float posicionEnDecimal = desde;
		while(transportando && px>hasta && !pararRobot)
		{
			posicionEnDecimal-=(25.0f*Math.abs(hasta-desde))/(duracion*1000.0f);
			px = Math.round(posicionEnDecimal);
			try { Thread.sleep(25); } catch (InterruptedException e) {}
		}
		// Dejamos caer el bote
		new Thread()
		{
			public void run()
			{
				cayendoBote=true;
				for(alturaBote=0;alturaBote<45;alturaBote++)
					try { Thread.sleep(12); } catch(Exception ex) {}
				cayendoBote=false;	
			}
		}.start();
		// Avanzamos el robot a la pos. inicial
		transportando=false;
		while(px<desde && !pararRobot)
		{
			px += 10;
			try { Thread.sleep(50); } catch (InterruptedException e) {}
		}
		if (!pararRobot)
		{
			px=valorPx;
			setFuncionando(false);
		}
	}

	/**
	 * M�todo que permite para el robot como est�.
	 */
	public void pararRobot()
	{
		pararRobot=true;		
	}

}
