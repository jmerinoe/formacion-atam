package scada.ui.elementos;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Image;
/**
 * Clase que dibuja un bote sobre una cinta de transporte o en un robot. Es una clase 
 * activa que siempre est� funcionando para calcular la posici�n donde deber�a estar.
 * La posici�n horizontal es la �nica que se altera. 
 * 
 * @see scada.Scada
 * @see ElementoGraficoConEstados
 * @see ElementoGrafico
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */
public class Bote extends ElementoGrafico implements Runnable 
{	
	/**
	 * Constante para indicar el estado del bote y dibujarlo acorde al mismo
	 */
	public static final int VACIO 		= 1;
	/**
	 * Constante para indicar el estado del bote y dibujarlo acorde al mismo
	 */
	public static final int LLENO 		= 2;
	/**
	 * Constante para indicar el estado del bote y dibujarlo acorde al mismo
	 */
	public static final int TAPADO 		= 3;
	/**
	 * Constante para indicar el estado del bote y dibujarlo acorde al mismo
	 */
	public static final int ETIQUETADO	= 4;
	
	/**
	 * Imagen del bote que se dibjua en este momento
	 */
	private Image boteActual;
	/**
	 * Imagen del bote vacio
	 */
	private Image boteVacio;
	/**
	 * Imagen del bote lleno
	 */
	private Image boteLleno;
	/**
	 * Imagen del bote tapado
	 */
	private Image boteTapado;
	/**
	 * Imagen del bote etiquetado
	 */
	private Image boteEtiquetado;
	/**
	 * Posicion vertical del bote
	 */
	private int py;
	/**
	 * Posicion horizontal del bote
	 */
	private float px;
	/**
	 * Origen del bote
	 */
	private int desde;
	/**
	 * Destino final del bote
	 */
	private int hasta;
	/**
	 * Longitud de la cinta en metros
	 */
	private int longCinta;
	/**
	 * Velocidad de la cinta en metros por minuto
	 */
	private int velocCinta;
	/**
	 * Hilo que controla la tarea de avanzar el bote
	 */
	private Thread hilo = null;
	/**
	 * Propiedad que indica si el hilo est� funcionando o no
	 */
	private boolean hiloFuncionando=false;
	/**
	 * Referencia a la cinta que gobierna el bote
	 */
	private Cinta cinta = null;
	
	/**
	 * Constructor de la clase. 
	 * @param sp Componente que lo instanci� y que pintar� en su contexto gr�fico
	 * @param pxDesde Posicion horizontal origen
	 * @param pxHasta Posicion horizontal destino
	 * @param py Posici�n vertical (no var�a)
	 * @param longCinta Longitud de la cinta en metros
	 * @param velocCinta Velocidad de la cinta en metros por minuto
	 * @param c Cinta sobre la que est� el bote (para moverlo s�lo si �sta se mueve)
	 *
	 */
	public Bote(Component sp, int pxDesde, int pxHasta, int py, int longCinta, int velocCinta, Cinta c)
	{
		super(sp);
		boteVacio = cargarImagen("imagenes/imgBoteVacio.gif");
		boteLleno = cargarImagen("imagenes/imgBoteLleno.gif");
		boteTapado = cargarImagen("imagenes/imgBoteTapado.gif");
		boteEtiquetado = cargarImagen("imagenes/imgBoteEtiquetado.gif");
		boteActual = null;
		this.py=py;
		this.px=desde;
		this.desde = pxDesde;
		this.hasta = pxHasta;
		this.longCinta = longCinta;
		this.velocCinta = velocCinta;
		this.cinta = c;
		hiloFuncionando=true;
		hilo = new Thread(this);
		hilo.start();		
	}

	/**
	 * Dibuja sobre un contexto gr�fico el bote (imagen que depende de su estado)
	 * @param g Contexto gr�fico del objeto donde se pinta el bote
	 */
	public void paint(Graphics g)
	{
		if (boteActual!=null)
			g.drawImage(boteActual, Math.round(px), py, 20, 20, padre);
	}

	/**
	 * Quita el bote de la cinta
	 */
	public void quitarBote()
	{
		boteActual=null;
		px = desde;		
	}
	
	/**
	 * Coloca un bote al principio de la cinta
	 */
	public void ponerBote()
	{
		if (boteActual==null)
		{
			px = desde;
			boteActual = boteVacio;
		}
	}

	/**
	 * Tarea del hilo. Si la cinta se mueve, avanza el bote el n�mero de
	 * pixels adecuado a la velocidad.
	 */
	public void run()
	{
		int ciclo=25;
		while(hiloFuncionando)
		{
			while(boteActual!=null && cinta!=null && cinta.estaGirando() && hiloFuncionando)
			{
				float avance = (ciclo*velocCinta)/60000.0f; // En metros
				avance = (avance*(cinta.getAncho()))/longCinta; // En pixeles
				if (desde<hasta)
				{
					px=px+avance;
					if (px>=hasta)
						px=hasta;
				}
				else
				{
					px=px-avance;
					if (px<=hasta)
						px=hasta;
				}try { Thread.sleep(ciclo); } catch (InterruptedException e) {}
			}
			try { Thread.sleep(ciclo); } catch (InterruptedException e) {}
		}
	}

	/**
	 * Cambia el estado del bote para pintarlo de otra forma.
	 * @param x Estado del bote. Definido en las constantes de la clase
	 */
	public void setEstado(int x)
	{
		switch(x)
		{
			case VACIO		: if (boteActual!=null) boteActual = boteVacio;break;
			case LLENO		: if (boteActual!=null) boteActual = boteLleno;break;
			case TAPADO		: if (boteActual!=null) boteActual = boteTapado;break;
			case ETIQUETADO	: if (boteActual!=null) boteActual = boteEtiquetado;break;
		}
	}

	/**
	 * Coloca el bote en una posici�n horizontal
	 * @param i Posici�n del bote
	 */
	public void setPosicionBote(int i)
	{
		this.px = i;
	}

	/**
	 * Devuelve la posici�n horizonal del bote
	 * @return Posici�n horizontal del bote
	 */
	public int getPosicion()
	{
		return Math.round(px);
	}
	
	/** 
	 * Destruye el hilo de la tarea
	 */
	public void destruirTarea()
	{
		
	}
	
}
