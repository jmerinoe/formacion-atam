package scada.ui.elementos;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Image;
/**
 * Clase que dibuja una mesa sobre la cual se expulsar�n botes. 
 * 
 * @see scada.Scada
 * @see ElementoGrafico
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */
public class MesaExpulsion extends ElementoGrafico
{
	/**
	 * Posicion horizontal
	 */
	private int px;
	/**
	 * Posici�n vertical
	 */
	private int py;
	/**
	 * Imagen de la mesa
	 */
	private Image img;

	/**
	 * Construye una mesa
	 * @param padre Componente que lo instancia y sobre el cual se dibujar�
	 * @param px Posici�n horizontal
	 * @param py Posici�n vertical
	 */
	public MesaExpulsion(Component padre, int px, int py)
	{
		super(padre);
		this.px = px;
		this.py = py;
		this.img = cargarImagen("imagenes/mesa.gif");
	}

	/**
	 * Dibuja la mesa en su posici�n
	 * @param g Contexto gr�fico del elemento donde se dibujar�
	 */
	public void paint(Graphics g)
	{
		g.drawImage(img, px, py, padre);
	}
}
