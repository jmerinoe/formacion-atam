package scada.ui.elementos;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Image;

/**
 * Clase que dibuja un robot de transporte de movimiento vertical. Es una clase
 * activa que mueve el robot con el bote 
 * 
 * @see scada.Scada
 * @see ElementoGraficoConEstados
 * @see ElementoGrafico
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */
public class Robot1 extends ElementoGraficoConEstados implements Runnable 
{		
	/**
	 * Hilo que maneja la animaci�n
	 */
	private Thread hilo = null;
	/**
	 * Propiedad que indica si se est� transportando bote o no.
	 */
	private boolean transportando = false;
	/**
	 * Posici�n vertical desde donde se parte
	 */
	private int desde;
	/**
	 * Posici�n vertical hasta donde se ha de llevar el bote
	 */
	private int hasta;
	/**
	 * Duraci�n del transporte en segundos
	 */
	private int duracion;
	/**
	 * Imagen del bote que se transporta
	 */
	private Image bote;
	/**
	 * Indica si se ha de parar o no el robot
	 */
	private boolean pararRobot=false;
	
	/**
	 * Constructor del robot
	 * @param sp Componente sobre el que se dibujar�
	 * @param px Posici�n horizontal
	 * @param py Posici�n vertical
	 */
	public Robot1(Component sp, int px, int py)
	{
		super(sp, "imagenes/robot1.gif", "imagenes/robot1Amarillo.gif", "imagenes/robot1Rojo.gif",
			  px, py);
		this.bote = cargarImagen("imagenes/imgBoteLleno.gif");
	}

	/**
	 * Metodo que inicia la simulaci�n de transporte del bote
	 * @param desde Posici�n vertical desde la cual mover el bote
	 * @param hasta Posici�n horizontal hasta la cual mover el bote
	 * @param tiempoTransporteEntreCintas Tiempo que dura el transporte en seg.
	 */
	public synchronized void iniciarTransporte(int desde, int hasta, int tiempoTransporteEntreCintas)
	{
		if (hilo==null || !hilo.isAlive())
		{
			transportando = true;
			this.desde = desde;
			this.hasta = hasta;
			this.duracion = tiempoTransporteEntreCintas;
			hilo = new Thread(this);
			hilo.start();
		}
	}

	/**
	 * Termina la animaci�n de transporte
	 *
	 */
	public void finTransporte()
	{
		transportando = false;
	}
	
	/**
	 * Dibuja al robot trasnsportando el bote
	 * @param g Contexto gr�fico del elemento donde se dibujar� el robot
	 */
	public void paint(Graphics g)
	{
		super.paint(g);
		if (transportando)
			g.drawImage(bote, Math.round(px+7), Math.round(py+15), 20,20,padre);
	}

	/** 
	 * M�todo de la tarea que se encarga de la animaci�n
	 */
	public void run()
	{
		setFuncionando(true);
		int valorPy = py;
		py=desde;
		float posicionEnDecimal=desde;
		while(transportando && py<hasta && !pararRobot)
		{
			if (pararRobot)
				return;
			posicionEnDecimal+=(25*(hasta-desde))/(duracion*1000.0f);
			py = Math.round(posicionEnDecimal);
			try { Thread.sleep(25); } catch (InterruptedException e) {}
		}
		while(transportando && !pararRobot)
			try { Thread.sleep(25); } catch (InterruptedException e) {}
		for(int x=py; !pararRobot && x>valorPy; x-=10)
		{
			py=x;	
			try { Thread.sleep(5); } catch (InterruptedException e) {}
		}
		if (!pararRobot)
		{
			py=desde;
			setFuncionando(false);
		}
	}

	/**
	 * M�todo que para el robot donde est�
	 */
	public void pararRobot()
	{
		pararRobot = true;		
	}

}
