package scada.ui.elementos;

import java.awt.Component;
/**
 * Clase que dibuja un detector.
 * 
 * @see scada.Scada
 * @see ElementoGraficoConEstados
 * @see ElementoGrafico
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */
public class Detector extends ElementoGraficoConEstados 
{
	/**
	 * Constructor de la clase que crea el detector con las im�genes para cada estado
	 * @param sp Componente que lo instanci�
	 * @param px Posici�n horizontal
	 * @param py Posici�n vertical
	 */
	public Detector(Component sp, int px, int py)
	{
		super(sp, "imagenes/detector.gif", "imagenes/detectorAmarillo.gif", "imagenes/detectorRojo.gif",
			  px, py, 0, 0);
	}
		
}
