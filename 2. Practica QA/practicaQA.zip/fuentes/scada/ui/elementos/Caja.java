package scada.ui.elementos;

import java.awt.Component;
/**
 * Clase que dibuja una caja. La caja que se dibuja depende del estado. El estado
 * se puede cambiar con los m�todos heredados de <i>ElementoGraficoConEstados</i>
 * 
 * @see scada.Scada
 * @see ElementoGraficoConEstados
 * @see ElementoGrafico
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */
public class Caja extends ElementoGraficoConEstados 
{
	/**
	 * Constructor que crea una caja con las imagenes para sus estados
	 * @param sp Componente que la instancia y sobre el cual se dibuja la caja
	 * @param px Posici�n horizontal
	 * @param py Posicion vertical
	 */
	public Caja(Component sp, int px, int py)
	{
		super(sp, "imagenes/caja.gif", "imagenes/cajaAmarilla.gif", "imagenes/cajaRoja.gif",
			  px, py,0,0);
	}
}
