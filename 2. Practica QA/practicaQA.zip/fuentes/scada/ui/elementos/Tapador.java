package scada.ui.elementos;

import java.awt.Component;
/**
 * Clase activa que dibuja una tapado y anima la acci�n de tapar 
 * 
 * @see scada.Scada
 * @see ElementoGrafico
 * @see ElementoGraficoConEstados
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */
public class Tapador extends ElementoGraficoConEstados implements Runnable
{
	/**
	 * Hilo que maneja la animaci�n de tapado
	 */
	private Thread hiloTapado = null;
	
	/**
	 * Constructor que crea un tapador situado en cierta posici�n
	 * @param sp Componente que dibujar� el tapador y que lo instancia
	 * @param px Posici�n horizontal
	 * @param py Posici�n vertical
	 */
	public Tapador(Component sp, int px, int py)
	{
		super(sp, "imagenes/taponador.gif", "imagenes/taponadorAmarillo.gif", "imagenes/taponadorRojo.gif",
			  px, py);
	}

	/**
	 * Inicia la animaci�n de tapado
	 */
	public void tapar()
	{
		if (hiloTapado==null || !hiloTapado.isAlive())
		{
			hiloTapado = new Thread(this);
			hiloTapado.start();
		}
	}
	
	/**
	 * Metodo que ejecuta la tarea para bajar y subir el tapador y asi realizar la
	 * animaci�n.
	 */
	public void run()
	{
		setFuncionando(true);
		for(int y=0;y<40;y++)
		{
			py++;
			try { Thread.sleep(5); } catch(Exception e) {}
		}
		for(int y=0;y<40;y++)
		{
			py--;
			try { Thread.sleep(2); } catch(Exception e) {}
		}
		setFuncionando(false);
	}
	
}
