package scada.ui.elementos;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Toolkit;
/**
 * Clase abstracta que representa un elemento gr�fico a dibujar sobre
 * un panel o un canvas. Siempre recibe la referencia del panel donde
 * se dibujar� en el constructor. Tambi�n tiene un m�todo que le
 * permite cargar im�genes. Se le obliga a implementar a su manera, mediante
 * un m�todo abstracto, la forma de dibujarse (metodo <i>paint</i>)
 * 
 * @see scada.Scada
 * @see ElementoGraficoConEstados
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */
public abstract class ElementoGrafico
{
	/**
	 * Componente que lo dibujar�
	 */
	protected Component padre;
	
	/**
	 * Constructor de la clase
	 * 
	 * @param padre Componente en el cual se dibujar�
	 */
	public ElementoGrafico(Component padre)
	{
		this.padre = padre;
	}
	
	/**
	 * Metodo protegido que permite a cualquier clase cargar una imagen localizada
	 * en el classpath de la aplicaci�n.
	 * 
	 * @param s Ruta a la imagen (como recurso en el classpath)
	 * @return Un objeto Image con la imagen cargada
	 */
	protected Image cargarImagen(String s)
	{
		Image i = Toolkit.getDefaultToolkit().getImage(getClass().getClassLoader().getResource(s));
		MediaTracker mt = new MediaTracker(padre);
		mt.addImage(i,1);
		try { mt.waitForAll(); } catch (InterruptedException e) {}
		return i;
	}	
	
	/**
	 * M�todo abstracto que deber sobreescribir todas sus subclases para ver
	 * c�mo se pinta el componente sobre el padre.
	 * @param g Contexto gr�fico donde se pintar� (debe ser el del componente que
	 * lo instanci�)
	 */
	public abstract void paint(Graphics g);
}
