package scada.ui.elementos;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Image;
/**
 * Clase que dibuja un bote "volando". Es una clase activa que se encarga de la animaci�n
 * del bote al ser expulsado a la caja, la mesa o la caja de embalaje. Solo altera su
 * posici�n vertical. 
 * 
 * @see scada.Scada
 * @see ElementoGrafico
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */
public class BoteVolador extends ElementoGrafico implements Runnable 
{	
	/**
	 * Imagen del bote que va volando
	 */
	private Image bote;
	/**
	 * Posici�n vertical del bote
	 */
	private int py;
	/**
	 * Posici�n horizontal del bote
	 */
	private int px;
	/**
	 * Posici�n vertical desde donde parte el bote
	 */
	private int pydesde;
	/**
	 * Posici�n vertical hasta donde va el bote
	 */
	private int pyhasta;
	/**
	 * Tama�o del bote (altura)
	 */
	private int tamano=20;
	/**
	 * Thread que controla la tarea
	 */
	private Thread hilo = null;
	/**
	 * Indica si el bote est� volando en estos momentos
	 */
	private boolean volando = false;
		
	/**
	 * Constructor de la clase
	 * @param sp Componente sobre el cual se dibujar� el bote
	 * @param bote Imagen del bote que se trasladar�
	 */
	public BoteVolador(Component sp, String bote)
	{
		super(sp);
		this.bote = cargarImagen(bote);
	}

	/**
	 * Se dibuja el bote en un contexto gr�fico
	 * @param g Contexto gr�fico del componente que instancia la tarea
	 */
	public void paint(Graphics g)
	{
		if (volando)
			g.drawImage(bote, px, py, tamano, tamano, padre);
	}

	/**
	 * M�todo que se llama para activar la tarea y comenzar la animaci�n
	 * @param px Posici�n horizontal
	 * @param pydesde Posici�n vertical desde la que se parte
	 * @param pyhasta Posici�n vertical a la que debe llegarse.
	 */
	public void expulsarBote(int px, int pydesde, int pyhasta)
	{
		if (hilo==null || !hilo.isAlive())
		{
			this.pydesde = pydesde;
			this.pyhasta = pyhasta;
			this.px = px;
			hilo = new Thread(this);
			hilo.start();
		}
	}
	
	/**
	 * Metodo donde se localiza la tarea a realizar: Ir moviendo el bote de posici�n
	 * y alterando su tama�o para que parezca que se mueve. 
	 */
	public void run()
	{
		volando = true;
		float tamanoB = 20.0f;
		for(int x=pydesde;x<pyhasta;x++)
		{
			if (x<pydesde+Math.abs(pydesde-pyhasta)/2)
				tamanoB += 40.0f / Math.abs(pydesde-pyhasta)/2;
			else
				tamanoB -= 40.0f / Math.abs(pydesde-pyhasta)/2;
			tamano = Math.round(tamanoB);
			py=x;
			try { Thread.sleep(10); } catch(Exception ex) {}
		}
		try { Thread.sleep(1000); } catch(Exception ex) {}
		volando=false;
	}
}
