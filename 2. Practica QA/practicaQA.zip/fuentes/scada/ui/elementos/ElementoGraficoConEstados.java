package scada.ui.elementos;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.MediaTracker;
/**
 * Clase abstracta que representa un elemento gr�fico con estados. Para ello
 * carga tres im�genes: Una cuando esta parado pero ok, otra para cuando est�
 * actuando y otra para cuando est� parado y no est� ok. Dependiendo se su
 * estado, deber�a pintar una imagen u otra.
 * 
 * @see scada.Scada
 * @see ElementoGrafico
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */
public abstract class ElementoGraficoConEstados extends ElementoGrafico
{
	/**
	 * Imagen que se muestra actualmente y que est� asociada al estado actual
	 */
	protected Image imagenActual = null;
	/**
	 * Posici�n en eje de abcisas de la imagen en el contexto gr�fico donde dibujaremos
	 */
	protected int px;
	/**
	 * Posici�n en el eje de ordenadas de la imagen en el contexto gr�fico donde dibujaremos
	 */
	protected int py;
	/**
	 * Ancho de la imagen
	 */
	protected int width;
	/**
	 * Alto de la imagen
	 */
	protected int height;
	/**
	 * Imagen en el estado normal
	 */	
	private Image imagen;
	/**
	 * Imagen en el estado actuando
	 */	
	private Image imagenAmarillo;
	/**
	 * Imagen en el estado detenido
	 */	
	private Image imagenRojo;
	/**
	 * Propiedad que nos dice si el elemento est� o no funcionando
	 */
	private boolean estaFuncionando=false;
	/**
	 * Propiedad que nos dice si el elemento est� o no parado 
	 */
	private boolean estaParado=false;
	
	/**
	 * Constructor que recibe el componente gr�fico que instancia el elemento y donde
	 * se dibujar� �ste, as� como las imagenes, su posici�n y tama�o.
	 * @param c Componente sobre el que se dibujar� (panel padre)
	 * @param recurso Nombre del recurso con la imagen normal
	 * @param recursoAmarillo Nombre del recurso con la imagen de actuando
	 * @param recursoRojo Nombre del recurso con la imagen detenido
	 * @param px Posicion x de la imagen
	 * @param py Posicion y de la imagen
	 * @param width Ancho de la imagen
	 * @param height Alto de la imagen
	 */
	protected ElementoGraficoConEstados(Component c, String recurso, String recursoAmarillo, String recursoRojo, int px, int py, int width, int height)
	{
		super(c);
		this.px = px;
		this.py = py;
		this.width = width;
		this.height = height;
		// Cargamos la imagen original
		this.imagen = cargarImagen(recurso);
		this.imagenAmarillo = cargarImagen(recursoAmarillo);
		this.imagenRojo = cargarImagen(recursoRojo);
		MediaTracker mt = new MediaTracker(padre);
		mt.addImage(this.imagen,1);
		mt.addImage(this.imagenRojo,2);
		mt.addImage(this.imagenAmarillo,3);
		try { mt.waitForAll(); } catch (InterruptedException e) {}
		setFuncionando(false);
	}

	/**
	 * Constructor que llama al anterior. Es para cuando no se especifica alto ni
	 * ancho de imagen: Se toma el que tiene de por s� la imagen.
	 * 
	 * @param c Componente sobre el que se dibujar� (panel padre)
	 * @param recurso Nombre del recurso con la imagen normal
	 * @param recursoAmarillo Nombre del recurso con la imagen de actuando
	 * @param recursoRojo Nombre del recurso con la imagen detenido
	 * @param px Posicion x de la imagen
	 * @param py Posicion y de la imagen
	 */
	protected ElementoGraficoConEstados(Component c, String recurso, String recursoAmarillo, String recursoRojo, int px, int py)
	{
		this(c, recurso, recursoAmarillo, recursoRojo, px, py, 0, 0);
	}

	/**
	 * Permite cambiar el estado del elemento: Funcionando o no
	 * @param f Estado al que pasar�
	 */
	public void setFuncionando(boolean f)
	{
		estaFuncionando = f;
		if (estaFuncionando)
		{
			imagenActual=imagenAmarillo;
			estaParado = false;
		}
		else
			imagenActual=imagen;
	}
	
	/**
	 * Permite cambiar el estado del elemento: Parado o no
	 * @param f Estado al que pasar�
	 */
	public void setParado(boolean f)
	{
		estaParado = f;
		if (estaParado)
			imagenActual=imagenRojo;
		else if (estaFuncionando)
			imagenActual=imagenAmarillo;
		else
			imagenActual=imagen;
	}
	
	/**
	 * Permite activar el elemento un tiempo para que se muestre la 
	 * imagen de actuando durante ciertos milisengundos
	 * @param milisegundos Tiempo que dura la actuaci�n
	 */
	public void activarUnTiempo(final long milisegundos)
	{
		new Thread()
		{
			public void run() 
			{ 
				setFuncionando(true);
				try { Thread.sleep(milisegundos); } catch(Exception e) {}
				setFuncionando(false);				
			}
		}.start();
	}
	
	/**
	 * M�todo que permite consultar si est� o no funcionando 
	 * @return Si funciona o no
	 */
	public boolean estaFuncionando()
	{
		return estaFuncionando;
	}

	/**
	 * M�todo que permite consultar si est� o no parado 
	 * @return Si est� parado o no
	 */
	public boolean estaParado()
	{
		return estaParado;
	}
	
	/**
	 * M�todo que se encargar de dibujar la imagen en el contexto gr�fico que se
	 * le pasa
	 * 
	 * @param g Contexto gr�fico del panel o canvas sobre el que se dibujar�
	 */
	public void paint(Graphics g)
	{
		if (width>0 && height>0)
			g.drawImage(this.imagenActual, px, py, width, height, padre);
		else 
		{
			g.drawImage(this.imagenActual, px, py, padre);
		}
	}
}
