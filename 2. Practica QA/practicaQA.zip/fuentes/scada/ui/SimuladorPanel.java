package scada.ui;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;

import scada.Scada;
import scada.ui.elementos.Bote;
import scada.ui.elementos.BoteVolador;
import scada.ui.elementos.Caja;
import scada.ui.elementos.Cinta;
import scada.ui.elementos.DepositoBotes;
import scada.ui.elementos.Detector;
import scada.ui.elementos.Etiquetador;
import scada.ui.elementos.Expulsor;
import scada.ui.elementos.Llenador;
import scada.ui.elementos.MesaExpulsion;
import scada.ui.elementos.Robot1;
import scada.ui.elementos.Robot2;
import scada.ui.elementos.Tapador;
/**
 * La aplicaci�n Scada muestra en la parte central de la ventana la simulaci�n
 * de la planta de fabricaci�n. Y en la parte inferior tiene un panel con los 
 * botones de acci�n para la aplicaci�n. El panel de la simulaci�n es el que 
 * se crea con esta clase.
 * Contiene muchos m�todos que llama el Scada para afectar a la simulaci�n de una
 * forma u otra (activar animaciones, mover elementos, etc.)
 * 
 * @see Scada
 * @see ControlPanel
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */

public class SimuladorPanel extends JPanel implements Runnable 
{
	/**
	 * Scada que es el frame que contiene este panel. Mantener esta referencia
	 * nos permite llamar a los m�todos p�blicos de �ste.
	 */
	private Scada scada;

	/* Elementos gr�ficos que se emplean para dibujar la cadena */
	private Cinta cinta1 = null;
	private Cinta cinta2 = null;
	private DepositoBotes depositoBotes = null;
	private Llenador llenador = null;
	private Tapador taponador = null;
	private Expulsor expulsorC1 = null;
	private Expulsor expulsorC2 = null;
	private Etiquetador etiquetador = null;
	private Detector detectorBotesLlenos = null;
	private Detector detectorBotesMalTapados = null;
	private Robot1 robotC1 = null;
	private Robot2 robotC2 = null;
	private Bote boteC1 = null;
	private Bote boteC2 = null;
	private MesaExpulsion mesa = null;
	private Caja cajaMalLlenados=null, cajaBotesAcabados=null;
	private BoteVolador boteExpulsadoC1=null, boteExpulsadoC2=null;
	
	/**
	 * Inicializa todo y arranca el hilo que se encarga de repintar la pantalla.
	 * @param s Scada (que es un JFrame) que contiene este panel
	 */
	public SimuladorPanel(Scada s)
	{
		this.scada = s;
		inicializar();
        Thread hiloRepintado = new Thread(this);
        hiloRepintado.start();
	}
	
	/**
	 * Inicializa las cintas, botes, y resto de elementos de la cadena de producci�n
	 *
	 */
	public void inicializar()
	{
		cinta1 = new Cinta(this, 100,100,500,50,-scada.getConfiguracion().getVelocidadCintaLlenado());
		cinta2 = new Cinta(this, 100,400,500,50,scada.getConfiguracion().getVelocidadCintaTaponado());

		depositoBotes = new DepositoBotes(this, 60,20);
		llenador = new Llenador(this, 250, 20, 60, 60);
		detectorBotesLlenos = new scada.ui.elementos.Detector(this,400,20);
		expulsorC1 = new Expulsor(this, 470, 20, 40, 80);
		cajaMalLlenados = new Caja(this, 425, 160);

		robotC1 = new Robot1(this, 605, 60);
		
		taponador = new Tapador(this, 460-15, 280);
		etiquetador = new Etiquetador(this,280,350);
		detectorBotesMalTapados = new Detector(this,233-20,325);
		expulsorC2 = new Expulsor(this, 188-20, 320, 40, 80);
		mesa = new MesaExpulsion(this, 168, 450);
		cajaBotesAcabados  = new Caja(this, 0, 400);
		robotC2 = new Robot2(this, 100, 280);

		boteC1 = new Bote(this, 100, 600, 80,
								scada.getConfiguracion().getLongitudCintaLlenado(),
								scada.getConfiguracion().getVelocidadCintaLlenado(),cinta1);

		boteC2 = new Bote(this, 
						  600, 100, 380,
						  scada.getConfiguracion().getLongitudCintaTaponado(),
						  scada.getConfiguracion().getVelocidadCintaTaponado(),cinta2);
		
		boteC1.setEstado(Bote.VACIO);
		boteC2.setEstado(Bote.LLENO);

		
		boteExpulsadoC1 = new BoteVolador(this, "imagenes/imgBoteLleno.gif");
		boteExpulsadoC2 = new BoteVolador(this, "imagenes/imgBoteTapado.gif");
	}
	
	/**
	 * M�todo que se encarga de pintar los elementos gr�ficos
	 */
	public void paint(Graphics g)
	{
		// Ponemos el fondo blanco para borrar todo
		g.setColor(Color.white);
		g.fillRect(0,0,this.getSize().width, this.getSize().height);
		// Dibujamos el deposito de botes
		depositoBotes.paint(g);
		// Dibujamos el llenador de botes
		llenador.paint(g);
		// Dibujamos el detector de botes llenos
		detectorBotesLlenos.paint(g);
		// Dibujamos el expulsor de botes mal llenados
		expulsorC1.paint(g);
		// Dibujamos la caja de botes mal llenados
		cajaMalLlenados.paint(g);
		// Dibujamos el taponador
		taponador.paint(g);
		// Dibujamos el etiquetador
		etiquetador.paint(g);
		// Dibujamos el detector
		detectorBotesMalTapados.paint(g);
		// Dibujamos el expulsor
		expulsorC2.paint(g);
		// Dibujamos la mesa de expulsion
		mesa.paint(g);
		// Dibujamos la caja del final
		cajaBotesAcabados.paint(g);
		// Dibujamos las cintas
		cinta1.paint(g);
		cinta2.paint(g);
		// Dibujamos el robot 1
		robotC1.paint(g);
		// Dibujamos el robot 2
		robotC2.paint(g);
		// Dibujamos el bote 1
		boteC1.paint(g);
		// Dibujamos el bote 2
		boteC2.paint(g);
		// Dibujamos los botes expulsados cuando los haya
		boteExpulsadoC1.paint(g);
		boteExpulsadoC2.paint(g);
	}
	
	/**
	 * Tarea del hilo de repintado. Cada ciertos milisegundos, redibuja la pantalla.
	 */
	public void run()
	{
		while(true)
		{
			repaint();
			try { Thread.sleep(50); } catch (InterruptedException e) {}
		}
	}

	/**
	 * Metodo que llama el scada para avisar de que se debe sacar un nuevo bote
	 */
	public void sacandoNuevoBote()
	{
		depositoBotes.sacarNuevoBote();			
	}
	
	/**
	 * Metodo que llama el scada para avisar de que el bote est� andando vac�o por la 
	 * cinta antes de llegar al llenador de mermelada
	 */
	public void boteAndandoVacio()
	{
		depositoBotes.setFuncionando(false);
		boteC1.ponerBote();
		cinta1.arrancarCinta();
	}
	
	/**
	 * Metodo que llama el scada para avisar de que el bote se est� llenando
	 * de mermelada
	 */
	public void cargarMermelada()
	{
		cinta1.pararCinta();
		boteC1.setPosicionBote(250);
		llenador.procesoLlenado(this.scada.getConfiguracion().getTiempoLlenadoBote());		
	}

	/**
	 * Metodo que llama el scada para avisar de que el bote est� andando lleno despues
	 * del llenador de botes
	 */
	public void boteAndandoLleno()
	{
		boteC1.setEstado(Bote.LLENO);
		llenador.setFuncionando(false);
		cinta1.arrancarCinta();
		detectorBotesLlenos.setFuncionando(false);
	}

	/**
	 * Metodo que llama el scada para avisar de que el bote est� pasando por
	 * el detector de llenado
	 */
	public void pasaPorDetectorLlenado()
	{
		boteC1.setPosicionBote(410);
		detectorBotesLlenos.setFuncionando(true);
		cinta1.arrancarCinta();
	}

	/**
	 * Metodo que llama el scada para avisar de que el bote se expulsa de la cinta de
	 * llenado
	 */	
	public void expulsarBoteCinta1()
	{
		quitarBoteCinta1();
		boteExpulsadoC1.expulsarBote(450, 60, 180);
		expulsorC1.activarUnTiempo(500);
		cinta1.pararCinta();
	}
	
	/**
	 * Metodo que llama el scada para avisar de que el bote en la cinta de
	 * llenado est� a la espera de transporte
	 */	
	public void esperandoTransporteEntreCintas()
	{
		cinta1.pararCinta();
		boteC1.setPosicionBote(600);
	}

	/**
	 * Metodo que llama el scada para avisar de que el bote en la cinta de
	 * llenado ha sido quitado por el robot (y por tanto puede salir otro bote)
	 */	
	public void quitarBoteCinta1()
	{
		cinta1.pararCinta();
		boteC1.quitarBote();
	}
	
	/**
	 * Metodo que llama el scada para avisar de que el bote est� transportandose de
	 * una cinta a otra
	 */	
	public void transportarBote()
	{
		robotC1.iniciarTransporte(60, 360, scada.getConfiguracion().getTiempoTransporteEntreCintas());
	}
	
	/**
	 * Metodo que llama el scada para avisar de que el bote ya ha sido transportado
	 * a la cinta de taponado.
	 */	
	public void finTransporteEntreCintas()
	{
		robotC1.finTransporte();
	}

	/**
	 * Metodo que llama el scada para avisar de que el sistema se par� por culpa
	 * del dep�sito de botes.
	 */	
	public void depositoBotesParado()
	{
		depositoBotes.setParado(true);
	}

	/**
	 * Metodo que llama el scada para avisar de que el sistema se par� por culpa
	 * del llenador de mermelada.
	 */	
	public void llenadorMermeladaParado()
	{
		llenador.setParado(true);
	}
	
	/**
	 * Metodo que llama el scada para avisar de que el sistema se par� por culpa
	 * de la caja de botes mal llenados
	 */	
	public void cajaBotesMalTapadosLlena()
	{
		cajaMalLlenados.setParado(true);
	}
	
	// Metodos que afectan a la simulacion de la segunda cinta
	/**
	 * Metodo que llama el scada para avisar de que el bote circula por la cinta 
	 * de tapado sin tapa.
	 */	
	public void boteCintaTapadoAndandoSinTapa()
	{
		boteC2.setEstado(Bote.LLENO);
		boteC2.ponerBote();
		cinta2.arrancarCinta();
	}	

	/**
	 * Metodo que llama el scada para avisar de que el bote esta siendo tapado.
	 */	
	public void tapandoBote()
	{
		cinta2.pararCinta();
		taponador.tapar();
		boteC2.setPosicionBote(460);
	}

	/**
	 * Metodo que llama el scada para avisar de que el bote circula ya con tapa
	 */	
	public void boteCintaTapadoAndandoConTapa()
	{
		boteC2.setEstado(Bote.TAPADO);		
		cinta2.arrancarCinta();
	}	

	/**
	 * Metodo que llama el scada para avisar de que el bote esta siendo etiquetado.
	 */	
	public void etiquetandoBote()
	{
		cinta2.pararCinta();
		etiquetador.setFuncionando(true);
		System.out.println("Etiquetado:"+boteC2.getPosicion());
		boteC2.setPosicionBote(300);
	}

	/**
	 * Metodo que llama el scada para avisar de que el bote esta circulando ya con
	 * la etiqueta puesta.
	 */	
	public void boteCintaTapadoAndandoConEtiqueta()
	{
		boteC2.setEstado(Bote.ETIQUETADO);		
		etiquetador.setFuncionando(false);
		cinta2.arrancarCinta();
		detectorBotesMalTapados.setFuncionando(false);
	}
	
	/**
	 * Metodo que llama el scada para avisar de que el bote esta pasando por el 
	 * detector de bien o mal tapado.
	 */	
	public void boteCintaTapadoPasaPorDetectorTapado()
	{
		cinta2.arrancarCinta();
		boteC2.setEstado(Bote.ETIQUETADO);
		detectorBotesMalTapados.setFuncionando(true);
		boteC2.setPosicionBote(223);		
	}

	/**
	 * Metodo que llama el scada para avisar de que el bote de la cinta de tapado
	 * ha sido quitado de la misma.
	 */
	public void quitarBoteCinta2()
	{
		cinta2.pararCinta();
		boteC2.quitarBote();
	}

	/**
	 * Metodo que llama el scada para avisar de que el bote ha sido expulsado de
	 * la cinta de tapado.
	 */	
	public void expulsarBoteCinta2()
	{
		quitarBoteCinta2();
		boteExpulsadoC2.expulsarBote(177,376,460);
	}

	/**
	 * Metodo que llama el scada para avisar de que el bote est� siendo transportado
	 * a la caja de embalaje.
	 */	
	public void transportandoBoteCajaEmbalaje()
	{
		cinta2.pararCinta();
		boteC2.quitarBote();
		robotC2.iniciarTransporte(100, 25, scada.getConfiguracion().getTiempoTransporteCajaEmbalaje());
	}

	/**
	 * Metodo que llama el scada para avisar de que la cinta de tapado est� parada y
	 * a la espera de otro bote que tapar.
	 */
	public void esperandoBoteCintaTapado()
	{
		cinta2.pararCinta();
		boteC2.quitarBote();
		robotC2.finTransporte();
	}

	/**
	 * Metodo que llama el scada para avisar de que la caja de embalaje est� llena.
	 */
	public void cajaEmbalajeLlena()
	{
		cajaBotesAcabados.setParado(true);
	}
	
	/**
	 * Metodo que llama el scada para parar todo el sistema
	 */
	public void pararTodo()
	{
		cinta1.destruirTarea();
		cinta2.destruirTarea();
		robotC1.pararRobot();
		robotC2.pararRobot();
		boteC1.destruirTarea();
		boteC2.destruirTarea();
	}
}

