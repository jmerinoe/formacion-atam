package comun;
/**
 * Interfaz que sirve como repositorio de constantes para la aplicaci�n. Aqui
 * se recogen desde los remitentes de cada mensaje de comunicaci�n, as� como
 * los estados de los aut�matas de llenado, tapado y maestro.
 * 
 * @version 1.0
 * @author	Raquel G�mez, Blanca Tom�s, Lia Bail�n, �scar Garc�a, David Fdez.
 */

public interface IConstantes
{
	// Participantes de la comunicacion
	public static final int SCADA = 0;
	public static final int AUTOMATA_MAESTRO = 1;
	public static final int AUTOMATA_LLENADO = 2;
	public static final int AUTOMATA_TAPONADO = 3;
	
	// Estados del automata de llenado
	public static final int AL_CINTA_LIBRE 						  = 100;
	public static final int AL_SACANDO_BOTE 					  = 101;
	public static final int AL_ANDANDO_VACIO 					  = 102;
	public static final int AL_LLENANDO 						  = 103;
	public static final int AL_ANDANDO_LLENO 					  = 104;
	public static final int AL_PASA_POR_DETECTOR_LLENADO 		  = 105;
	public static final int AL_ANDANDO_LLENO_DETECTADO 			  = 106;
	public static final int AL_EXPULSANDO_BOTE					  = 107;
	public static final int AL_ESPERANDO_TRANSPORTE 			  = 108;
	public static final int AL_PARADA_EMERGENCIA_NO_BOTES 		  = 109;
	public static final int AL_PARADA_EMERGENCIA_NO_MERMELADA 	  = 110;
	public static final int AL_PARADA_EMERGENCIA_CAJA_BOTES_LLENA = 111;
	public static final int AL_SISTEMA_PARADO 					  = 112;
	
	// Estados del automata de taponado
	public static final int AT_SISTEMA_PARADO 						= 200;
	public static final int AT_ESPERANDO_BOTE 						= 201;
	public static final int AT_ANDANDO_SIN_TAPA 					= 202;
	public static final int AT_TAPANDO 								= 203;
	public static final int AT_ANDANDO_TAPADO 						= 204;
	public static final int AT_ETIQUETANDO 							= 205;
	public static final int AT_ANDANDO_ETIQUETADO 					= 206;
	public static final int AT_PASA_POR_DETECTOR_TAPADO 			= 207;
	public static final int AT_ANDANDO_ETIQUETADO_DETECTADO			= 208;
	public static final int AT_EXPULSANDO_BOTE						= 209;
	public static final int AT_TRANSPORTANDO		 				= 210;
	public static final int AT_BOTE_EN_CAJA_EMBALAJE 				= 211;
	public static final int AT_PARADA_EMERGENCIA_CAJA_BOTES_LLENA 	= 212;

	// Estados del automata maestro
	public static final int AM_SISTEMA_PARADO				 	= 300;
	public static final int AM_TRANSPORTANDO_BOTE_A_OTRA_CINTA 	= 301;
	public static final int AM_BOTE_TRANSPORTADO 				= 302;
	
}